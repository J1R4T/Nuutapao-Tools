/**
 * Nuutapao Tools — Desktop Launcher & Program Updater Prototype Logic
 */

(function () {
  'use strict';

  // --- State ---
  let soundEnabled = true;
  let isAppInstalled = false;
  let currentAppVersion = null;
  let latestAppVersion = 'Unknown';
  let activeReleaseInfo = null;
  let isCheckingUpdates = false;
  let isUpdating = false;

  // --- Elements ---
  const hubWindow = document.getElementById('hubWindow');
  const ambientCanvas = document.getElementById('ambientCanvas');
  const soundToggleBtn = document.getElementById('soundToggleBtn');
  const soundIcon = document.getElementById('soundIcon');
  const hubCloseBtn = document.getElementById('hubCloseBtn');

  const viewDeck = document.getElementById('viewDeck');
  const viewToolsDetail = document.getElementById('viewToolsDetail');

  const cardTools = document.getElementById('cardTools');
  const cardToolsBadge = document.getElementById('cardToolsBadge');
  const backToDeckBtn = document.getElementById('backToDeckBtn');

  const detailBadgeUpdate = document.getElementById('detailBadgeUpdate');
  const heroDetailBadge = document.getElementById('heroDetailBadge');

  const lblCurrentVersion = document.getElementById('lblCurrentVersion');
  const lblLatestVersion = document.getElementById('lblLatestVersion');
  const btnCheckUpdates = document.getElementById('btnCheckUpdates');
  const checkUpdatesIcon = document.getElementById('checkUpdatesIcon');
  const btnPrimaryUpdate = document.getElementById('btnPrimaryUpdate');
  const btnPrimaryText = document.getElementById('btnPrimaryText');
  const btnReinstallApp = document.getElementById('btnReinstallApp');
  const btnUninstallApp = document.getElementById('btnUninstallApp');
  const btnChangeDir = document.getElementById('btnChangeDir');
  const lblInstallPath = document.getElementById('lblInstallPath');

  const panelChangelog = document.getElementById('panelChangelog');
  const panelChangelogTitle = document.getElementById('panelChangelogTitle');
  const panelReleaseDate = document.getElementById('panelReleaseDate');
  const changelogList = document.getElementById('changelogList');
  const btnOpenGitHubRelease = document.getElementById('btnOpenGitHubRelease');

  const panelProgress = document.getElementById('panelProgress');
  const progressBarFill = document.getElementById('progressBarFill');
  const progressPctText = document.getElementById('progressPctText');
  const progressSpeedText = document.getElementById('progressSpeedText');
  const progressSizeText = document.getElementById('progressSizeText');
  const progressStatusHeading = document.getElementById('progressStatusHeading');
  const progressStatusSub = document.getElementById('progressStatusSub');
  const installTerminal = document.getElementById('installTerminal');
  const progressFinishedActions = document.getElementById('progressFinishedActions');
  const btnLaunchNewVersion = document.getElementById('btnLaunchNewVersion');

  const hubToast = document.getElementById('hubToast');

  // Helper to auto-append \Nuutapao Tools subfolder if not already present
  function normalizeInstallDir(p) {
    if (!p || typeof p !== 'string') return p;
    let clean = p.trim();
    if (/^[A-Za-z]:[/\\]?$/.test(clean)) {
      return `${clean[0].toUpperCase()}:\\Nuutapao Tools`;
    }
    clean = clean.replace(/[/\\]+$/, '');
    const parts = clean.split(/[/\\]/);
    const last = (parts[parts.length - 1] || '').toLowerCase();
    if (last === 'nuutapao tools' || last === 'nuutapao downloader') {
      return clean;
    }
    return clean + '\\Nuutapao Tools';
  }

  // =========================================================================
  // Web Audio Synthesizer (No external audio assets needed!)
  // =========================================================================
  let audioCtx = null;

  function initAudio() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        audioCtx = new AudioContext();
      }
    }
  }

  function playTone(freq, type, duration, vol = 0.08, rampDown = true) {
    if (!soundEnabled) return;
    try {
      initAudio();
      if (!audioCtx) return;
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);

      gain.gain.setValueAtTime(vol, audioCtx.currentTime);
      if (rampDown) {
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
      }

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
      // Audio context policy safe fallback
    }
  }

  function playCardHoverSound() {
    playTone(587.33, 'sine', 0.08, 0.04); // D5 soft ping
  }

  function playCardClickSound() {
    playTone(880, 'triangle', 0.12, 0.07); // A5 chime
    setTimeout(() => playTone(1174.66, 'sine', 0.18, 0.06), 60); // D6
  }

  function playWhooshSound() {
    if (!soundEnabled) return;
    try {
      initAudio();
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(740, audioCtx.currentTime + 0.22);

      gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
      gain.gain.linearRampToValueAtTime(0.001, audioCtx.currentTime + 0.25);

      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.25);
    } catch (e) {}
  }

  function playSuccessChime() {
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6 major chord
    notes.forEach((note, index) => {
      setTimeout(() => {
        playTone(note, 'triangle', 0.35, 0.1);
      }, index * 90);
    });
  }

  // =========================================================================
  // Background Ambient Particles Canvas
  // =========================================================================
  function initAmbientCanvas() {
    if (!ambientCanvas) return;
    const ctx = ambientCanvas.getContext('2d');
    let width = (ambientCanvas.width = window.innerWidth);
    let height = (ambientCanvas.height = window.innerHeight);

    window.addEventListener('resize', () => {
      width = ambientCanvas.width = window.innerWidth;
      height = ambientCanvas.height = window.innerHeight;
    });

    const particles = [];
    const particleCount = 20;

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * 2 + 0.5,
        speedX: (Math.random() - 0.5) * 0.4,
        speedY: (Math.random() - 0.5) * 0.4,
        alpha: Math.random() * 0.6 + 0.2,
        hue: Math.random() > 0.6 ? 25 : 270 // warm orange or purple dust
      });
    }

    let lastRenderAt = 0;
    function render(now = 0) {
      if (now - lastRenderAt < 33) {
        requestAnimationFrame(render);
        return;
      }
      lastRenderAt = now;
      ctx.clearRect(0, 0, width, height);

      for (let p of particles) {
        p.x += p.speedX;
        p.y += p.speedY;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 80%, 75%, ${p.alpha})`;
        ctx.fill();
      }

      requestAnimationFrame(render);
    }

    render();
  }

  // =========================================================================
  // 3D Parallax Tilt on Cards
  // =========================================================================
  function setupCardTilt(card) {
    if (!card) return;

    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const rotateX = ((y - centerY) / centerY) * -12;
      const rotateY = ((x - centerX) / centerX) * 12;

      card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-8px) scale3d(1.03, 1.03, 1.03)`;
    });

    card.addEventListener('mouseenter', () => {
      playCardHoverSound();
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0) scale3d(1, 1, 1)';
    });
  }

  // =========================================================================
  // Toast Notification Helper
  // =========================================================================
  let toastTimer = null;
  function showToast(message, duration = 3000) {
    if (!hubToast) return;
    hubToast.innerHTML = message;
    hubToast.classList.remove('hidden');

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      hubToast.classList.add('hidden');
    }, duration);
  }

  // =========================================================================
  // View Navigation
  // =========================================================================
  function switchView(fromView, toView) {
    playWhooshSound();
    fromView.classList.remove('active');
    toView.classList.add('active');
  }

  // =========================================================================
  // GitHub Releases Updater Logic
  // =========================================================================
  function appendTerminalLine(text, className = '') {
    const line = document.createElement('div');
    line.className = 'term-line ' + className;
    line.textContent = text;
    installTerminal.appendChild(line);
    installTerminal.scrollTop = installTerminal.scrollHeight;
  }

  function renderReleaseNotes(notes) {
    if (!changelogList || !notes || !notes.trim()) return;
    const lines = notes.split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0 && !l.startsWith('#') && !l.toLowerCase().startsWith('note patch'));

    if (lines.length === 0) return;

    changelogList.innerHTML = '';
    lines.slice(0, 8).forEach(line => {
      const cleanText = line.replace(/^[-*+•\s]+/, '').trim();
      if (!cleanText) return;

      const li = document.createElement('li');
      li.className = 'changelog-item';

      let icon = '✨';
      if (/fix|bug/i.test(cleanText)) icon = '🐛';
      else if (/speed|fast|turbo|optimi/i.test(cleanText)) icon = '⚡';
      else if (/add|new|feature/i.test(cleanText)) icon = '🌟';
      else if (/ui|design|look/i.test(cleanText)) icon = '🎨';
      else if (/security|protect/i.test(cleanText)) icon = '🛡️';

      li.innerHTML = `
        <span class="item-icon">${icon}</span>
        <div class="item-body">
          <strong>${cleanText}</strong>
        </div>
      `;
      changelogList.appendChild(li);
    });
  }

  // =========================================================================
  // Installation & Version State Visualizer
  // =========================================================================
  function applyInstallState(installed, currentVer, latestVer, hasUpdate) {
    isAppInstalled = !!installed;
    if (currentVer) {
      currentAppVersion = currentVer.startsWith('v') ? currentVer : 'v' + currentVer;
    } else {
      currentAppVersion = null;
    }

    if (latestVer) {
      latestAppVersion = latestVer.startsWith('v') ? latestVer : 'v' + latestVer;
    }

    if (!isAppInstalled) {
      // NOT INSTALLED
      lblCurrentVersion.textContent = 'Not Installed';
      lblCurrentVersion.style.color = '#8e95aa';
      lblLatestVersion.textContent = latestAppVersion;
      lblLatestVersion.style.color = '#4ade80';

      btnPrimaryText.textContent = `📥 Install Nuutapao Tools (${latestAppVersion})`;
      btnPrimaryUpdate.style.background = 'linear-gradient(135deg, #ff5e3a 0%, #ff2a54 100%)';
      btnPrimaryUpdate.classList.add('pulse-update');
      btnPrimaryUpdate.disabled = false;
      btnPrimaryUpdate.style.opacity = '1';

      btnReinstallApp.disabled = true;
      btnReinstallApp.title = 'Install Nuutapao Tools first.';

      if (btnUninstallApp) {
        btnUninstallApp.style.display = 'none';
      }

      if (cardToolsBadge) {
        cardToolsBadge.innerHTML = '<span class="pulse-dot dot-dim"></span> Not Installed';
      }
      if (heroDetailBadge) {
        heroDetailBadge.innerHTML = '<span class="pulse-dot dot-dim"></span> Not Installed';
      }
      if (detailBadgeUpdate) {
        detailBadgeUpdate.textContent = `Ready to Install: ${latestAppVersion}`;
        detailBadgeUpdate.style.borderColor = 'rgba(255, 94, 58, 0.4)';
        detailBadgeUpdate.style.color = '#ff8a65';
      }
    } else {
      // INSTALLED!
      lblCurrentVersion.textContent = currentAppVersion || 'Unknown';
      lblCurrentVersion.style.color = '#4ade80';
      lblLatestVersion.textContent = latestAppVersion;

      btnReinstallApp.disabled = false;
      btnReinstallApp.title = 'Download and reinstall the latest version from GitHub';

      if (btnUninstallApp) {
        btnUninstallApp.style.display = 'flex';
        btnUninstallApp.disabled = false;
      }

      if (hasUpdate) {
        lblLatestVersion.style.color = '#ff7043';
        btnPrimaryText.textContent = `⚡ Update to ${latestAppVersion}`;
        btnPrimaryUpdate.style.background = 'linear-gradient(135deg, #ff4500 0%, #ff7043 100%)';
        btnPrimaryUpdate.classList.add('pulse-update');
        btnPrimaryUpdate.disabled = false;
        btnPrimaryUpdate.style.opacity = '1';

        if (cardToolsBadge) {
          cardToolsBadge.innerHTML = '<span class="pulse-dot"></span> Update Ready';
        }
        if (heroDetailBadge) {
          heroDetailBadge.innerHTML = '<span class="pulse-dot"></span> Update Ready';
        }
        if (detailBadgeUpdate) {
          detailBadgeUpdate.textContent = `Update Ready: ${latestAppVersion}`;
          detailBadgeUpdate.style.borderColor = 'rgba(255, 78, 58, 0.5)';
          detailBadgeUpdate.style.color = '#ff7043';
        }
      } else {
        lblLatestVersion.style.color = '#4ade80';
        btnPrimaryText.textContent = `Already Up to Date (${currentAppVersion || latestAppVersion})`;
        btnPrimaryUpdate.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
        btnPrimaryUpdate.classList.remove('pulse-update');
        btnPrimaryUpdate.disabled = false;
        btnPrimaryUpdate.style.opacity = '1';

        if (cardToolsBadge) {
          cardToolsBadge.innerHTML = '<span class="pulse-dot"></span> Installed';
        }
        if (heroDetailBadge) {
          heroDetailBadge.innerHTML = '<span class="pulse-dot"></span> Up to Date';
        }
        if (detailBadgeUpdate) {
          detailBadgeUpdate.textContent = `Installed (${currentAppVersion || latestAppVersion})`;
          detailBadgeUpdate.style.borderColor = 'rgba(74, 222, 128, 0.4)';
          detailBadgeUpdate.style.color = '#4ade80';
        }
      }
    }
  }

  async function checkForGitHubUpdates(showToastNotification = false) {
    if (isCheckingUpdates) return;
    isCheckingUpdates = true;
    if (checkUpdatesIcon) checkUpdatesIcon.classList.add('spinning');

    try {
      const api = window.electronAPI || window.hubAPI;
      if (api && api.checkGitHubUpdates) {
        const result = await api.checkGitHubUpdates();
        if (result) {
          activeReleaseInfo = result;
          const installed = !!result.installed;
          const installedVer = result.installedVersion;
          const latestVer = result.latestVersion || latestAppVersion;
          const hasUpdate = !!result.hasUpdate;

          applyInstallState(installed, installedVer, latestVer, hasUpdate);

          if (result.success) {
            if (panelChangelogTitle && result.releaseName) {
              panelChangelogTitle.textContent = `✨ What's New in ${result.releaseName || latestVer}`;
            }
            if (panelReleaseDate && result.releaseDate) {
              try {
                const d = new Date(result.releaseDate);
                panelReleaseDate.textContent = 'Released ' + d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
              } catch (e) {}
            }
            if (result.releaseNotes) {
              renderReleaseNotes(result.releaseNotes);
            }

            if (showToastNotification) {
              if (!installed) {
                showToast(`ℹ️ Nuutapao Tools is not installed. Latest version is ${latestVer}.`);
              } else if (hasUpdate) {
                showToast(`🔔 New release available: ${latestVer} on GitHub!`);
              } else {
                showToast(`✅ Nuutapao Tools is up to date (${currentAppVersion || latestVer})`);
              }
            }
          } else if (result.error && showToastNotification) {
            showToast(`⚠️ ${result.error}`);
          }
        }
      }
    } catch (err) {
      console.error('Update check failed:', err);
      if (showToastNotification) {
        showToast('⚠️ Could not connect to GitHub API');
      }
    } finally {
      isCheckingUpdates = false;
      if (checkUpdatesIcon) {
        setTimeout(() => checkUpdatesIcon.classList.remove('spinning'), 400);
      }
    }
  }

  async function startRealUpdate() {
    if (isUpdating) return;
    isUpdating = true;
    btnReinstallApp.disabled = true;

    if (!activeReleaseInfo || !activeReleaseInfo.downloadUrl) {
      showToast('🔍 Checking GitHub Releases for latest download package...');
      await checkForGitHubUpdates(true);
      if (!activeReleaseInfo || !activeReleaseInfo.downloadUrl) {
        showToast('ℹ️ No .exe installer asset found on GitHub yet.');
        isUpdating = false;
        btnReinstallApp.disabled = !isAppInstalled;
        return;
      }
    }

    playCardClickSound();

    panelChangelog.classList.add('hidden');
    panelProgress.classList.remove('hidden');
    progressFinishedActions.classList.add('hidden');

    btnPrimaryUpdate.disabled = true;
    btnPrimaryUpdate.style.opacity = '0.5';

    installTerminal.innerHTML = '';
    const releaseTag = activeReleaseInfo.releaseTag || activeReleaseInfo.latestVersion;
    const assetName = activeReleaseInfo.assetName || 'Nuutapao Tools Setup.exe';
    const mbTotal = activeReleaseInfo.assetSize ? (activeReleaseInfo.assetSize / (1024 * 1024)).toFixed(1) : '143.0';

    appendTerminalLine(`[1/4] Connecting to GitHub Releases (${releaseTag})...`, 'highlight');
    appendTerminalLine(`[2/4] Package: ${assetName} (${mbTotal} MB)`);
    progressStatusHeading.textContent = `Downloading ${assetName}...`;
    progressStatusSub.textContent = 'Streaming high-speed release package from GitHub CDN';

    const api = window.electronAPI || window.hubAPI;
    if (api && api.onDownloadProgress) {
      api.onDownloadProgress((data) => {
        progressBarFill.style.width = data.percent.toFixed(1) + '%';
        progressPctText.textContent = Math.round(data.percent) + '%';
        progressSpeedText.textContent = `${data.speedMBps} MB/s`;
        progressSizeText.textContent = `${data.downloadedMB} / ${data.totalMB} MB`;
      });
    }
    if (api && api.onInstallLog) {
      api.onInstallLog((msg) => {
        appendTerminalLine(msg, 'info');
        progressStatusHeading.textContent = 'Installing Nuutapao Tools...';
        progressStatusSub.textContent = msg;
        progressSpeedText.textContent = 'Installing...';
      });
    }

    try {
      appendTerminalLine(`[3/4] Streaming data from GitHub CDN...`);
      const result = await (api ? api.downloadAndInstallUpdate({
        downloadUrl: activeReleaseInfo.downloadUrl,
        assetName: activeReleaseInfo.assetName,
        installDir: (lblInstallPath && lblInstallPath.dataset.userEdited === 'true') ? normalizeInstallDir(lblInstallPath.textContent) : null
      }) : null);

      if (result && result.success && result.installed) {
        appendTerminalLine(`[4/4] Installation completed directly on Nuutapao Tools!`, 'success');
        finishUpdate(activeReleaseInfo.latestVersion, true);
      } else {
        throw new Error((result && result.message) || 'Installation was not completed');
      }
    } catch (err) {
      appendTerminalLine(`❌ Error: ${err.message}`, 'error');
      progressStatusHeading.textContent = 'Installation Failed';
      progressStatusSub.textContent = err.message;
      btnPrimaryUpdate.disabled = false;
      btnPrimaryUpdate.style.opacity = '1';
      isUpdating = false;
      btnReinstallApp.disabled = !isAppInstalled;
      showToast(`❌ Installation failed: ${err.message}`);
    }
  }

  function finishUpdate(newVer, installed) {
    isUpdating = false;
    btnReinstallApp.disabled = !installed;
    currentAppVersion = newVer ? (newVer.startsWith('v') ? newVer : `v${newVer}`) : null;

    if (installed) {
      progressStatusHeading.textContent = `🎉 Nuutapao Tools Installed!`;
      progressStatusSub.textContent = 'Desktop icon & Start Menu shortcut created automatically.';
      progressSpeedText.textContent = 'Complete';
      progressBarFill.style.width = '100%';
      progressPctText.textContent = '100%';
      appendTerminalLine('✨ Installation complete! Nuutapao Tools is ready to use.', 'success');
      appendTerminalLine('📌 Desktop icon and Start Menu shortcuts ready.', 'success');
      applyInstallState(true, currentAppVersion, latestAppVersion, false);
      showToast(`✨ Nuutapao Tools ${currentAppVersion} installed successfully!`);
    } else {
      progressStatusHeading.textContent = `⚠️ Installation Incomplete`;
      progressStatusSub.textContent = 'Please retry installing Nuutapao Tools.';
      progressSpeedText.textContent = 'Failed';
      appendTerminalLine('⚠️ Installation could not be verified.', 'error');
    }

    progressFinishedActions.classList.remove('hidden');
    playSuccessChime();
  }

  // =========================================================================
  // Event Bindings
  // =========================================================================
  function initEvents() {
    // Sound Toggle
    soundToggleBtn.addEventListener('click', () => {
      soundEnabled = !soundEnabled;
      soundIcon.textContent = soundEnabled ? '🔊' : '🔇';
      soundToggleBtn.title = soundEnabled ? 'Sound Enabled' : 'Sound Muted';
      if (soundEnabled) playCardClickSound();
    });

    // Close Hub
    hubCloseBtn.addEventListener('click', () => {
      playCardClickSound();
      showToast('👋 Closing Nuutapao Tools...', 1500);
      setTimeout(() => {
        const api = window.electronAPI || window.hubAPI;
        if (api && api.closeWindow) {
          api.closeWindow();
        } else if (window.opener) {
          window.close();
        } else {
          // Visual exit animation in browser
          const win = document.getElementById('hubWindow');
          win.style.transition = 'transform 0.4s ease, opacity 0.4s ease';
          win.style.transform = 'scale(0.8) translateY(30px)';
          win.style.opacity = '0';
          setTimeout(() => {
            win.style.display = 'none';
            alert('Nuutapao Tools closed. You can refresh the page to reopen.');
          }, 400);
        }
      }, 300);
    });

    function openToolsDetail() {
      playCardClickSound();
      switchView(viewDeck, viewToolsDetail);
      // Automatically check for GitHub updates when opening tools details
      checkForGitHubUpdates(false);
    }

    // Card 2: Creator Tools (Transition to Detail View: card moves left, info moves right)
    cardTools.addEventListener('click', (e) => {
      e.stopPropagation();
      openToolsDetail();
    });

    const cardToolsWrap = document.getElementById('cardToolsWrap');
    if (cardToolsWrap) {
      cardToolsWrap.addEventListener('click', () => {
        openToolsDetail();
      });
    }

    cardTools.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openToolsDetail();
      }
    });

    // Return to Hub Deck (Transition back to centered cards deck)
    backToDeckBtn.addEventListener('click', () => {
      playCardClickSound();
      switchView(viewToolsDetail, viewDeck);
    });

    // Check for updates button
    if (btnCheckUpdates) {
      btnCheckUpdates.addEventListener('click', (e) => {
        e.stopPropagation();
        playCardClickSound();
        checkForGitHubUpdates(true);
      });
    }

    // View on GitHub Releases button
    if (btnOpenGitHubRelease) {
      btnOpenGitHubRelease.addEventListener('click', (e) => {
        e.stopPropagation();
        playCardClickSound();
        const url = activeReleaseInfo?.htmlUrl || 'https://github.com/J1R4T/Nuutapao-Tools/releases';
        const api = window.electronAPI || window.hubAPI;
        if (api && api.openExternal) {
          api.openExternal(url);
        } else {
          window.open(url, '_blank');
        }
      });
    }

    // Primary Action (Install / Update / Check)
    btnPrimaryUpdate.addEventListener('click', () => {
      if (!isAppInstalled) {
        startRealUpdate();
      } else if (activeReleaseInfo && activeReleaseInfo.hasUpdate) {
        startRealUpdate();
      } else {
        checkForGitHubUpdates(true);
      }
    });

    // Reinstall the latest release directly from GitHub.
    btnReinstallApp.addEventListener('click', () => {
      if (!isAppInstalled || isUpdating) return;
      startRealUpdate();
    });

    // Uninstall Program
    if (btnUninstallApp) {
      btnUninstallApp.addEventListener('click', async () => {
        if (!isAppInstalled) {
          showToast('ℹ️ Nuutapao Tools is not installed.');
          return;
        }

        playCardClickSound();
        const api = window.electronAPI || window.hubAPI;

        let confirmed = false;
        if (api && api.confirmDialog) {
          try {
            confirmed = await api.confirmDialog({
              title: 'Uninstall Nuutapao Tools',
              message: 'Are you sure you want to uninstall Nuutapao Tools from your system?',
              okLabel: 'Uninstall',
              cancelLabel: 'Cancel'
            });
          } catch (e) {
            confirmed = confirm('Are you sure you want to uninstall Nuutapao Tools from your system?');
          }
        } else {
          confirmed = confirm('Are you sure you want to uninstall Nuutapao Tools from your system?');
        }
        if (!confirmed) return;

        if (api && api.uninstallTools) {
          try {
            showToast('🗑️ Launching uninstaller...');
            const res = await api.uninstallTools();
            if (res && res.success) {
              showToast('⏳ Uninstaller is running. Follow prompts to finish uninstallation.');

              // Poll for uninstallation completion
              let pollCount = 0;
              const pollInterval = setInterval(async () => {
                pollCount++;
                if (pollCount > 30) {
                  clearInterval(pollInterval);
                  return;
                }

                const sys = await api.getSystemInfo();
                if (sys && !sys.installed) {
                  clearInterval(pollInterval);
                  applyInstallState(false, null, latestAppVersion, false);
                  playSuccessChime();
                  showToast('✅ Nuutapao Tools has been uninstalled successfully.');
                }
              }, 2000);
            } else {
              showToast('⚠️ ' + (res?.message || 'Could not launch uninstaller.'));
            }
          } catch (err) {
            showToast('❌ Failed to launch uninstaller: ' + err.message);
          }
        } else {
          showToast('ℹ️ Uninstall is only available in the desktop app.');
        }
      });
    }

    btnLaunchNewVersion.addEventListener('click', async () => {
      const api = window.electronAPI || window.hubAPI;
      if (!api || !api.launchApp) {
        showToast('Launch is only available in the desktop app.');
        return;
      }
      try {
        const result = await api.launchApp();
        if (result && result.success) {
          showToast(result.alreadyRunning ? 'Nuutapao Tools is already open.' : 'Nuutapao Tools launched!');
        } else {
          showToast(result?.message || 'Could not find Nuutapao Tools executable.');
        }
      } catch (err) {
        showToast('Failed to launch: ' + err.message);
      }
    });

    // Change Directory picker (native dialog in Electron, prompt fallback in browser)
    btnChangeDir.addEventListener('click', async () => {
      playCardClickSound();
      const api = window.electronAPI || window.hubAPI;
      if (api && api.selectDirectory) {
        try {
          const rawPath = await api.selectDirectory(lblInstallPath.textContent);
          if (rawPath) {
            const newPath = normalizeInstallDir(rawPath);
            lblInstallPath.textContent = newPath;
            lblInstallPath.dataset.userEdited = 'true';
            showToast(`📁 Install path updated to: ${newPath}`);
          }
        } catch (err) {
          showToast('❌ Failed to select directory: ' + err.message);
        }
      } else {
        const rawPath = prompt('Set install destination directory:', lblInstallPath.textContent);
        if (rawPath && rawPath.trim()) {
          const newPath = normalizeInstallDir(rawPath.trim());
          lblInstallPath.textContent = newPath;
          lblInstallPath.dataset.userEdited = 'true';
          showToast(`📁 Install path updated to: ${newPath}`);
        }
      }
    });

    // Keyboard navigation (ESC closes modal, Arrow keys between cards)
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (viewToolsDetail.classList.contains('active')) {
          switchView(viewToolsDetail, viewDeck);
        }
      }
    });

    // Setup 3D Tilt for active card
    setupCardTilt(cardTools);
  }

  // =========================================================================
  // Window Dragging (Browser fallback + Native Electron drag support)
  // =========================================================================
  function setupWindowDragging() {
    const titlebar = document.getElementById('hubTitlebar');
    const win = document.getElementById('hubWindow');
    if (!titlebar || !win) return;

    let isDragging = false;
    let startX = 0, startY = 0, initialLeft = 0, initialTop = 0;

    titlebar.addEventListener('mousedown', (e) => {
      if (e.target.closest('button') || e.target.closest('.titlebar-controls')) return;
      if (window.electronAPI || window.hubAPI) return; // Handled natively by Electron -webkit-app-region: drag

      isDragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = win.getBoundingClientRect();
      initialLeft = rect.left;
      initialTop = rect.top;

      titlebar.style.cursor = 'grabbing';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      win.style.position = 'fixed';
      win.style.left = `${initialLeft + dx}px`;
      win.style.top = `${initialTop + dy}px`;
      win.style.margin = '0';
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        titlebar.style.cursor = '';
      }
    });
  }

  // =========================================================================
  // Initialize
  // =========================================================================
  window.addEventListener('DOMContentLoaded', () => {
    initAmbientCanvas();
    initEvents();
    setupWindowDragging();

    // Default to uninstalled check state
    applyInstallState(false, null, 'Unknown', false);

    if (lblInstallPath && lblInstallPath.textContent) {
      lblInstallPath.textContent = normalizeInstallDir(lblInstallPath.textContent);
    }

    // Fetch installed path and version from Electron
    const api = window.electronAPI || window.hubAPI;
    if (api && api.getSystemInfo) {
      api.getSystemInfo().then(info => {
        if (info) {
          if (info.installPath && lblInstallPath) {
            lblInstallPath.textContent = normalizeInstallDir(info.installPath);
          }
          applyInstallState(info.installed, info.installedVersion, latestAppVersion, false);
        }
        // Defer update check so UI renders instantly first
        setTimeout(() => checkForGitHubUpdates(false), 1200);
      }).catch(() => {
        setTimeout(() => checkForGitHubUpdates(false), 1200);
      });
    } else {
      setTimeout(() => checkForGitHubUpdates(false), 1200);
    }
  });
})();
