const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn, execSync, execFile } = require('child_process');
const {
  compareSemver,
  isToolsSetupAsset,
  getInstallableRelease
} = require('./release-utils');

// Universal Windows Compatibility & Performance Optimizations — applied before app ready
app.commandLine.appendSwitch('enable-features', 'CanvasOopRasterization');
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
app.commandLine.appendSwitch('high-dpi-support', '1');

// Support CLI flags and environment overrides for low-spec / VM / broken GPU environments
if (
  process.argv.includes('--disable-gpu') ||
  process.env.NUUTAPAO_DISABLE_GPU === '1' ||
  process.env.NUUTAPAO_TEST === '1'
) {
  app.disableHardwareAcceleration();
}
if (process.argv.includes('--no-sandbox')) {
  app.commandLine.appendSwitch('no-sandbox');
}

// Graceful child process crash handler (GPU, utility processes)
app.on('child-process-gone', (event, details) => {
  if (details.type === 'GPU') {
    console.warn('GPU process gone in Hub:', details.reason, '- continuing in safe fallback');
  }
});
app.on('render-process-gone', (event, webContents, details) => {
  console.warn('Render process gone in Hub:', details.reason);
});

let hubWindow;

// --- Single Instance Lock ---
// Prevent duplicate Hub windows when user re-launches while already running
const gotLock = app.requestSingleInstanceLock();

if (!gotLock) {
  // Another instance is already running — quit this one immediately
  app.quit();
} else {
  // When another instance tries to launch, bring existing window to front
  app.on('second-instance', () => {
    if (hubWindow) {
      if (hubWindow.isMinimized()) hubWindow.restore();
      hubWindow.show();
      hubWindow.focus();
    }
  });

  function createHubWindow() {
    const icoPath = path.join(__dirname, 'assets', 'icon.ico');
    const rootIco = path.join(__dirname, '..', 'icon.ico');
    const pubIco = path.join(__dirname, '..', 'public', 'icon.ico');
    const icon = fs.existsSync(icoPath) ? icoPath
      : fs.existsSync(rootIco) ? rootIco
      : fs.existsSync(pubIco) ? pubIco
      : undefined;

    hubWindow = new BrowserWindow({
      width: 960,
      height: 640,
      frame: false,
      transparent: true,
      resizable: false,
      show: false,
      backgroundColor: '#00000000',
      icon: icon,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        preload: path.join(__dirname, 'preload.js')
      }
    });

    hubWindow.loadFile(path.join(__dirname, 'index.html'));

    // Use ready-to-show (fires when first render is done) — faster than did-finish-load
    hubWindow.once('ready-to-show', () => {
      hubWindow.show();
      hubWindow.focus();
    });
  }

  app.whenReady().then(createHubWindow);

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
      app.quit();
    }
  });

  // Window controls
  ipcMain.on('hub-close', () => {
    hubWindow?.close();
  });

  ipcMain.on('hub-minimize', () => {
    hubWindow?.minimize();
  });

  ipcMain.on('hub-maximize', () => {
    if (hubWindow && !hubWindow.isMaximized()) {
      hubWindow.setResizable(true);
      hubWindow.maximize();
    }
  });

  ipcMain.on('hub-unmaximize', () => {
    if (hubWindow && hubWindow.isMaximized()) {
      hubWindow.unmaximize();
      hubWindow.setSize(960, 640);
      hubWindow.center();
    }
  });

  ipcMain.on('hub-toggle-maximize', () => {
    if (hubWindow) {
      if (hubWindow.isMaximized()) {
        hubWindow.unmaximize();
        hubWindow.setSize(960, 640);
        hubWindow.center();
      } else {
        hubWindow.setResizable(true);
        hubWindow.maximize();
      }
    }
  });

  // Launch main tools program — search multiple install locations
  // Helper: check if a process is running and try to bring its window to front
  function isProcessRunningAndFocus(processName) {
    const { execSync } = require('child_process');
    try {
      // Check if the process is running
      const result = execSync(`tasklist /FI "IMAGENAME eq ${processName}" /NH`, { encoding: 'utf8', timeout: 5000 });
      if (!result.includes(processName)) return false;

      // Process is running — bring its window to front using PowerShell + Win32 API
      const psScript = `
        Add-Type @"
          using System;
          using System.Runtime.InteropServices;
          public class Win32Focus {
            [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
            [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
            [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
          }
"@
        $procs = Get-Process -Name '${processName.replace('.exe', '')}' -ErrorAction SilentlyContinue
        foreach ($p in $procs) {
          if ($p.MainWindowHandle -ne 0) {
            if ([Win32Focus]::IsIconic($p.MainWindowHandle)) {
              [Win32Focus]::ShowWindow($p.MainWindowHandle, 9)
            }
            [Win32Focus]::SetForegroundWindow($p.MainWindowHandle)
            break
          }
        }
      `.trim();
      execSync(`powershell -NoProfile -ExecutionPolicy Bypass -Command "${psScript.replace(/"/g, '\\\\"')}"`, { timeout: 8000, windowsHide: true });
      return true;
    } catch (err) {
      return false;
    }
  }

  // Helper: Get Windows Special Folders (Desktop & Programs)
  function getWindowsSpecialFolders() {
    const userProfile = process.env.USERPROFILE || os.homedir();
    const appData = process.env.APPDATA || path.join(userProfile, 'AppData', 'Roaming');

    const desktops = new Set([
      path.join(userProfile, 'Desktop'),
      path.join(userProfile, 'OneDrive', 'Desktop')
    ]);

    try {
      const regDesktop = execSync('reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders" /v Desktop', { encoding: 'utf8', timeout: 3000, stdio: ['pipe', 'pipe', 'ignore'] });
      const match = regDesktop.match(/Desktop\s+REG_\S+\s+(.+)/i);
      if (match && match[1]) {
        let resolved = match[1].trim().replace(/%USERPROFILE%/gi, userProfile);
        if (fs.existsSync(resolved)) desktops.add(resolved);
      }
    } catch (_) {}

    const programs = path.join(appData, 'Microsoft', 'Windows', 'Start Menu', 'Programs');
    return { desktops: Array.from(desktops).filter(d => fs.existsSync(d) || d.includes('Desktop')), programs };
  }

  // Create Windows Shortcut reliably via native WSH VBScript (No ExecutionPolicy restrictions)
  function createWindowsShortcut(targetExe, shortcutPath, description) {
    const targetFolder = path.dirname(shortcutPath);
    if (!fs.existsSync(targetFolder)) {
      fs.mkdirSync(targetFolder, { recursive: true });
    }

    const vbsPath = path.join(os.tmpdir(), `create_lnk_${Date.now()}_${Math.random().toString(36).substring(2, 6)}.vbs`);
    const vbsContent = [
      'Set oWS = WScript.CreateObject("WScript.Shell")',
      `sLinkFile = "${shortcutPath.replace(/"/g, '""')}"`,
      'Set oLink = oWS.CreateShortcut(sLinkFile)',
      `oLink.TargetPath = "${targetExe.replace(/"/g, '""')}"`,
      `oLink.WorkingDirectory = "${path.dirname(targetExe).replace(/"/g, '""')}"`,
      `oLink.Description = "${(description || 'Nuutapao Tools').replace(/"/g, '""')}"`,
      `oLink.IconLocation = "${targetExe.replace(/"/g, '""')},0"`,
      'oLink.Save'
    ].join('\r\n');

    try {
      fs.writeFileSync(vbsPath, vbsContent, 'utf8');
      execSync(`cscript //nologo "${vbsPath}"`, { timeout: 5000, stdio: 'pipe' });
      return fs.existsSync(shortcutPath);
    } catch (err) {
      return false;
    } finally {
      try { if (fs.existsSync(vbsPath)) fs.unlinkSync(vbsPath); } catch (_) {}
    }
  }

  // Guarantee that Desktop and Start Menu shortcuts and App Paths exist
  function ensureShortcutsAndRegistration(exePath) {
    if (!exePath || !fs.existsSync(exePath)) return;
    try {
      const special = getWindowsSpecialFolders();
      for (const desk of special.desktops) {
        if (fs.existsSync(desk)) {
          const lnk = path.join(desk, 'Nuutapao Tools.lnk');
          createWindowsShortcut(exePath, lnk, 'Nuutapao Tools');
        }
      }
      if (special.programs && fs.existsSync(special.programs)) {
        const lnk = path.join(special.programs, 'Nuutapao Tools.lnk');
        createWindowsShortcut(exePath, lnk, 'Nuutapao Tools');
      }

      // Register in Windows Search App Paths
      const regKey1 = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Nuutapao Tools.exe';
      const regKey2 = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\nuutapao.exe';
      execSync(`reg add "${regKey1}" /ve /t REG_SZ /d "\\"${exePath}\\"" /f`, { timeout: 3000, stdio: 'ignore' });
      execSync(`reg add "${regKey1}" /v Path /t REG_SZ /d "\\"${path.dirname(exePath)}\\"" /f`, { timeout: 3000, stdio: 'ignore' });
      execSync(`reg add "${regKey2}" /ve /t REG_SZ /d "\\"${exePath}\\"" /f`, { timeout: 3000, stdio: 'ignore' });
      execSync(`reg add "${regKey2}" /v Path /t REG_SZ /d "\\"${path.dirname(exePath)}\\"" /f`, { timeout: 3000, stdio: 'ignore' });
    } catch (_) {}
  }

  // Helper to guarantee target installation path always ends in dedicated Nuutapao Tools subfolder
  function ensureNuutapaoSubfolder(targetPath) {
    if (!targetPath || typeof targetPath !== 'string') return targetPath;
    let clean = targetPath.trim();
    if (/^[A-Za-z]:[/\\]?$/.test(clean)) {
      const driveLetter = clean[0].toUpperCase();
      return `${driveLetter}:\\Nuutapao Tools`;
    }
    clean = clean.replace(/[/\\]+$/, '');
    const baseName = path.basename(clean).toLowerCase();
    if (baseName === 'nuutapao tools' || baseName === 'nuutapao downloader') {
      return clean;
    }
    return path.join(clean, 'Nuutapao Tools');
  }

  // Silent installer runner: executes in background with /S, monitors extraction, and auto-creates shortcuts
  async function executeSilentInstaller(installerPath, installDir, sendLog) {
    if (typeof sendLog !== 'function') sendLog = () => {};

    sendLog('⚡ Starting silent installation for Nuutapao Tools...');

    const localAppData = process.env.LOCALAPPDATA || (process.env.USERPROFILE ? path.join(process.env.USERPROFILE, 'AppData', 'Local') : '');
    const defaultTargetDir = path.join(localAppData, 'Programs', 'Nuutapao Tools');
    const targetDir = ensureNuutapaoSubfolder(installDir || defaultTargetDir);

    // Spawn directly instead of running through cmd.exe. This keeps paths with spaces
    // intact, avoids shell parsing, and leaves the Hub responsive while NSIS runs.
    try {
      sendLog('📦 Extracting core application binaries in background...');
      await new Promise((resolve, reject) => {
        const child = spawn(installerPath, ['/S', `/D=${targetDir}`], {
          windowsHide: true,
          stdio: 'ignore'
        });
        const timeout = setTimeout(() => {
          child.kill();
          reject(new Error('Installer timed out after 60 seconds.'));
        }, 60000);
        child.once('error', (error) => {
          clearTimeout(timeout);
          reject(error);
        });
        child.once('exit', (code) => {
          clearTimeout(timeout);
          code === 0 ? resolve() : reject(new Error(`Installer exited with code ${code}.`));
        });
      });
    } catch (err) {
      // NSIS can hand work to a child process. Verify the installed result below.
      console.warn('Installer process note:', err.message);
    }

    // Wait for NSIS background extraction to finish and detect the installed application
    const maxWaitMs = 20000;
    const startTime = Date.now();
    let installedInfo = null;

    while (Date.now() - startTime < maxWaitMs) {
      installedInfo = await detectInstalledNuutapaoTools();
      if (installedInfo.installed && installedInfo.exePath && fs.existsSync(installedInfo.exePath)) {
        try {
          const stat = fs.statSync(installedInfo.exePath);
          if (stat.size > 1000000) {
            await new Promise(r => setTimeout(r, 1000));
            break;
          }
        } catch (_) {}
      }
      await new Promise(r => setTimeout(r, 1000));
    }

    installedInfo = await detectInstalledNuutapaoTools();
    if (installedInfo.installed && installedInfo.exePath) {
      sendLog('📌 Automatically creating Desktop icon and Start Menu shortcuts...');
      ensureShortcutsAndRegistration(installedInfo.exePath);
      sendLog('✅ Nuutapao Tools installation completed. No wizard required.');
      return {
        success: true,
        installed: true,
        exePath: installedInfo.exePath,
        version: installedInfo.version
      };
    }

    throw new Error('Silent installation could not be verified. Please retry.');
  }

  // Helper: detect installed Nuutapao Tools from filesystem and Windows Registry
  async function detectInstalledNuutapaoTools() {
    const localAppData = process.env.LOCALAPPDATA || (process.env.USERPROFILE ? path.join(process.env.USERPROFILE, 'AppData', 'Local') : '');
    const programFiles = process.env.ProgramFiles || 'C:\\Program Files';
    const programFilesX86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';

    let detectedExe = null;
    let detectedVersion = null;
    let uninstallCmd = null;

    // 1. Check primary standard install location first (fast & reliable)
    const primaryCandidate = path.join(localAppData, 'Programs', 'Nuutapao Tools', 'Nuutapao Tools.exe');
    if (fs.existsSync(primaryCandidate)) {
      detectedExe = primaryCandidate;
    }

    // 2. Check other standard directories
    if (!detectedExe) {
      const otherCandidates = [
        path.join(programFiles, 'Nuutapao Tools', 'Nuutapao Tools.exe'),
        path.join(programFilesX86, 'Nuutapao Tools', 'Nuutapao Tools.exe'),
        'D:\\Nuutapao Tools\\Nuutapao Tools.exe',
        'D:\\Nuutapao Tools.exe'
      ];
      for (const cand of otherCandidates) {
        if (cand && fs.existsSync(cand)) {
          detectedExe = cand;
          break;
        }
      }
    }

    // 3. Check Windows Registry (HKCU and HKLM Uninstall keys)
    if (!detectedExe) {
      const regBases = [
        'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
        'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
        'HKLM\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall'
      ];

      for (const regBase of regBases) {
        try {
          const out = await new Promise((resolve) => {
            execFile('reg.exe', ['query', regBase, '/s', '/f', 'Nuutapao'], {
              encoding: 'utf8',
              timeout: 1500,
              windowsHide: true,
              maxBuffer: 4 * 1024 * 1024
            }, (error, stdout) => resolve(!error ? stdout : null));
          });
          if (!out) continue;

          const blocks = out.split(/\r?\n\r?\n/);
          for (const block of blocks) {
            if (/nuutapao/i.test(block)) {
              const locMatch = block.match(/InstallLocation\s+REG_\S+\s+(.+)/i);
              const uninstMatch = block.match(/UninstallString\s+REG_\S+\s+(.+)/i);
              const verMatch = block.match(/DisplayVersion\s+REG_\S+\s+(.+)/i);

              if (verMatch) detectedVersion = verMatch[1].trim();
              if (uninstMatch) uninstallCmd = uninstMatch[1].trim();

              if (!detectedExe && locMatch) {
                const cand = path.join(locMatch[1].trim(), 'Nuutapao Tools.exe');
                if (fs.existsSync(cand)) {
                  detectedExe = cand;
                  break;
                }
              }
              if (!detectedExe && uninstMatch) {
                const cleanU = uninstMatch[1].trim().replace(/^"([^"]+)".*$/, '$1').replace(/\s*\/.*$/, '');
                const cand = path.join(path.dirname(cleanU), 'Nuutapao Tools.exe');
                if (fs.existsSync(cand)) {
                  detectedExe = cand;
                  break;
                }
              }
            }
          }
        } catch (_) {}
        if (detectedExe) break;
      }
    }

    // If an installed executable actually exists on disk:
    if (detectedExe && fs.existsSync(detectedExe)) {
      const installDir = path.dirname(detectedExe);

      if (!uninstallCmd) {
        const candidateUninstallers = [
          path.join(installDir, 'Uninstall Nuutapao Tools.exe'),
          path.join(installDir, 'unins000.exe'),
          path.join(installDir, 'uninstall.exe')
        ];
        for (const u of candidateUninstallers) {
          if (fs.existsSync(u)) {
            uninstallCmd = `"${u}" /currentuser`;
            break;
          }
        }
      }

      return {
        installed: true,
        exePath: detectedExe,
        installPath: installDir,
        version: detectedVersion,
        uninstallString: uninstallCmd
      };
    }

    // Completely NOT installed!
    return {
      installed: false,
      exePath: null,
      installPath: path.join(localAppData, 'Programs', 'Nuutapao Tools'),
      version: null,
      uninstallString: null
    };
  }

  function readExecutableVersion(exePath) {
    if (!exePath) return Promise.resolve(null);
    const escapedExePath = exePath.replace(/'/g, "''");
    const script = `$v=(Get-Item -LiteralPath '${escapedExePath}').VersionInfo; if ($v.ProductVersion) { $v.ProductVersion } else { $v.FileVersion }`;
    return new Promise((resolve) => {
      execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
        encoding: 'utf8',
        timeout: 1500,
        windowsHide: true,
        maxBuffer: 1024 * 1024
      }, (error, stdout) => resolve(!error && stdout ? stdout.trim() || null : null));
    });
  }

  // Launch main tools program
  ipcMain.handle('hub-launch-tools', async () => {
    // First check if Nuutapao Tools is already running — if so, just bring it to front
    if (isProcessRunningAndFocus('Nuutapao Tools.exe')) {
      return { success: true, alreadyRunning: true, message: 'Nuutapao Tools is already running — brought to front.' };
    }

    const info = await detectInstalledNuutapaoTools();
    if (info.installed && info.exePath && fs.existsSync(info.exePath)) {
      const child = spawn(info.exePath, [], { detached: true, stdio: 'ignore' });
      child.unref();
      return { success: true, path: info.exePath };
    }

    // Direct check of standard directory locations
    const directCandidates = [
      path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Nuutapao Tools', 'Nuutapao Tools.exe'),
      path.join(process.env.ProgramFiles || '', 'Nuutapao Tools', 'Nuutapao Tools.exe'),
      path.join(process.env['ProgramFiles(x86)'] || '', 'Nuutapao Tools', 'Nuutapao Tools.exe')
    ];
    for (const cand of directCandidates) {
      if (cand && fs.existsSync(cand)) {
        const child = spawn(cand, [], { detached: true, stdio: 'ignore' });
        child.unref();
        return { success: true, path: cand };
      }
    }

    // In dev mode only (if unpacked build exists), fallback
    const devPath = path.join(__dirname, '..', 'dist', 'win-unpacked', 'Nuutapao Tools.exe');
    if (!app.isPackaged && fs.existsSync(devPath)) {
      const child = spawn(devPath, [], { detached: true, stdio: 'ignore' });
      child.unref();
      return { success: true, path: devPath, isDev: true };
    }

    // Self-healing fallback: Check if an installer already exists on disk
    const updateDir = path.join(process.env.LOCALAPPDATA || process.env.TEMP, 'Nuutapao Hub', 'updates');
    const installerCandidates = [
      path.join(updateDir, 'Nuutapao.Tools.Setup.4.76.0.exe'),
      path.join(updateDir, 'Nuutapao Tools Setup 4.76.0.exe'),
      path.join(__dirname, '..', 'dist', 'Nuutapao Tools Setup 4.76.0.exe'),
      path.join(__dirname, '..', 'dist', 'Nuutapao Tools Setup 4.1.0.exe'),
      path.join(__dirname, '..', 'dist', 'Nuutapao Tools Setup 4.0.0.exe'),
      path.join(__dirname, '..', 'dist', 'customsetup.exe')
    ];
    const foundInstaller = installerCandidates.find(p => p && fs.existsSync(p));
    if (foundInstaller) {
      try {
        const installResult = await executeSilentInstaller(foundInstaller, null, () => {});
        if (installResult && installResult.installed && installResult.exePath && fs.existsSync(installResult.exePath)) {
          const child = spawn(installResult.exePath, [], { detached: true, stdio: 'ignore' });
          child.unref();
          return { success: true, path: installResult.exePath, autoInstalled: true };
        }
      } catch (err) {
        console.error('Silent install during launch error:', err);
      }
    }

    return { success: false, notInstalled: true, message: 'Nuutapao Tools is not installed. Please install it first.' };
  });

  // Uninstall Nuutapao Tools
  ipcMain.handle('hub-uninstall-tools', async () => {
    const info = await detectInstalledNuutapaoTools();
    if (!info.installed && !fs.existsSync('D:\\Nuutapao Tools.exe')) {
      return { success: false, message: 'Nuutapao Tools is not currently installed.' };
    }

    // 1. Terminate any running process first
    try {
      execSync('taskkill /F /IM "Nuutapao Tools.exe" /T', { stdio: 'ignore' });
    } catch (_) {}

    // 2. Determine install location
    const installDir = info.installPath || 'D:\\';
    const isDriveRoot = !installDir || /^[A-Za-z]:\\?$/.test(installDir.trim());

    if (isDriveRoot) {
      // Safely delete only the specific application files to prevent drive wipe
      const files = [
        path.join(installDir, 'Nuutapao Tools.exe'),
        path.join(installDir, 'Uninstall Nuutapao Tools.exe'),
        path.join(installDir, 'uninstallerIcon.ico'),
        path.join(installDir, 'chrome_100_percent.pak'),
        path.join(installDir, 'chrome_200_percent.pak'),
        path.join(installDir, 'd3dcompiler_47.dll'),
        path.join(installDir, 'ffmpeg.dll'),
        path.join(installDir, 'icudtl.dat'),
        path.join(installDir, 'libEGL.dll'),
        path.join(installDir, 'libGLESv2.dll'),
        path.join(installDir, 'LICENSE.electron.txt'),
        path.join(installDir, 'LICENSES.chromium.html'),
        path.join(installDir, 'resources.pak'),
        path.join(installDir, 'snapshot_blob.bin'),
        path.join(installDir, 'v8_context_snapshot.bin'),
        path.join(installDir, 'vk_swiftshader.dll'),
        path.join(installDir, 'vk_swiftshader_icd.json'),
        path.join(installDir, 'vulkan-1.dll')
      ];
      for (const f of files) {
        try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch (_) {}
      }
      try { if (fs.existsSync(path.join(installDir, 'locales'))) fs.rmSync(path.join(installDir, 'locales'), { recursive: true, force: true }); } catch (_) {}
      try { if (fs.existsSync(path.join(installDir, 'resources'))) fs.rmSync(path.join(installDir, 'resources'), { recursive: true, force: true }); } catch (_) {}
    } else {
      // Standard directory install: delete the whole app directory
      try {
        if (fs.existsSync(installDir)) {
          fs.rmSync(installDir, { recursive: true, force: true });
        }
      } catch (_) {}
    }

    // 3. Remove shortcuts
    try {
      const special = getWindowsSpecialFolders();
      for (const d of special.desktops) {
        const sc = path.join(d, 'Nuutapao Tools.lnk');
        if (fs.existsSync(sc)) fs.unlinkSync(sc);
      }
      if (special.programs) {
        const sc = path.join(special.programs, 'Nuutapao Tools.lnk');
        if (fs.existsSync(sc)) fs.unlinkSync(sc);
      }
    } catch (_) {}

    // 4. Clean up registry uninstall keys
    const regKeys = [
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\c2108820-7680-50aa-b187-b9819aeb638f',
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\NuutapaoTools',
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\NuutapaoDownloader',
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Nuutapao Tools.exe',
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\nuutapao.exe'
    ];
    for (const k of regKeys) {
      try { execSync(`reg delete "${k}" /f`, { stdio: 'ignore' }); } catch (_) {}
    }

    return { success: true, message: 'Nuutapao Tools uninstalled successfully.' };
  });

  // Confirm dialog — native OS message box
  ipcMain.handle('hub-confirm-dialog', async (event, opts) => {
    const result = await dialog.showMessageBox(hubWindow, {
      type: 'warning',
      title: opts?.title || 'Confirm',
      message: opts?.message || 'Are you sure?',
      buttons: [opts?.cancelLabel || 'Cancel', opts?.okLabel || 'OK'],
      defaultId: 0,
      cancelId: 0
    });
    return result.response === 1;
  });

  // Select install directory — native dialog
  ipcMain.handle('hub-select-dir', async (event, currentPath) => {
    const result = await dialog.showOpenDialog(hubWindow, {
      title: 'Select Destination Directory',
      defaultPath: currentPath || 'C:\\Program Files\\Nuutapao Tools',
      properties: ['openDirectory', 'createDirectory']
    });

    if (!result.canceled && result.filePaths.length > 0) {
      return ensureNuutapaoSubfolder(result.filePaths[0]);
    }
    return null;
  });

  // Provide system/version info to renderer
  ipcMain.handle('hub-system-info', async () => {
    const info = await detectInstalledNuutapaoTools();
    return {
      installed: info.installed,
      installPath: info.installPath,
      installedVersion: await readExecutableVersion(info.exePath) || info.version,
      canUninstall: !!info.uninstallString,
      platform: process.platform,
      arch: process.arch
    };
  });

  function isOfficialReleaseDownload(downloadUrl) {
    try {
      const url = new URL(downloadUrl);
      return url.protocol === 'https:' &&
        url.hostname === 'github.com' &&
        /^\/J1R4T\/Nuutapao-Tools\/releases\/download\//i.test(url.pathname);
    } catch {
      return false;
    }
  }

  // Check for updates on GitHub Releases — selects latest version first
  ipcMain.handle('hub-check-github-updates', async () => {
    const info = await detectInstalledNuutapaoTools();
    const installed = info.installed;
    const installedVer = await readExecutableVersion(info.exePath) || info.version;
    const latestUrl = 'https://api.github.com/repos/J1R4T/Nuutapao-Tools/releases/latest';
    const allReleasesUrl = 'https://api.github.com/repos/J1R4T/Nuutapao-Tools/releases';

    let bestRelease = null;
    let bestAsset = null;
    let bestVersionStr = null;

    // 1. Try official /releases/latest endpoint first (chooses the latest release first)
    try {
      const resLatest = await fetch(latestUrl, {
        headers: {
          'User-Agent': 'Nuutapao-Hub',
          'Accept': 'application/vnd.github.v3+json'
        }
      });

      if (resLatest.ok) {
        const latestRel = await resLatest.json();
        const candidate = getInstallableRelease(latestRel);
        if (candidate) {
          bestRelease = candidate.release;
          bestAsset = candidate.asset;
          bestVersionStr = candidate.version;
        } else if ((latestRel.assets || []).some(isToolsSetupAsset)) {
          console.warn('Ignoring latest release because its tag and setup asset versions do not match.');
        }
      }
    } catch (e) {
      console.warn('Could not fetch /releases/latest directly:', e.message);
    }

    // 2. If latest endpoint did not yield an executable, scan all releases
    if (!bestRelease || !bestAsset) {
      try {
        const resAll = await fetch(allReleasesUrl, {
          headers: {
            'User-Agent': 'Nuutapao-Hub',
            'Accept': 'application/vnd.github.v3+json'
          }
        });

        if (resAll.ok) {
          const releases = await resAll.json();
          if (Array.isArray(releases) && releases.length > 0) {
            let bestVerTuple = [0, 0, 0];
            let bestDate = 0;

            for (const rel of releases) {
              if (rel.draft) continue;
              const candidate = getInstallableRelease(rel);
              if (!candidate) continue;

              const verTuple = candidate.version;
              const relDate = new Date(rel.published_at || 0).getTime();
              const cmp = compareSemver(verTuple, bestVerTuple);

              // Choose the highest semver, or most recently published if equal
              if (cmp > 0 || (cmp === 0 && relDate > bestDate)) {
                bestVerTuple = verTuple;
                bestDate = relDate;
                bestRelease = candidate.release;
                bestAsset = candidate.asset;
                bestVersionStr = verTuple;
              }
            }
          }
        }
      } catch (err) {
        console.warn('Error fetching all releases:', err.message);
      }
    }

    // 3. If still no release found, fallback cleanly
    if (!bestRelease || !bestAsset) {
      return {
        success: true,
        installed: installed,
        installedVersion: installedVer ? (installedVer.startsWith('v') ? installedVer : 'v' + installedVer) : null,
        latestVersion: null,
        hasUpdate: false,
        needsInstall: !installed,
        message: 'No executable release found on GitHub.'
      };
    }

    const hasUpdate = installed && (!installedVer || compareSemver(bestVersionStr, installedVer) > 0);
    const needsInstall = !installed;

    return {
      success: true,
      installed: installed,
      hasUpdate,
      needsInstall,
      installedVersion: installedVer ? (installedVer.startsWith('v') ? installedVer : 'v' + installedVer) : null,
      latestVersion: 'v' + bestVersionStr,
      releaseTag: bestRelease.tag_name,
      releaseName: bestRelease.name || bestRelease.tag_name,
      releaseDate: bestRelease.published_at,
      releaseNotes: bestRelease.body || 'No release notes provided.',
      assetName: bestAsset.name,
      assetSize: bestAsset.size,
      downloadUrl: bestAsset.browser_download_url,
      htmlUrl: bestRelease.html_url
    };
  });

  // Download & Install update from GitHub release asset directly on Hub
  ipcMain.handle('hub-download-and-install-update', async (event, { downloadUrl, assetName, installDir }) => {
    const sendLog = (msg) => {
      try {
        event.sender.send('hub-install-log', msg);
      } catch (_) {}
    };

    const localInstallers = [
      path.join(__dirname, '..', 'dist', 'Nuutapao Tools Setup 4.76.0.exe'),
      path.join(__dirname, '..', 'dist', 'Nuutapao Tools Setup 4.1.0.exe'),
      path.join(__dirname, '..', 'dist', 'Nuutapao Tools Setup 4.0.0.exe'),
      path.join(__dirname, '..', 'dist', 'customsetup.exe')
    ];
    const existingLocalInstaller = localInstallers.find(p => fs.existsSync(p));

    if (!downloadUrl && existingLocalInstaller) {
      // Local fallback for offline/development installation (silent, no wizard)
      return await executeSilentInstaller(existingLocalInstaller, installDir, sendLog);
    }

    if (!downloadUrl) throw new Error('No download URL provided and no local installer found.');
    if (!isOfficialReleaseDownload(downloadUrl)) {
      throw new Error('The update source is not an official Nuutapao Tools GitHub release.');
    }

    const updateDir = path.join(process.env.LOCALAPPDATA || process.env.TEMP, 'Nuutapao Hub', 'updates');
    if (!fs.existsSync(updateDir)) {
      fs.mkdirSync(updateDir, { recursive: true });
    }

    const fileName = path.basename(String(assetName || 'Nuutapao_Tools_Update.exe'));
    if (!isToolsSetupAsset({ name: fileName })) {
      throw new Error('The selected update is not a Nuutapao Tools setup executable.');
    }
    const targetPath = path.join(updateDir, fileName);
    const partialPath = `${targetPath}.part`;

    try {
      const res = await fetch(downloadUrl, {
        headers: { 'User-Agent': 'Nuutapao-Hub' },
        redirect: 'follow'
      });

      if (!res.ok) {
        if (existingLocalInstaller) {
          return await executeSilentInstaller(existingLocalInstaller, installDir, sendLog);
        }
        throw new Error(`HTTP ${res.status}: Failed to download update file`);
      }

      const totalBytes = parseInt(res.headers.get('content-length') || '0', 10);
      const fileStream = fs.createWriteStream(partialPath);
      let streamError = null;
      fileStream.on('error', (error) => { streamError = error; });

      let downloadedBytes = 0;
      let lastTime = Date.now();
      let bytesSinceLast = 0;
      let currentSpeedMBps = '0.0';

      const reader = res.body.getReader();

      while (true) {
        if (streamError) throw streamError;
        const { done, value } = await reader.read();
        if (done) break;

        downloadedBytes += value.length;
        bytesSinceLast += value.length;
        if (!fileStream.write(Buffer.from(value))) {
          await new Promise((resolve, reject) => {
            fileStream.once('drain', resolve);
            fileStream.once('error', reject);
          });
        }

        const now = Date.now();
        const elapsed = (now - lastTime) / 1000;
        if (elapsed >= 0.2) {
          const speed = (bytesSinceLast / (1024 * 1024)) / elapsed;
          currentSpeedMBps = speed.toFixed(1);
          lastTime = now;
          bytesSinceLast = 0;

          const percent = totalBytes > 0 ? Math.min(100, (downloadedBytes / totalBytes) * 100) : 0;
          const downloadedMB = (downloadedBytes / (1024 * 1024)).toFixed(1);
          const totalMB = (totalBytes / (1024 * 1024)).toFixed(1);

          event.sender.send('hub-download-progress', {
            percent,
            downloadedMB,
            totalMB,
            speedMBps: currentSpeedMBps,
            downloadedBytes,
            totalBytes
          });
        }
      }

      await new Promise((resolve, reject) => {
        if (streamError) return reject(streamError);
        fileStream.once('error', reject);
        fileStream.end(resolve);
      });
      fs.renameSync(partialPath, targetPath);

      // Send 100% completion event
      event.sender.send('hub-download-progress', {
        percent: 100,
        downloadedMB: (downloadedBytes / (1024 * 1024)).toFixed(1),
        totalMB: (totalBytes / (1024 * 1024)).toFixed(1),
        speedMBps: 'Installing...',
        downloadedBytes,
        totalBytes
      });

      // Execute silently directly on Nuutapao Hub (no wizard, auto-creates desktop & start menu shortcuts)
      return await executeSilentInstaller(targetPath, installDir, sendLog);
    } catch (err) {
      try { if (fs.existsSync(partialPath)) fs.unlinkSync(partialPath); } catch (_) {}
      if (existingLocalInstaller) {
        return await executeSilentInstaller(existingLocalInstaller, installDir, sendLog);
      }
      throw err;
    }
  });

  // Safely open external link
  ipcMain.handle('hub-open-external', async (event, url) => {
    if (url && (url.startsWith('https://') || url.startsWith('http://'))) {
      shell.openExternal(url);
      return true;
    }
    return false;
  });

} // end single-instance else block
