/* ===== Nuutapao Downloader — Frontend Logic ===== */

// ── i18n Translations ──────────────────────────────────────────────────────
const translations = {
  en: {
    appNameShort: 'Nuutapao',
    appNameSub: 'Tools V.4.76',
    navHome: 'Home',
    navClipper: 'Clipper',
    navConverter: 'Converter',
    navQr: 'QR Maker',
    navHistory: 'History',
    navSettings: 'Settings',
    navAbout: 'About',
    headerDesc: 'Download videos from any platform easily!',
    clipperTitle: '✂️ Video & Stream Clipper',
    clipperDesc: 'Trim and download exact sections from YouTube videos and Live streams in any quality.',
    clipperUrlPlaceholder: 'Paste YouTube video or Live stream link to trim...',
    btnFetchInfo: 'Load Video',
    labelTimeRange: '⏱️ Select Time Range',
    labelClipDuration: 'Clip Length:',
    labelStartTime: 'Start Time',
    labelEndTime: 'End Time',
    labelPresets: 'Quick Jumps:',
    presetFull: 'Full Video',
    btnTrimDownload: 'Trim & Download Clip',
    toastLoadingInfo: 'Loading video info... ⏳',
    toastInfoLoaded: 'Video loaded! Set your time range ✨',
    toastInvalidTime: 'End time must be greater than start time!',
    toastClipStarted: 'Clip download started! 🚀',
    converterTitle: '🔄 File Converter',
    converterDesc: 'Convert video, audio, and image files to any format with ease.',
    converterDropTitle: 'Drag & drop files here',
    converterDropSub: 'or click to browse files',
    converterScan: 'Scan file format',
    converterScanHint: 'File formats are scanned automatically when files are added.',
    converterScanNone: 'Add a file first to scan its format.',
    converterScanComplete: 'Scan complete',
    converterTypeImage: 'Picture',
    converterTypeVideo: 'Video',
    converterTypeAudio: 'Audio',
    converterEmpty: 'Add files to start converting',
    converterStartAll: 'Convert All',
    converterConverting: 'Converting...',
    converterDone: 'Done!',
    converterOpenFolder: 'Open folder',
    converterError: 'Error',
    converterCancelled: 'Cancelled',
    toastConvertStarted: 'Conversion started! 🔄',
    toastConvertDone: 'Conversion complete! ✅',
    toastConvertError: 'Conversion failed ❌',
    toastFilesAdded: 'Files added! 📂',
    qrTitle: '▣ QR Maker',
    qrDesc: 'Create a scan-ready QR code from any link.',
    qrLinkLabel: 'Link to encode',
    qrLinkPlaceholder: 'Paste a link, email, phone number, or app link...',
    qrGenerate: 'Generate',
    qrSizeLabel: 'QR size',
    qrSizeSmall: 'Small',
    qrSizeMedium: 'Medium',
    qrSizeLarge: 'Large',
    qrEmpty: 'Your QR code will appear here.',
    qrCopy: 'Copy image',
    qrSave: 'Save PNG',
    toastQrGenerated: 'QR code generated! ✨',
    toastQrLinkRequired: 'Please paste a link first.',
    toastQrCopied: 'QR image copied to clipboard!',
    toastQrSaved: 'QR image saved!',
    toastQrCopyUnavailable: 'Image copy is only available in the desktop app.',
    qualityHigh: 'High',
    qualityMedium: 'Medium',
    qualityLow: 'Low',
    urlPlaceholder: 'Paste any video link here (YouTube, TikTok, IG, X...)',
    btnDownload: 'Download',
    labelFormat: 'Format',
    labelQuality: 'Quality',
    qualityBest: 'Best Available (Auto)',
    labelSaveTo: 'Save to',
    btnBrowse: 'Browse',
    labelThumbnail: 'Thumbnail',
    recentTitle: '🕒 Recent Downloads',
    btnClearAll: 'Clear All',
    emptyRecent: 'No downloads yet. Paste a link to get started!',
    historyTitle: '🕒 Download History',
    historyDesc: 'Browse through your complete list of previously downloaded media.',
    historySearchPlaceholder: 'Search history...',
    emptyHistory: 'No download history available yet.',
    settingsTitle: '⚙️ Settings',
    settingsDesc: 'Configure Nuutapao Tools preferences and customize your media experience.',
    settingsAppearance: '🎨 Appearance',
    settingDarkTheme: 'Dark Theme',
    settingDarkThemeDesc: 'Switch between light and dark modes',
    settingZoomLevel: 'Zoom Level',
    settingZoomLevelDesc: 'Adjust the interface size',
    settingsLanguage: '🌐 Language',
    settingLanguageTitle: 'Interface Language',
    settingLanguageDesc: 'Choose the language for the interface',
    settingsHistoryMgmt: '📋 History Management',
    settingAutoDeleteTitle: 'Auto-delete History',
    settingAutoDeleteDesc: 'Automatically remove history older than selected days',
    autoDeleteNever: 'Never',
    autoDelete1: 'After 1 day',
    autoDelete3: 'After 3 days',
    autoDelete7: 'After 7 days',
    autoDelete14: 'After 14 days',
    autoDelete30: 'After 30 days',
    settingClearAllTitle: 'Clear All History',
    settingClearAllDesc: 'Remove all download history records permanently',
    btnDeleteAll: '🗑️ Delete All',
    settingsWindow: '🖥️ Application Window',
    settingAlwaysOnTop: 'Always on Top',
    settingAlwaysOnTopDesc: 'Keep Nuutapao Tools window above all other windows',
    settingRunInBackground: 'Run in Background',
    settingRunInBackgroundDesc: 'Keep running in system tray when closed so downloads continue',
    settingStartMinimized: 'Start Minimized',
    settingStartMinimizedDesc: 'Open directly in the system tray when the app starts',
    settingOpenOnStartup: 'Open on startup',
    settingOpenOnStartupDesc: 'Launch automatically when you sign in to your computer',
    statusLiveRecording: '🔴 Recording Live (auto-finishes on stream end)',
    settingsCookies: '🍪 Cookies',
    settingsCookiesDesc: 'Use cookies from a signed-in account with access permissions to download private videos, age-restricted contents, or member-only videos.',
    settingCookieSource: 'Cookies Source',
    settingCookieSourceDesc: 'Choose whether to use browser cookies, custom file, or none',
    cookieNone: 'None (No cookies)',
    cookieBrowser: 'Use Browser Cookies',
    cookieFile: 'Use cookies.txt File',
    settingSelectBrowser: 'Select Browser',
    settingSelectBrowserDesc: 'yt-dlp will import cookies from the selected browser',
    settingCookieFilePath: 'Cookies File Path',
    settingCookieFilePathDesc: 'Select your custom cookies.txt file',
    browserCookieTipText: '<b>Browser Tip:</b> If downloading age-restricted videos, make sure your browser is completely closed or use a <code>cookies.txt</code> file to avoid database locking.',
    fileCookieTipText: '<b>Tip:</b> Export a Netscape-format cookies.txt while signed in to YouTube. Age-restricted videos require an account that can already watch them, and cookies expire, so refresh the file when needed.',
    aboutTitle: '🦊 About Nuutapao Tools™',
    aboutSubtitle: 'Sleek, adorable, and powerful media tools for yt-dlp & FFmpeg.',
    aboutDesc: 'This app was created by Nuutapao and is exclusively for Nuutapao.',
    followTitle: '✨ Follow me :',
    featureUltraFast: 'Ultra Fast Downloads',
    featureUltraFastDesc: 'Spawns highly-optimized multi-threaded yt-dlp processes.',
    featureAesthetics: 'Tailored Aesthetics',
    featureAestheticsDesc: 'Support for Light/Dark themes and interactive visual responses.',
    featureCookie: 'Secure Cookie Handling',
    featureCookieDesc: 'Supports importing cookies directly from browsers or using Netscape format cookies files.',
    btnCancel: 'Cancel',
    btnConfirm: 'Confirm',
    toastDownloadStarted: 'Download started! 🚀',
    toastPasteLink: 'Please paste a video link first! 💖',
    platformOther: 'Other',
    toastCancelled: 'Cancelled',
    toastCannotBrowse: 'Cannot open folder browser',
    toastCannotBrowseCookie: 'Cannot browse for cookies file',
    toastHistoryCleared: 'All history cleared! 🧹',
    settingsEngine: '🚀 Downloader Engine (yt-dlp)',
    settingsEngineDesc: 'yt-dlp handles video extraction. Keeps itself updated automatically to fix website changes.',
    btnUpdateEngine: 'Update Engine',
    toastYtdlpUpdated: 'yt-dlp updated to the latest version! ✨',
    toastYtdlpUpToDate: 'yt-dlp is already up to date! ✅',
    toastItemDeleted: 'Item removed from history',
    toastRedownloadStarted: 'Re-download started! 🔄',
    confirmClearTitle: 'Clear All History?',
    confirmClearDesc: 'This will permanently delete all your download history records. This action cannot be undone.',
    confirmDeleteTitle: 'Delete this item?',
    confirmDeleteDesc: 'This record will be permanently removed from your history.',
    statusCompleted: 'Completed',
    statusError: 'Error',
    settingsDns: '🔒 Secure DNS (DoH)',
    settingsDnsDesc: 'Use Secure DNS (DoH) to resolve domains and bypass ISP domain blocks. Note: Secure DNS cannot bypass region-locked content.',
    settingEnableDns: 'Use Secure DNS (DoH)',
    settingEnableDnsDesc: 'Encrypt and resolve DNS queries via Cloudflare, Google, or OpenDNS',
    settingSelectDnsProvider: 'Select DNS provider',
    settingSelectDnsProviderDesc: 'Choose a secure DNS-over-HTTPS provider',
    settingCustomDnsUrl: 'Custom DoH Provider URL',
    settingCustomDnsUrlDesc: 'Format: https://dns.example.com/dns-query',
    customDnsPlaceholder: 'https://1.1.1.1/dns-query',
    settingsProxy: '🌐 Network Proxy & VPN',
    settingsProxyDesc: 'Route downloads through a permitted proxy or VPN to bypass network restrictions or access region-locked content in supported regions.',
    settingEnableProxy: 'Enable Network Proxy / Bypass',
    settingEnableProxyDesc: 'Route downloads through Proxy or Local Server',
    settingProxyPreset: 'Proxy Preset',
    settingProxyPresetDesc: 'Select a pre-configured local proxy server or custom URL',
    settingProxyUrl: 'Custom Proxy Server URL',
    settingProxyUrlDesc: 'Format: http://127.0.0.1:1080 or socks5://127.0.0.1:10808',
    proxyPlaceholder: 'e.g. http://127.0.0.1:1080 or socks5://127.0.0.1:10808',
    proxyNoticeText: 'Select a Proxy preset above or use Cloudflare WARP/VPN to route traffic or bypass network restrictions.',
    settingsRestore: '🔄 Restore to Default',
    settingRestoreTitle: 'Reset All Settings',
    settingRestoreDesc: 'Reset all settings, download preferences, and history to factory defaults. This cannot be undone.',
    btnRestoreDefaults: 'Restore Defaults',
    confirmRestoreTitle: 'Restore to Default?',
    confirmRestoreDesc: 'This will reset ALL settings, download preferences, and history to factory defaults. This action cannot be undone.',
    toastRestoredDefaults: 'All settings restored to defaults! ✨',
    navAssets: 'Assets Finder',
    assetsTitle: '🖼️ Assets Finder',
    assetsDesc: 'Search and download free high-quality images and GIFs from Google and across the web.',
    assetsSearchPlaceholder: 'Search images, GIFs, aesthetics, wallpapers...',
    assetsSearchBtn: 'Search',
    assetsFindMore: 'Find More',
    assetsVisualDropTitle: 'Drag & drop an image here',
    assetsVisualBrowse: 'or click to browse files',
    assetsVisualHint: 'Paste an image with Ctrl+V. Image is sent to Google Lens for visual search.',
    assetsVisualSearching: 'Looking for similar images…',
    assetsSimilarCount: '{count} similar images',
    assetsFilterPhotos: 'Photos',
    assetsForYou: 'For You',
    assetsForYouSub: 'Inspired by your interests',
    assetsRefreshFeed: 'Shuffle',
    assetsEmptyState: 'Search for something to discover amazing assets!',
    assetsLoadMore: 'Load More',
    assetsDownloadBtn: 'Download',
    assetsDownloading: 'Downloading...',
    assetsDownloaded: 'Saved to Downloads! ✨',
    assetsDownloadError: 'Download failed ❌',
    assetsSearching: 'Searching...',
    assetsNoResults: 'No results found. Try a different search term!',
    assetsResultsCount: '{count} results found',
    settingsAssetsApi: '🖼️ Assets Finder API Keys (Optional)',
    settingPixabayKey: 'Pixabay API Key',
    settingPixabayKeyDesc: 'Optional — Google Search works with no key. For Pixabay: sign up on pixabay.com/api/docs',
    settingGiphyKey: 'Giphy API Key',
    settingGiphyKeyDesc: 'Optional — Google Search works with no key. For Giphy: developers.giphy.com',
    assetsSetupTitle: 'Set Up API Keys',
    assetsSetupDesc: 'To use Pixabay or Giphy directly, you can provide free keys, or simply use Google search with zero setup!',
    assetsSetupPixabayStep: 'Go to <a href="https://pixabay.com/api/docs/" target="_blank">pixabay.com/api/docs</a> → Sign up → Your key appears on the page',
    assetsSetupGiphyStep: 'Go to <a href="https://developers.giphy.com/" target="_blank">developers.giphy.com</a> → Create App → Copy API key',
    assetsSetupSettingsStep: 'Paste your keys in Settings → Assets Finder API Keys',
    assetsGoSettings: 'Go to Settings',
    settingsSound: '🔊 Sound Effects (SFX)',
    settingsSoundDesc: 'Play cute and satisfying sound effects for clicks, tab navigation, and downloads.',
    settingSoundEnabled: 'Enable SFX',
    settingSoundEnabledDesc: 'Turn audio sound effects on or off',
    settingSoundVolume: 'SFX Volume',
    btnTestSound: 'Test',
  },
  th: {
    appNameShort: 'Nuutapao',
    appNameSub: 'Tools V.4.76',
    navHome: 'หน้าหลัก',
    navClipper: 'ตัดคลิป',
    navConverter: 'ตัวแปลงไฟล์',
    navQr: 'สร้าง QR',
    navHistory: 'ประวัติ',
    navSettings: 'ตั้งค่า',
    navAbout: 'เกี่ยวกับ',
    headerDesc: 'ดาวน์โหลดวิดีโอจากทุกแพลตฟอร์มได้ง่ายๆ!',
    clipperTitle: '✂️ ตัดคลิปวิดีโอและไลฟ์สตรีม',
    clipperDesc: 'ตัดและดาวน์โหลดเฉพาะช่วงเวลาที่ต้องการจากวิดีโอหรือไลฟ์สตรีม YouTube ได้ทุกความละเอียด',
    clipperUrlPlaceholder: 'วางลิงก์วิดีโอหรือไลฟ์สตรีม YouTube ที่ต้องการตัด...',
    btnFetchInfo: 'โหลดข้อมูล',
    labelTimeRange: '⏱️ เลือกช่วงเวลาที่ต้องการตัด',
    labelClipDuration: 'ความยาวคลิป:',
    labelStartTime: 'เวลาเริ่มต้น',
    labelEndTime: 'เวลาสิ้นสุด',
    labelPresets: 'เลือกช่วงเร็ว:',
    presetFull: 'ทั้งวิดีโอ',
    btnTrimDownload: 'ตัดและดาวน์โหลดคลิป',
    toastLoadingInfo: 'กำลังโหลดข้อมูลวิดีโอ... ⏳',
    toastInfoLoaded: 'โหลดข้อมูลวิดีโอสำเร็จ! เลือกช่วงเวลาได้เลย ✨',
    toastInvalidTime: 'เวลาสิ้นสุดต้องมากกว่าเวลาเริ่มต้น!',
    toastClipStarted: 'เริ่มดาวน์โหลดคลิปแล้ว! 🚀',
    converterTitle: '🔄 ตัวแปลงไฟล์',
    converterDesc: 'แปลงไฟล์วิดีโอ เสียง และรูปภาพเป็นทุกนามสกุลได้ง่ายๆ',
    converterDropTitle: 'ลากไฟล์มาวางที่นี่',
    converterDropSub: 'หรือคลิกเพื่อเลือกไฟล์',
    converterScan: '\u0e15\u0e23\u0e27\u0e08\u0e2a\u0e2d\u0e1a\u0e23\u0e39\u0e1b\u0e41\u0e1a\u0e1a\u0e44\u0e1f\u0e25\u0e4c',
    converterScanHint: '\u0e23\u0e30\u0e1a\u0e1a\u0e08\u0e30\u0e2a\u0e41\u0e01\u0e19\u0e23\u0e39\u0e1b\u0e41\u0e1a\u0e1a\u0e44\u0e1f\u0e25\u0e4c\u0e2d\u0e31\u0e15\u0e42\u0e19\u0e21\u0e31\u0e15\u0e34\u0e40\u0e21\u0e37\u0e48\u0e2d\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e44\u0e1f\u0e25\u0e4c',
    converterScanNone: '\u0e01\u0e23\u0e38\u0e13\u0e32\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e44\u0e1f\u0e25\u0e4c\u0e01\u0e48\u0e2d\u0e19\u0e2a\u0e41\u0e01\u0e19',
    converterScanComplete: '\u0e2a\u0e41\u0e01\u0e19\u0e40\u0e2a\u0e23\u0e47\u0e08\u0e2a\u0e34\u0e49\u0e19',
    converterTypeImage: '\u0e23\u0e39\u0e1b\u0e20\u0e32\u0e1e',
    converterTypeVideo: '\u0e27\u0e34\u0e14\u0e35\u0e42\u0e2d',
    converterTypeAudio: '\u0e40\u0e2a\u0e35\u0e22\u0e07',
    converterEmpty: 'เพิ่มไฟล์เพื่อเริ่มแปลง',
    converterStartAll: 'แปลงทั้งหมด',
    converterConverting: 'กำลังแปลง...',
    converterDone: 'เสร็จสิ้น!',
    converterOpenFolder: 'เปิดโฟลเดอร์',
    converterError: 'ผิดพลาด',
    converterCancelled: 'ยกเลิกแล้ว',
    toastConvertStarted: 'เริ่มแปลงไฟล์แล้ว! 🔄',
    toastConvertDone: 'แปลงไฟล์เสร็จสิ้น! ✅',
    toastConvertError: 'แปลงไฟล์ล้มเหลว ❌',
    toastFilesAdded: 'เพิ่มไฟล์แล้ว! 📂',
    qrTitle: '▣ สร้าง QR Code',
    qrDesc: 'สร้าง QR Code พร้อมสแกนจากลิงก์ใดก็ได้',
    qrLinkLabel: 'ลิงก์ที่ต้องการเข้ารหัส',
    qrLinkPlaceholder: 'วางลิงก์ อีเมล เบอร์โทรศัพท์ หรือลิงก์แอป...',
    qrGenerate: 'สร้าง QR',
    qrSizeLabel: 'ขนาด QR',
    qrSizeSmall: 'เล็ก',
    qrSizeMedium: 'กลาง',
    qrSizeLarge: 'ใหญ่',
    qrEmpty: 'QR Code ของคุณจะแสดงที่นี่',
    qrCopy: 'คัดลอกรูปภาพ',
    qrSave: 'บันทึก PNG',
    toastQrGenerated: 'สร้าง QR Code แล้ว! ✨',
    toastQrLinkRequired: 'กรุณาวางลิงก์ก่อน',
    toastQrCopied: 'คัดลอก QR ไปยังคลิปบอร์ดแล้ว!',
    toastQrSaved: 'บันทึกรูป QR แล้ว!',
    toastQrCopyUnavailable: 'คัดลอกรูปภาพได้เฉพาะในแอปเดสก์ท็อป',
    qualityHigh: 'สูง',
    qualityMedium: 'กลาง',
    qualityLow: 'ต่ำ',
    urlPlaceholder: 'วางลิงก์วิดีโอที่นี่ (YouTube, TikTok, IG, X...)',
    btnDownload: 'ดาวน์โหลด',
    labelFormat: 'รูปแบบ',
    labelQuality: 'คุณภาพ',
    qualityBest: 'ดีที่สุด (อัตโนมัติ)',
    labelSaveTo: 'บันทึกไปที่',
    btnBrowse: 'เลือก',
    labelThumbnail: 'ภาพปก',
    recentTitle: '🕒 ดาวน์โหลดล่าสุด',
    btnClearAll: 'ล้างทั้งหมด',
    emptyRecent: 'ยังไม่มีรายการดาวน์โหลด วางลิงก์เพื่อเริ่มต้น!',
    historyTitle: '🕒 ประวัติการดาวน์โหลด',
    historyDesc: 'ดูรายการสื่อที่ดาวน์โหลดก่อนหน้าทั้งหมดของคุณ',
    historySearchPlaceholder: 'ค้นหาประวัติ...',
    emptyHistory: 'ยังไม่มีประวัติการดาวน์โหลด',
    settingsTitle: '⚙️ ตั้งค่า',
    settingsDesc: 'ปรับแต่งการตั้งค่า Nuutapao Tools ตามความต้องการของคุณ',
    settingsAppearance: '🎨 ธีม',
    settingDarkTheme: 'ธีมมืด',
    settingDarkThemeDesc: 'สลับระหว่างโหมดสว่างและมืด',
    settingZoomLevel: 'ระดับการซูม',
    settingZoomLevelDesc: 'ปรับขนาดการแสดงผลของหน้าจอแอป',
    settingsLanguage: '🌐 ภาษา',
    settingLanguageTitle: 'ภาษาของแอป',
    settingLanguageDesc: 'เลือกภาษาสำหรับหน้าจอการใช้งาน',
    settingsHistoryMgmt: '📋 จัดการประวัติ',
    settingAutoDeleteTitle: 'ลบประวัติอัตโนมัติ',
    settingAutoDeleteDesc: 'ลบประวัติที่เก่ากว่าจำนวนวันที่เลือกโดยอัตโนมัติ',
    autoDeleteNever: 'ไม่เลย',
    autoDelete1: 'หลังจาก 1 วัน',
    autoDelete3: 'หลังจาก 3 วัน',
    autoDelete7: 'หลังจาก 7 วัน',
    autoDelete14: 'หลังจาก 14 วัน',
    autoDelete30: 'หลังจาก 30 วัน',
    settingClearAllTitle: 'ล้างประวัติทั้งหมด',
    settingClearAllDesc: 'ลบประวัติการดาวน์โหลดทั้งหมดอย่างถาวร',
    btnDeleteAll: '🗑️ ลบทั้งหมด',
    settingsWindow: '🖥️ หน้าต่างแอป',
    settingAlwaysOnTop: 'อยู่ด้านบนเสมอ',
    settingAlwaysOnTopDesc: 'ให้หน้าต่าง Nuutapao Tools อยู่เหนือหน้าต่างอื่นทั้งหมด',
    settingRunInBackground: 'ทำงานในพื้นหลัง',
    settingRunInBackgroundDesc: 'ทำงานต่อใน System Tray เมื่อปิดหน้าต่างเพื่อให้ดาวน์โหลดต่อได้',
    settingStartMinimized: 'เริ่มต้นแบบย่อหน้าต่าง',
    settingStartMinimizedDesc: 'เปิดแอปไว้ใน System Tray เมื่อเริ่มต้น',
    settingOpenOnStartup: 'เปิดแอปเมื่อเริ่มต้นระบบ',
    settingOpenOnStartupDesc: 'เปิดแอปอัตโนมัติเมื่อคุณลงชื่อเข้าใช้คอมพิวเตอร์',
    statusLiveRecording: '🔴 กำลังบันทึกการถ่ายทอดสด (เสร็จสิ้นอัตโนมัติเมื่อจบสตรีม)',
    settingsCookies: '🍪 คุกกี้',
    settingsCookiesDesc: 'ใช้คุกกี้จากบัญชีที่มีสิทธิ์เข้าถึง เพื่อดาวน์โหลดวิดีโอส่วนตัว วิดีโอที่จำกัดอายุ หรือวิดีโอสำหรับสมาชิก',
    settingCookieSource: 'แหล่งที่มาของคุกกี้',
    settingCookieSourceDesc: 'เลือกว่าจะใช้คุกกี้จากเบราว์เซอร์ ไฟล์ หรือไม่ใช้',
    cookieNone: 'ไม่ใช้ (ไม่มีคุกกี้)',
    cookieBrowser: 'ใช้คุกกี้จากเบราว์เซอร์',
    cookieFile: 'ใช้ไฟล์ cookies.txt',
    settingSelectBrowser: 'เลือกเบราว์เซอร์',
    settingSelectBrowserDesc: 'yt-dlp จะนำเข้าคุกกี้จากเบราว์เซอร์ที่เลือก',
    settingCookieFilePath: 'พาธไฟล์คุกกี้',
    settingCookieFilePathDesc: 'เลือกไฟล์ cookies.txt ของคุณ',
    browserCookieTipText: '<b>คำแนะนำเบราว์เซอร์:</b> สำหรับวิดีโอจำกัดอายุ กรุณาปิดเบราว์เซอร์ให้สนิทก่อนดาวน์โหลด หรือใช้ไฟล์ <code>cookies.txt</code> เพื่อป้องกันฐานข้อมูลถูกล็อก',
    fileCookieTipText: '<b>คำแนะนำ:</b> ส่งออกไฟล์ cookies.txt รูปแบบ Netscape ขณะลงชื่อเข้าใช้ YouTube วิดีโอจำกัดอายุต้องใช้บัญชีที่ดูวิดีโอนั้นได้อยู่แล้ว และคุกกี้หมดอายุได้ จึงควรส่งออกไฟล์ใหม่เมื่อจำเป็น',
    aboutTitle: '🦊 เกี่ยวกับ Nuutapao Tools™',
    aboutSubtitle: 'สวยงาม น่ารัก และทรงพลัง สำหรับ yt-dlp & FFmpeg',
    aboutDesc: 'This app was created by Nuutapao and is exclusively for Nuutapao.',
    followTitle: '✨ Follow me :',
    featureUltraFast: 'ดาวน์โหลดเร็วสุดๆ',
    featureUltraFastDesc: 'เรียกใช้กระบวนการ yt-dlp แบบ multi-threaded ที่ปรับแต่งมาอย่างดี',
    featureAesthetics: 'ธีมสวยงาม',
    featureAestheticsDesc: 'รองรับธีมสว่าง/มืด และการตอบสนองทางภาพแบบโต้ตอบ',
    featureCookie: 'จัดการคุกกี้อย่างปลอดภัย',
    featureCookieDesc: 'รองรับการนำเข้าคุกกี้โดยตรงจากเบราว์เซอร์ หรือใช้ไฟล์คุกกี้รูปแบบ Netscape',
    btnCancel: 'ยกเลิก',
    btnConfirm: 'ยืนยัน',
    toastDownloadStarted: 'เริ่มดาวน์โหลดแล้ว! 🚀',
    toastPasteLink: 'กรุณาวางลิงก์วิดีโอก่อน! 💖',
    platformOther: 'อื่นๆ',
    toastCancelled: 'ยกเลิกแล้ว',
    toastCannotBrowse: 'ไม่สามารถเปิดตัวเลือกโฟลเดอร์ได้',
    toastCannotBrowseCookie: 'ไม่สามารถเลือกไฟล์คุกกี้ได้',
    toastHistoryCleared: 'ล้างประวัติทั้งหมดแล้ว! 🧹',
    settingsEngine: '🚀 ตัวดาวน์โหลดหลัก (yt-dlp)',
    settingsEngineDesc: 'yt-dlp ทำหน้าที่ดึงไฟล์วิดีโอจากเว็บต่างๆ ระบบจะอัปเดตให้อัตโนมัติเมื่อเว็บเปลี่ยนโครงสร้าง',
    btnUpdateEngine: 'อัปเดตเดี๋ยวนี้',
    toastYtdlpUpdated: 'อัปเดต yt-dlp เป็นเวอร์ชันล่าสุดแล้ว! ✨',
    toastYtdlpUpToDate: 'yt-dlp เป็นเวอร์ชันล่าสุดแล้ว! ✅',
    toastItemDeleted: 'ลบรายการจากประวัติแล้ว',
    toastRedownloadStarted: 'เริ่มดาวน์โหลดซ้ำแล้ว! 🔄',
    confirmClearTitle: 'ล้างประวัติทั้งหมด?',
    confirmClearDesc: 'การดำเนินการนี้จะลบประวัติการดาวน์โหลดทั้งหมดอย่างถาวร ไม่สามารถย้อนกลับได้',
    confirmDeleteTitle: 'ลบรายการนี้?',
    confirmDeleteDesc: 'รายการนี้จะถูกลบออกจากประวัติอย่างถาวร',
    statusCompleted: 'เสร็จสิ้น',
    statusError: 'ผิดพลาด',
    settingsDns: '🔒 Secure DNS (DoH)',
    settingsDnsDesc: 'ใช้ Secure DNS (DoH) เพื่อช่วยแก้ไขชื่อโดเมนและเลี่ยงการบล็อก DNS ของผู้ให้บริการอินเทอร์เน็ต (หมายเหตุ: Secure DNS ไม่สามารถเปลี่ยนประเทศหรือปลดล็อกเนื้อหาที่จำกัดประเทศได้)',
    settingEnableDns: 'เปิดใช้งาน Secure DNS (DoH)',
    settingEnableDnsDesc: 'ถอดรหัสและเชื่อมต่อ DNS ผ่าน Cloudflare, Google หรือ OpenDNS',
    settingSelectDnsProvider: 'เลือกผู้ให้บริการ DNS (Select DNS provider)',
    settingSelectDnsProviderDesc: 'เลือกเซิร์ฟเวอร์ DNS ปลอดภัยที่ต้องการใช้งาน',
    settingCustomDnsUrl: 'URL เซิร์ฟเวอร์ DoH กำหนดเอง',
    settingCustomDnsUrlDesc: 'รูปแบบ: https://dns.example.com/dns-query',
    customDnsPlaceholder: 'https://1.1.1.1/dns-query',
    settingsProxy: '🌐 เครือข่ายและพร็อกซี (Proxy / VPN)',
    settingsProxyDesc: 'ส่งต่อการดาวน์โหลดผ่าน Proxy หรือเซิร์ฟเวอร์ VPN เพื่อเลี่ยงการจำกัดเครือข่าย หรือเข้าถึงเนื้อหาที่จำกัดเฉพาะบางประเทศ',
    settingEnableProxy: 'เปิดใช้งาน Network Proxy / Bypass',
    settingEnableProxyDesc: 'ส่งการดาวน์โหลดผ่าน Proxy หรือเซิร์ฟเวอร์ในเครื่อง',
    settingProxyPreset: 'พรีเซ็ต Proxy',
    settingProxyPresetDesc: 'เลือกเซิร์ฟเวอร์ Proxy สำเร็จรูปในเครื่อง หรือใส่ URL เอง',
    settingProxyUrl: 'URL ของเซิร์ฟเวอร์ Proxy แบบกำหนดเอง',
    settingProxyUrlDesc: 'รูปแบบ: http://127.0.0.1:1080 หรือ socks5://127.0.0.1:10808',
    proxyPlaceholder: 'เช่น http://127.0.0.1:1080 หรือ socks5://127.0.0.1:10808',
    proxyNoticeText: 'เลือกพรีเซ็ต Proxy ด้านบน หรือใช้ Cloudflare WARP/VPN เพื่อส่งผ่านข้อมูลหรือเลี่ยงการจำกัดเครือข่าย',
    settingsRestore: '🔄 คืนค่าเริ่มต้น',
    settingRestoreTitle: 'รีเซ็ตการตั้งค่าทั้งหมด',
    settingRestoreDesc: 'รีเซ็ตการตั้งค่า ค่าดาวน์โหลด และประวัติทั้งหมดกลับเป็นค่าเริ่มต้นจากโรงงาน ไม่สามารถย้อนกลับได้',
    btnRestoreDefaults: 'คืนค่าเริ่มต้น',
    confirmRestoreTitle: 'คืนค่าเริ่มต้น?',
    confirmRestoreDesc: 'การดำเนินการนี้จะรีเซ็ตการตั้งค่า ค่าดาวน์โหลด และประวัติทั้งหมดกลับเป็นค่าเริ่มต้น ไม่สามารถย้อนกลับได้',
    toastRestoredDefaults: 'คืนค่าเริ่มต้นทั้งหมดแล้ว! ✨',
    navAssets: 'ค้นหารูปภาพ',
    assetsTitle: '🖼️ ค้นหารูปภาพ',
    assetsDesc: 'ค้นหาและดาวน์โหลดรูปภาพและ GIF คุณภาพสูงฟรีจาก Google และทั่วทั้งเว็บ',
    assetsSearchPlaceholder: 'ค้นหารูปภาพ, GIF, ภาพพื้นหลัง, ความสวยงาม...',
    assetsSearchBtn: 'ค้นหา',
    assetsFindMore: 'ค้นหาเพิ่มเติม',
    assetsVisualDropTitle: 'ลากและวางรูปภาพที่นี่',
    assetsVisualBrowse: 'หรือคลิกเพื่อเลือกไฟล์',
    assetsVisualHint: 'วางรูปภาพด้วย Ctrl+V รูปภาพจะถูกส่งไปยัง Google Lens เพื่อค้นหาภาพที่คล้ายกัน',
    assetsVisualSearching: 'กำลังค้นหารูปภาพที่คล้ายกัน…',
    assetsSimilarCount: 'รูปภาพที่คล้ายกัน {count} รูป',
    assetsFilterPhotos: 'รูปถ่าย',
    assetsForYou: 'สำหรับคุณ',
    assetsForYouSub: 'แนะนำตามสิ่งที่คุณสนใจ',
    assetsRefreshFeed: 'สุ่มใหม่',
    assetsEmptyState: 'ค้นหาอะไรสักอย่างเพื่อค้นพบรูปภาพสุดเจ๋ง!',
    assetsLoadMore: 'โหลดเพิ่มเติม',
    assetsDownloadBtn: 'ดาวน์โหลด',
    assetsDownloading: 'กำลังดาวน์โหลด...',
    assetsDownloaded: 'บันทึกไปยังโฟลเดอร์ Downloads แล้ว! ✨',
    assetsDownloadError: 'ดาวน์โหลดล้มเหลว ❌',
    assetsSearching: 'กำลังค้นหา...',
    assetsNoResults: 'ไม่พบผลลัพธ์ ลองค้นหาคำอื่น!',
    assetsResultsCount: 'พบ {count} ผลลัพธ์',
    settingsAssetsApi: '🖼️ API Key สำหรับค้นหารูปภาพ (ไม่บังคับ)',
    settingPixabayKey: 'Pixabay API Key',
    settingPixabayKeyDesc: 'ไม่บังคับ — ค้นหาด้วย Google ได้ทันทีโดยไม่ต้องใช้ Key. สำหรับ Pixabay: pixabay.com/api/docs',
    settingGiphyKey: 'Giphy API Key',
    settingGiphyKeyDesc: 'ไม่บังคับ — ค้นหาด้วย Google ได้ทันทีโดยไม่ต้องใช้ Key. สำหรับ Giphy: developers.giphy.com',
    assetsSetupTitle: 'ตั้งค่า API Key',
    assetsSetupDesc: 'หากต้องการใช้ Pixabay หรือ Giphy โดยตรงสามารถใส่ Key ได้ หรือเลือกค้นหาด้วย Google โดยไม่ต้องใช้ Key!',
    assetsSetupPixabayStep: 'ไปที่ <a href="https://pixabay.com/api/docs/" target="_blank">pixabay.com/api/docs</a> → สมัคร → key จะแสดงบนหน้า',
    assetsSetupGiphyStep: 'ไปที่ <a href="https://developers.giphy.com/" target="_blank">developers.giphy.com</a> → สร้างแอป → คัดลอก API key',
    assetsSetupSettingsStep: 'วาง key ใน ตั้งค่า → API Key สำหรับค้นหารูปภาพ',
    assetsGoSettings: 'ไปที่ตั้งค่า',
    settingsSound: '🔊 เสียงเอฟเฟกต์ (SFX)',
    settingsSoundDesc: 'เล่นเสียงเอฟเฟกต์น่ารักสดใสสำหรับการคลิก เปลี่ยนแท็บ และดาวน์โหลด',
    settingSoundEnabled: 'เปิดใช้งาน SFX',
    settingSoundEnabledDesc: 'เปิดหรือปิดเสียงเอฟเฟกต์ในโปรแกรม',
    settingSoundVolume: 'ระดับเสียง SFX',
    btnTestSound: 'ทดสอบ',
  }
};

// ── State ──────────────────────────────────────────────────────────────────
const state = {
  videoInfo: null,
  format: 'mp4',
  savePath: '',
  converterSavePath: '',
  activeDownloads: new Map(),
  settings: {
    theme: 'light',
    language: 'en',
    alwaysOnTop: false,
    runInBackground: true,
    startMinimized: false,
    openOnStartup: false,
    autoDeleteDays: 0,
    cookieSource: 'none',
    cookieBrowser: 'chrome',
    cookieFile: '',
    dnsEnabled: true,
    dnsProvider: 'cloudflare',
    customDnsUrl: '',
    proxyEnabled: false,
    proxyPreset: 'warp',
    proxyUrl: '',
    zoomLevel: 1.0,
    pixabayApiKey: '',
    giphyApiKey: ''
  }
};

// ── i18n Functions ─────────────────────────────────────────────────────────
function t(key) {
  const lang = state.settings.language || 'en';
  return (translations[lang] && translations[lang][key]) || translations.en[key] || key;
}

function applyI18n() {
  // Text content
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const translated = t(key);
    if (translated) el.textContent = translated;
  });
  // Placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    const translated = t(key);
    if (translated) el.placeholder = translated;
  });
  // Update language buttons
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === state.settings.language);
  });
}

// ── DOM Refs ───────────────────────────────────────────────────────────────
const urlInput       = document.getElementById('urlInput');
const fetchBtn       = document.getElementById('fetchBtn');
const formatBtns     = document.querySelectorAll('.format-btn');
const qualitySelect  = document.getElementById('qualitySelect');
const savePathInput  = document.getElementById('savePath');
const browseBtn      = document.getElementById('browseBtn');
const thumbnailToggle= document.getElementById('thumbnailToggle');
const activeList     = document.getElementById('activeList');
const emptyState     = document.getElementById('emptyState');
const clearBtn       = document.getElementById('clearBtn');
const navItems       = document.querySelectorAll('.nav-item');

// Window Controls DOM Refs
const winMinBtn = document.getElementById('winMinBtn');
const winMaxBtn = document.getElementById('winMaxBtn');
const winCloseBtn = document.getElementById('winCloseBtn');

// Navigation Section DOM Refs
const tabContents = document.querySelectorAll('.tab-content');

// Settings DOM Refs
const themeToggle = document.getElementById('themeToggle');
const zoomSelect = document.getElementById('zoomSelect');
const alwaysOnTopToggle = document.getElementById('alwaysOnTopToggle');
const runInBackgroundToggle = document.getElementById('runInBackgroundToggle');
const startMinimizedToggle = document.getElementById('startMinimizedToggle');
const openOnStartupToggle = document.getElementById('openOnStartupToggle');
const cookieSourceRadios = document.querySelectorAll('input[name="cookieSource"]');
const browserCookieSection = document.getElementById('browserCookieSection');
const fileCookieSection = document.getElementById('fileCookieSection');
const cookieBrowserSelect = document.getElementById('cookieBrowserSelect');
const cookieFilePathInput = document.getElementById('cookieFilePath');
const cookieFileBrowseBtn = document.getElementById('cookieFileBrowseBtn');
const dnsToggle = document.getElementById('dnsToggle');
const dnsProviderSection = document.getElementById('dnsProviderSection');
const dnsProviderSelect = document.getElementById('dnsProviderSelect');
const customDnsSection = document.getElementById('customDnsSection');
const customDnsInput = document.getElementById('customDnsInput');
const proxyToggle = document.getElementById('proxyToggle');
const proxyPresetSection = document.getElementById('proxyPresetSection');
const proxyPresetSelect = document.getElementById('proxyPresetSelect');
const proxyUrlSection = document.getElementById('proxyUrlSection');
const proxyUrlInput = document.getElementById('proxyUrlInput');
const autoDeleteDaysSelect = document.getElementById('autoDeleteDays');
const clearAllHistoryBtn = document.getElementById('clearAllHistoryBtn');
const langBtns = document.querySelectorAll('.lang-btn');

// Sync lists DOM Refs
const historyTabList = document.getElementById('historyTabList');
const historySearchInput = document.getElementById('historySearchInput');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

// Converter DOM Refs
const converterDropzone = document.getElementById('converterDropzone');
const converterBrowseBtn = document.getElementById('converterBrowseBtn');
const converterSavePathInput = document.getElementById('converterSavePath');
const converterFileInput = document.getElementById('converterFileInput');
const converterScanResult = document.getElementById('converterScanResult');
const converterQueue = document.getElementById('converterQueue');
const converterEmpty = document.getElementById('converterEmpty');

// QR Maker DOM refs
const qrValueInput = document.getElementById('qrValue');
const qrGenerateBtn = document.getElementById('qrGenerateBtn');
const qrSizeOptions = document.getElementById('qrSizeOptions');
const qrPreviewImage = document.getElementById('qrPreviewImage');
const qrResolutionBadge = document.getElementById('qrResolutionBadge');
const qrEmptyState = document.getElementById('qrEmptyState');
const qrActions = document.getElementById('qrActions');
const qrCopyBtn = document.getElementById('qrCopyBtn');
const qrSaveBtn = document.getElementById('qrSaveBtn');
const qrState = { value: '', size: 512, dataUrl: '' };

// Sound Effects (SFX) DOM Refs & Synthesizer
const quickSoundBtn = document.getElementById('quickSoundBtn');
const quickSoundIcon = document.getElementById('quickSoundIcon');
const soundEffectsToggle = document.getElementById('soundEffectsToggle');
const soundVolumeSlider = document.getElementById('soundVolumeSlider');
const soundVolumeLabel = document.getElementById('soundVolumeLabel');
const soundTestBtn = document.getElementById('soundTestBtn');

class CutePopSoundManager {
  constructor() {
    this.ctx = null;
    this.enabled = true;
    this.volume = 0.7;
    this.masterGain = null;
    this.loadSettings();
  }

  loadSettings() {
    try {
      const stored = localStorage.getItem('nuutapao_sfx_settings');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (typeof parsed.enabled === 'boolean') this.enabled = parsed.enabled;
        if (typeof parsed.volume === 'number') this.volume = Math.max(0, Math.min(1, parsed.volume));
      }
    } catch {}
  }

  saveSettings() {
    try {
      localStorage.setItem('nuutapao_sfx_settings', JSON.stringify({
        enabled: this.enabled,
        volume: this.volume
      }));
    } catch {}
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
    }
    this.saveSettings();
  }

  setEnabled(val) {
    this.enabled = !!val;
    this.saveSettings();
  }

  // Cute bubble pop for tab switches (playful two-tone upward pop)
  playTab() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(460, t);
      osc.frequency.exponentialRampToValueAtTime(780, t + 0.07);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.18, t + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.08);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.09);
    } catch {}
  }

  // Waterdrop / button click pop
  playClick() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(760, t);
      osc.frequency.exponentialRampToValueAtTime(480, t + 0.05);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.16, t + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.07);
    } catch {}
  }

  // Playful high bubble pop (filter chips, theme switches)
  playPop() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, t);
      osc.frequency.exponentialRampToValueAtTime(1320, t + 0.05);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.15, t + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.07);
    } catch {}
  }

  // Soft airy swoop for modal opening, lightbox, or drawer
  playWhoosh() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, t);
      osc.frequency.exponentialRampToValueAtTime(680, t + 0.14);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.12, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.18);
    } catch {}
  }

  // Cheerful Kawaii ascending 3-note arpeggio (C5 -> E5 -> G5 -> C6)
  playSuccess() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const notes = [523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, i) => {
        const t = this.ctx.currentTime + i * 0.065;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = i === notes.length - 1 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(freq, t);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(0.18, t + 0.018);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t);
        osc.stop(t + 0.24);
      });
    } catch {}
  }

  // Celebratory victory chime on download or conversion complete
  playComplete() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const notes = [
        { f: 587.33, d: 0.10, pause: 0 },    // D5
        { f: 783.99, d: 0.10, pause: 0.08 }, // G5
        { f: 880.00, d: 0.10, pause: 0.16 }, // A5
        { f: 1174.66, d: 0.38, pause: 0.25 } // D6 (held victory bell)
      ];
      notes.forEach(n => {
        const t = this.ctx.currentTime + n.pause;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(n.f, t);

        gain.gain.setValueAtTime(0.001, t);
        gain.gain.linearRampToValueAtTime(0.20, t + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + n.d);

        osc.connect(gain);
        gain.connect(this.masterGain);
        osc.start(t);
        osc.stop(t + n.d + 0.05);
      });
    } catch {}
  }

  // Gentle cute cartoon error boing
  playError() {
    if (!this.enabled) return;
    try {
      this.init();
      if (!this.ctx) return;
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, t);
      osc.frequency.exponentialRampToValueAtTime(140, t + 0.18);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.14, t + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(t);
      osc.stop(t + 0.24);
    } catch {}
  }
}

const sfx = new CutePopSoundManager();
window.sfx = sfx;

// Resume audio on first user interaction (browser policy compliant)
['click', 'keydown', 'touchstart'].forEach(evt => {
  window.addEventListener(evt, () => sfx.init(), { once: true, passive: true });
});

// Assets Finder DOM Refs
const assetsSearchInput = document.getElementById('assetsSearchInput');
const assetsSearchClear = document.getElementById('assetsSearchClear');
const assetsSearchBtn = document.getElementById('assetsSearchBtn');
const assetsFindMoreBtn = document.getElementById('assetsFindMoreBtn');
const assetsVisualSearchModal = document.getElementById('assetsVisualSearchModal');
const assetsVisualSearchBackdrop = document.getElementById('assetsVisualSearchBackdrop');
const assetsVisualSearchClose = document.getElementById('assetsVisualSearchClose');
const assetsVisualDropzone = document.getElementById('assetsVisualDropzone');
const assetsVisualSearchInput = document.getElementById('assetsVisualSearchInput');
const assetsVisualSearchStatus = document.getElementById('assetsVisualSearchStatus');
const assetsVisualResults = document.getElementById('assetsVisualResults');
const assetsVisualSearchDialog = assetsVisualSearchModal.querySelector('.assets-visual-search-dialog');
const assetsGrid = document.getElementById('assetsGrid');
const assetsEmptyState = document.getElementById('assetsEmptyState');
const assetsFilters = document.getElementById('assetsFilters');
const assetsForYouBar = document.getElementById('assetsForYouBar');
const assetsRefreshFeedBtn = document.getElementById('assetsRefreshFeedBtn');

const assetsResultsInfo = document.getElementById('assetsResultsInfo');
const assetsResultCount = document.getElementById('assetsResultCount');
const assetsLoadMore = document.getElementById('assetsLoadMore');
const assetsLoadMoreBtn = document.getElementById('assetsLoadMoreBtn');
const assetsLightbox = document.getElementById('assetsLightbox');
const assetsLightboxBackdrop = document.getElementById('assetsLightboxBackdrop');
const assetsLightboxClose = document.getElementById('assetsLightboxClose');
const assetsLightboxImg = document.getElementById('assetsLightboxImg');
const assetsLightboxAuthor = document.getElementById('assetsLightboxAuthor');
const assetsLightboxSource = document.getElementById('assetsLightboxSource');
const assetsLightboxSize = document.getElementById('assetsLightboxSize');
const assetsLightboxTags = document.getElementById('assetsLightboxTags');
const assetsResolutionSelect = document.getElementById('assetsResolutionSelect');
const assetsDownloadBtn = document.getElementById('assetsDownloadBtn');

const assetsState = {
  query: '',
  source: 'google',
  type: 'photo',
  page: 1,
  total: 0,
  items: [],
  loading: false,
  currentItem: null,
  isDiscovery: true
};

// Modal DOM Refs
const confirmModal = document.getElementById('confirmModal');
const confirmModalTitle = document.getElementById('confirmModalTitle');
const confirmModalDesc = document.getElementById('confirmModalDesc');
const confirmModalCancel = document.getElementById('confirmModalCancel');
const confirmModalConfirm = document.getElementById('confirmModalConfirm');

// ── Confirm Modal ──────────────────────────────────────────────────────────
let modalResolve = null;

function showConfirm(titleKey, descKey) {
  confirmModalTitle.textContent = t(titleKey);
  confirmModalDesc.textContent = t(descKey);
  confirmModalCancel.textContent = t('btnCancel');
  confirmModalConfirm.textContent = t('btnConfirm');
  confirmModal.classList.remove('hidden');
  return new Promise(resolve => { modalResolve = resolve; });
}

confirmModalCancel.addEventListener('click', () => {
  confirmModal.classList.add('hidden');
  if (modalResolve) modalResolve(false);
});
confirmModalConfirm.addEventListener('click', () => {
  confirmModal.classList.add('hidden');
  if (modalResolve) modalResolve(true);
});
confirmModal.addEventListener('click', (e) => {
  if (e.target === confirmModal) {
    confirmModal.classList.add('hidden');
    if (modalResolve) modalResolve(false);
  }
});

// ── WebSocket ──────────────────────────────────────────────────────────────
let ws;
function connectWS() {
  ws = new WebSocket(`ws://${location.host}`);
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.type === 'progress') handleProgress(msg);
    if (msg.type === 'history')  renderHistory(msg.data);
    if (msg.type === 'convert-progress') handleConvertProgress(msg);
    if (msg.type === 'ytdlp-status') renderYtDlpStatus(msg.data);
  };
  ws.onclose = () => setTimeout(connectWS, 2000);
}
connectWS();

// ── Helpers ────────────────────────────────────────────────────────────────
function formatSize(bytes) {
  if (!bytes) return 'Unknown size';
  if (bytes >= 1e9) return (bytes / 1e9).toFixed(1) + ' GB';
  if (bytes >= 1e6) return (bytes / 1e6).toFixed(1) + ' MB';
  return (bytes / 1e3).toFixed(0) + ' KB';
}

function truncate(str, max = 50) {
  if (!str) return '';
  return str.length > max ? str.slice(0, max) + '…' : str;
}

function toast(msg, type = 'info') {
  if (type === 'success') sfx.playSuccess();
  else if (type === 'error') sfx.playError();
  else sfx.playPop();

  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

// ── yt-dlp Status UI ──────────────────────────────────────────────────────
function renderYtDlpStatus(data) {
  if (!data) return;
  const versionEl = document.getElementById('ytdlpVersionLabel');
  const statusEl = document.getElementById('ytdlpStatusLabel');
  const updateBtn = document.getElementById('updateYtdlpBtn');

  const isTh = state.settings.language === 'th';

  if (versionEl) {
    versionEl.textContent = `${isTh ? 'เวอร์ชัน:' : 'Version:'} ${data.version || 'Checking...'}`;
  }
  if (statusEl) {
    let statusText = data.message || data.status;
    if (data.status === 'checking') statusText = isTh ? 'กำลังตรวจสอบอัปเดต...' : 'Checking for updates...';
    else if (data.status === 'up-to-date') statusText = isTh ? 'เป็นเวอร์ชันล่าสุดแล้ว ✅' : 'Up to date ✅';
    else if (data.status === 'updated') statusText = isTh ? 'อัปเดตสำเร็จ 🎉' : 'Updated successfully 🎉';
    else if (data.status === 'error') statusText = `${isTh ? 'ผิดพลาด:' : 'Error:'} ${data.message}`;

    statusEl.textContent = `${isTh ? 'สถานะ:' : 'Status:'} ${statusText}`;
  }
  if (updateBtn) {
    updateBtn.disabled = data.status === 'checking';
    updateBtn.textContent = data.status === 'checking' ? '...' : t('btnUpdateEngine');
  }
}

// ── Platform Detection ────────────────────────────────────────────────────
const PLATFORMS = [
  { id: 'youtube',   name: 'YouTube',   patterns: [/youtu\.?be/i, /youtube\.com/i] },
  { id: 'tiktok',    name: 'TikTok',    patterns: [/tiktok\.com/i, /vm\.tiktok/i, /vt\.tiktok/i] },
  { id: 'instagram', name: 'Instagram', patterns: [/instagram\.com/i, /instagr\.am/i] },
  { id: 'facebook',  name: 'Facebook',  patterns: [/facebook\.com/i, /fb\.watch/i, /fb\.com/i] },
  { id: 'x',         name: 'X',         patterns: [/twitter\.com/i, /x\.com/i, /t\.co/i] },
  { id: 'bilibili',  name: 'Bilibili',  patterns: [/bilibili\.com/i, /b23\.tv/i] },
  { id: 'douyin',    name: 'Douyin',    patterns: [/douyin\.com/i, /iesdouyin\.com/i] },
  { id: 'reddit',    name: 'Reddit',    patterns: [/reddit\.com/i, /redd\.it/i] },
  { id: 'twitch',    name: 'Twitch',    patterns: [/twitch\.tv/i] },
  { id: 'soundcloud',name: 'SoundCloud',patterns: [/soundcloud\.com/i] },
  { id: 'vimeo',     name: 'Vimeo',     patterns: [/vimeo\.com/i] }
];

function detectPlatform(url) {
  if (!url) return null;
  for (const p of PLATFORMS) {
    if (p.patterns.some(r => r.test(url))) return p;
  }
  // If it looks like a URL but doesn't match known platforms
  if (/^https?:\/\//i.test(url)) return { id: 'other', name: t('platformOther'), patterns: [] };
  return null;
}

function updatePlatformBar(url) {
  const detected = detectPlatform(url);
  const chips = document.querySelectorAll('.platform-chip');
  chips.forEach(chip => {
    const isActive = detected && chip.dataset.platform === detected.id;
    chip.classList.toggle('active', isActive);
  });
  return detected;
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const now = new Date();
  const diff = now - d;
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (mins < 1) return state.settings.language === 'th' ? 'เมื่อสักครู่' : 'Just now';
  if (mins < 60) return state.settings.language === 'th' ? `${mins} นาทีที่แล้ว` : `${mins}m ago`;
  if (hours < 24) return state.settings.language === 'th' ? `${hours} ชั่วโมงที่แล้ว` : `${hours}h ago`;
  if (days < 7) return state.settings.language === 'th' ? `${days} วันที่แล้ว` : `${days}d ago`;
  return d.toLocaleDateString(state.settings.language === 'th' ? 'th-TH' : 'en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

// ── History Storage (server is single source of truth) ─────────────────────
let serverHistory = [];

function getStoredHistory() {
  return serverHistory;
}

async function addToHistory(dl) {
  // The server already records history via recordHistory() on download completion.
  // This function exists for the UI to update the local cache when WebSocket pushes arrive.
  const idx = serverHistory.findIndex(h => h.id === dl.id);
  if (idx !== -1) serverHistory.splice(idx, 1);
  serverHistory.unshift({ ...dl, savedAt: dl.finishedAt || new Date().toISOString() });
  if (serverHistory.length > 200) serverHistory.length = 200;
}

async function removeFromHistory(id) {
  try {
    await fetch(`/api/history/${id}`, { method: 'DELETE' });
    serverHistory = serverHistory.filter(h => h.id !== id);
    const active = state.activeDownloads.get(id);
    if (active && active.status !== 'downloading') {
      state.activeDownloads.delete(id);
    }
    renderDownloads();
    renderHistoryTab();
  } catch {}
}

async function clearAllHistory() {
  try {
    await fetch('/api/history', { method: 'DELETE' });
    serverHistory = [];
    for (const [id, dl] of state.activeDownloads.entries()) {
      if (dl.status !== 'downloading') {
        state.activeDownloads.delete(id);
      }
    }
    renderDownloads();
    renderHistoryTab();
  } catch {}
}

function autoDeleteOldHistory() {
  // Auto-delete is handled server-side via normalizeHistory when state is loaded/saved.
  // Trigger a save to apply the setting.
  patchServerState({});
}

// ── UI Events ──────────────────────────────────────────────────────────────
formatBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    sfx.playPop();
    formatBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.format = btn.dataset.val;
    if(['mp3', 'wav', 'm4a'].includes(state.format)) {
      qualitySelect.disabled = true;
    } else {
      qualitySelect.disabled = false;
    }
    if (state.format === 'wav' && thumbnailToggle) {
      thumbnailToggle.checked = false;
    }
    saveDownloadDefaults();
  });
});

function setActiveTab(targetTab) {
  if (!targetTab) return;
  sfx.playTab();
  navItems.forEach(n => n.classList.toggle('active', n.dataset.tab === targetTab));
  tabContents.forEach(content => {
    if (content.id === `${targetTab}-tab`) {
      content.classList.remove('hidden');
    } else {
      content.classList.add('hidden');
    }
  });
  if (targetTab === 'history') {
    renderHistoryTab();
  }
  if (targetTab === 'assets') {
    if (!assetsState.items || assetsState.items.length === 0) {
      loadDiscoveryFeed(false);
    }
  }
  if (targetTab === 'clipper') {
    if (clipperSavePathInput && !clipperSavePathInput.value) {
      clipperSavePathInput.value = state.savePath || '';
    }
  }
}

navItems.forEach(item => {
  item.addEventListener('click', (e) => {
    e.preventDefault();
    const targetTab = item.dataset.tab;
    setActiveTab(targetTab);
    saveActiveTab(targetTab);
  });
});

// ── Assets Finder ─────────────────────────────────────────────────────────

// Curated Gen Z favorite starter pools (Strictly non-AI photography & viral meme/aesthetic GIF vibes)
const DISCOVERY_PHOTO_POOLS = [
  '35mm film photography aesthetic -ai -"ai generated"',
  'cute silly cat meme photo -ai -"ai generated"',
  'y2k vintage aesthetic photography -ai -"ai generated"',
  'retro 90s anime scenery aesthetic',
  'ghibli peaceful scenery landscape',
  'golden hour sunset 35mm film photography -ai -"ai generated"',
  'vintage disposable camera aesthetic -ai -"ai generated"',
  'chill capybara photography -ai -"ai generated"',
  'tokyo night city street film photography -ai -"ai generated"',
  'funny orange cat photos -ai -"ai generated"',
  'cozy vintage room record player aesthetic -ai -"ai generated"',
  'matcha latte cozy cafe film photography -ai -"ai generated"',
  'golden retriever silly puppy photos -ai -"ai generated"',
  'polaroid vintage summer aesthetic -ai -"ai generated"'
];

const DISCOVERY_GIF_POOLS = [
  'funny cat meme gif',
  'iconic reaction meme gif',
  'retro 90s anime aesthetic gif',
  'dancing cat cute gif',
  'relatable mood reaction gif',
  'pedro raccoon meme gif',
  'ghibli peaceful aesthetic gif',
  'chill anime lofi loop gif',
  'funny dog silly moment gif',
  'pop cat meme cute gif',
  'kawaii kitten meme gif',
  'confused cat meme gif',
  'funny hamster meme gif'
];

const USER_INTERESTS_STORAGE_KEY = 'nuutapao_user_interests_v1';

function getLearnedInterests() {
  try {
    const raw = localStorage.getItem(USER_INTERESTS_STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      if (data && typeof data === 'object') {
        if (!data.tags || typeof data.tags !== 'object') data.tags = {};
        return data;
      }
    }
  } catch {}
  return { tags: {}, lastUpdated: Date.now() };
}

function saveLearnedInterests(data) {
  try {
    localStorage.setItem(USER_INTERESTS_STORAGE_KEY, JSON.stringify(data));
  } catch {}
}

function recordUserInterests(keywords, weight = 1) {
  if (!keywords) return;
  const words = Array.isArray(keywords)
    ? keywords
    : String(keywords).toLowerCase().split(/[\s,._\-+/\\]+/);
  const data = getLearnedInterests();
  const stopWords = new Set([
    'the', 'and', 'with', 'for', 'from', 'this', 'that', 'image', 'picture', 'photo',
    'free', 'high', 'view', 'wallpapers', 'wallpaper', 'download', 'best', 'gif', 'gifs',
    'com', 'net', 'org', 'www', 'http', 'https', 'stock', 'vector', 'illustration'
  ]);

  words.forEach(raw => {
    const w = raw.trim().toLowerCase();
    if (w.length < 3 || stopWords.has(w) || /^\d+$/.test(w)) return;
    const current = data.tags[w];
    const score = typeof current === 'number' ? current : (Number(current?.score) || 0);
    data.tags[w] = { score: score + weight, updatedAt: Date.now() };
  });

  // Keep top 60 tags
  const sorted = Object.entries(data.tags).sort((a, b) => {
    const scoreOf = value => typeof value === 'number' ? value : (Number(value?.score) || 0);
    return scoreOf(b[1]) - scoreOf(a[1]);
  });
  if (sorted.length > 60) {
    data.tags = Object.fromEntries(sorted.slice(0, 60));
  }
  data.lastUpdated = Date.now();
  saveLearnedInterests(data);
}

function getInterestScores() {
  const data = getLearnedInterests();
  const now = Date.now();
  const halfLifeMs = 45 * 24 * 60 * 60 * 1000;
  return Object.entries(data.tags || {}).map(([tag, value]) => {
    const score = typeof value === 'number' ? value : (Number(value?.score) || 0);
    const updatedAt = typeof value === 'number' ? (data.lastUpdated || now) : (value?.updatedAt || data.lastUpdated || now);
    const age = Math.max(0, now - updatedAt);
    return { tag, score: score * Math.pow(0.5, age / halfLifeMs) };
  }).filter(entry => entry.score > 0.1).sort((a, b) => b.score - a.score);
}

function pickWeightedInterestTags(count) {
  const pool = getInterestScores();
  const picked = [];
  while (pool.length && picked.length < count) {
    const weights = pool.map(entry => Math.sqrt(entry.score));
    const total = weights.reduce((sum, weight) => sum + weight, 0);
    let roll = Math.random() * total;
    let index = 0;
    while (index < weights.length - 1 && roll >= weights[index]) {
      roll -= weights[index];
      index++;
    }
    picked.push(pool[index].tag);
    pool.splice(index, 1);
  }
  return picked;
}

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function assetIdentityKeys(item) {
  const keys = [];
  if (item.id) keys.push(`id:${item.source || ''}:${item.id}`);

  for (const value of [item.preview, item.thumbnail]) {
    if (!value) continue;
    try {
      const url = new URL(value);
      url.hash = '';
      for (const key of [...url.searchParams.keys()]) {
        if (/^(utm_.+|ref|source|width|height|w|h|resize|quality|format|auto)$/i.test(key)) {
          url.searchParams.delete(key);
        }
      }
      keys.push(`url:${url.hostname.toLowerCase()}${url.pathname}${url.search}`);
    } catch {
      keys.push(`url:${value}`);
    }
  }

  const title = (item.title || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  if (title.length >= 16) keys.push(`title:${title}`);
  return keys;
}

function dedupeAssetItems(items, existing = []) {
  const seen = new Set(existing.flatMap(assetIdentityKeys));
  const unique = [];
  for (const item of items) {
    const keys = assetIdentityKeys(item);
    if (keys.some(key => seen.has(key))) continue;
    keys.forEach(key => seen.add(key));
    unique.push(item);
  }
  return unique;
}

function pickDiscoveryBatch(count = 5) {
  const isGif = assetsState.type === 'gif';
  const basePool = isGif ? DISCOVERY_GIF_POOLS : DISCOVERY_PHOTO_POOLS;
  const learnedTags = pickWeightedInterestTags(Math.max(0, count - 1));
  const personalizedQueries = learnedTags.map(tag => {
    if (isGif) return `${tag} ${Math.random() < 0.5 ? 'reaction ' : 'meme '}gif`;
    return `${tag} ${Math.random() < 0.5 ? 'photography' : 'aesthetic photos'}`;
  });
  const explorationQuery = basePool[Math.floor(Math.random() * basePool.length)];
  const queries = [...personalizedQueries, explorationQuery];
  const remainingExploration = shuffleArray(basePool.filter(query => query !== explorationQuery));
  while (queries.length < count && remainingExploration.length) {
    queries.push(remainingExploration.pop());
  }
  return shuffleArray(queries).slice(0, count);
}

function scoreAssetForInterests(item, interests) {
  const words = new Set([...(item.tags || []), item.title || '']
    .join(' ').toLowerCase().split(/[^a-z0-9]+/).filter(word => word.length >= 3));
  return [...words].reduce((score, word) => score + (interests.get(word) || 0), 0);
}

async function loadDiscoveryFeed(append = false) {
  if (assetsState.loading) return;
  assetsState.isDiscovery = true;

  if (!append) {
    assetsState.page = 1;
    assetsState.items = [];
    showAssetsShimmer(12);
  }

  if (assetsResultsInfo) assetsResultsInfo.classList.add('hidden');
  assetsForYouBar?.classList.remove('hidden');
  if (assetsSearchClear) assetsSearchClear.classList.add('hidden');

  assetsState.loading = true;
  if (assetsLoadMoreBtn) assetsLoadMoreBtn.disabled = true;

  try {
    // Mix learned topics with exploration queries to keep the feed personal and varied.
    const batchQueries = pickDiscoveryBatch(5);
    const perTopic = 6;

    const fetchPromises = batchQueries.map(q => {
      const params = new URLSearchParams({
        q,
        source: assetsState.source,
        type: assetsState.type,
        page: assetsState.page,
        per_page: perTopic
      });
      return fetch(`/api/assets/search?${params}`)
        .then(res => res.json())
        .then(data => data.items || [])
        .catch(() => []);
    });

    const results = await Promise.all(fetchPromises);

    // Interleave results from each topic so items are varied and distributed
    const interleaved = [];
    const collected = [];
    const maxLen = Math.max(0, ...results.map(r => r.length));

    for (let i = 0; i < maxLen; i++) {
      for (const topicItems of results) {
        if (topicItems[i]) {
          collected.push(topicItems[i]);
        }
      }
    }

    interleaved.push(...dedupeAssetItems(collected, assetsState.items));

    // Rank learned topics first while reserving the tail for discovery.
    const interests = new Map(getInterestScores().map(({ tag, score }) => [tag, score]));
    const scored = interleaved.map(item => ({ item, score: scoreAssetForInterests(item, interests) }));
    const personalized = scored.filter(entry => entry.score > 0).sort((a, b) => b.score - a.score);
    const exploratory = shuffleArray(scored.filter(entry => entry.score === 0));
    const personalCount = Math.ceil(interleaved.length * 0.8);
    const newItems = [
      ...personalized.slice(0, personalCount),
      ...shuffleArray([...personalized.slice(personalCount), ...exploratory])
    ].map(entry => entry.item);

    assetsState.total = 150;
    assetsState.items = append ? [...assetsState.items, ...newItems] : newItems;

    renderAssetsGrid(newItems, append);

    const hasMore = assetsState.items.length < assetsState.total && newItems.length > 0;
    if (assetsLoadMore) assetsLoadMore.classList.toggle('hidden', !hasMore);
    if (assetsEmptyState) assetsEmptyState.classList.add('hidden');
  } catch (err) {
    console.error('Discovery feed error:', err);
  } finally {
    assetsState.loading = false;
    if (assetsLoadMoreBtn) assetsLoadMoreBtn.disabled = false;
  }
}

function showAssetsShimmer(count = 12) {
  const heights = [180, 220, 260, 200, 240, 300, 190, 250, 210, 270, 230, 280];
  let html = '';
  for (let i = 0; i < count; i++) {
    html += `<div class="asset-card-shimmer" style="height:${heights[i % heights.length]}px"></div>`;
  }
  assetsGrid.innerHTML = html;
}

function renderAssetCard(item) {
  const card = document.createElement('div');
  card.className = 'asset-card';
  card.innerHTML = `
    <img src="${item.thumbnail}" alt="" loading="lazy" />
    <div class="asset-card-overlay">
      <div class="asset-card-author">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        ${item.author}
      </div>
    </div>
    <button class="asset-card-download" title="Quick Download">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
    </button>
    ${item.type === 'gif' ? '<span class="asset-card-gif-badge">GIF</span>' : ''}
  `;

  // Click card → learn interest and open lightbox
  card.addEventListener('click', (e) => {
    if (e.target.closest('.asset-card-download')) return;
    const keywords = (item.tags || []).concat((item.title || '').split(' '));
    recordUserInterests(keywords, 2);
    openAssetsLightbox(item);
  });

  // Quick download button
  const dlBtn = card.querySelector('.asset-card-download');
  dlBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const keywords = (item.tags || []).concat((item.title || '').split(' '));
    recordUserInterests(keywords, 4);
    quickDownloadAsset(item, dlBtn);
  });

  return card;
}

function renderAssetsGrid(items, append = false) {
  if (!append) {
    assetsGrid.innerHTML = '';
  }
  if (items.length === 0 && !append) {
    assetsGrid.innerHTML = `
      <div class="assets-empty-state">
        <div class="assets-empty-icon">😕</div>
        <p>${t('assetsNoResults')}</p>
      </div>
    `;
    return;
  }
  items.forEach(item => {
    assetsGrid.appendChild(renderAssetCard(item));
  });
}

async function searchAssets(append = false) {
  const q = assetsSearchInput.value.trim();
  if (!q) {
    if (assetsSearchClear) assetsSearchClear.classList.add('hidden');
    loadDiscoveryFeed(false);
    return;
  }

  assetsState.isDiscovery = false;
  assetsForYouBar?.classList.add('hidden');
  if (assetsSearchClear) assetsSearchClear.classList.remove('hidden');

  // Record query into learned interests (+3 weight)
  recordUserInterests(q, 3);

  if (!append) {
    assetsState.page = 1;
    assetsState.items = [];
    showAssetsShimmer(12);
  }

  assetsState.query = q;
  assetsState.loading = true;
  assetsSearchBtn.disabled = true;
  assetsSearchBtn.textContent = t('assetsSearching');
  if (assetsLoadMoreBtn) assetsLoadMoreBtn.disabled = true;

  try {
    const params = new URLSearchParams({
      q: assetsState.query,
      source: assetsState.source,
      type: assetsState.type,
      page: assetsState.page,
      per_page: 30
    });
    const res = await fetch(`/api/assets/search?${params}`);
    const data = await res.json();

    if (!res.ok) {
      toast(data.error || 'Search failed', 'error');
      return;
    }

    // Show setup guide if API key is missing for Pixabay/Giphy
    if (data.setup_required) {
      const source = data.setup_required;
      assetsGrid.innerHTML = `
        <div class="assets-setup-guide">
          <div class="assets-setup-icon">🔑</div>
          <h3>${t('assetsSetupTitle')}</h3>
          <p>${t('assetsSetupDesc')}</p>
          <div class="assets-setup-steps">
            <div class="assets-setup-step">
              <span class="assets-setup-step-num">1</span>
              <span>${source === 'giphy' ? t('assetsSetupGiphyStep') : t('assetsSetupPixabayStep')}</span>
            </div>
            <div class="assets-setup-step">
              <span class="assets-setup-step-num">2</span>
              <span>${t('assetsSetupSettingsStep')}</span>
            </div>
          </div>
          <button class="btn-go-settings" onclick="setActiveTab('settings'); saveActiveTab('settings');">${t('assetsGoSettings')}</button>
        </div>
      `;
      assetsResultsInfo.classList.add('hidden');
      assetsLoadMore.classList.add('hidden');
      return;
    }

    const uniqueItems = dedupeAssetItems(data.items, append ? assetsState.items : []);
    assetsState.total = data.total;
    assetsState.items = append ? [...assetsState.items, ...uniqueItems] : uniqueItems;

    renderAssetsGrid(uniqueItems, append);

    // Results info
    assetsResultsInfo.classList.remove('hidden');
    assetsResultCount.textContent = t('assetsResultsCount').replace('{count}', assetsState.total.toLocaleString());

    // Show/hide load more
    const hasMore = assetsState.items.length < assetsState.total;
    assetsLoadMore.classList.toggle('hidden', !hasMore);
    assetsEmptyState?.classList.add('hidden');
  } catch (err) {
    toast('Search failed: ' + err.message, 'error');
  } finally {
    assetsState.loading = false;
    assetsSearchBtn.disabled = false;
    assetsSearchBtn.textContent = t('assetsSearchBtn');
    if (assetsLoadMoreBtn) assetsLoadMoreBtn.disabled = false;
  }
}

function openAssetsLightbox(item) {
  assetsState.currentItem = item;
  assetsLightboxImg.src = item.preview || item.thumbnail;
  assetsLightboxAuthor.textContent = '📷 ' + item.author;
  if (assetsLightboxSource) {
    assetsLightboxSource.textContent = item.type === 'gif' ? 'GIF' : 'PHOTO';
    assetsLightboxSource.className = 'assets-lightbox-source ' + (item.type === 'gif' ? 'giphy' : 'google');
  }
  assetsLightboxSize.textContent = item.width && item.height ? `${item.width} × ${item.height}` : '';

  // Tags
  assetsLightboxTags.innerHTML = '';
  (item.tags || []).forEach(tag => {
    const el = document.createElement('span');
    el.className = 'assets-lightbox-tag';
    el.textContent = tag;
    assetsLightboxTags.appendChild(el);
  });

  // Resolution select
  const origOption = assetsResolutionSelect.querySelector('option[value="original"]');
  if (origOption) origOption.style.display = item.urls.original ? '' : 'none';

  assetsLightbox.classList.remove('hidden');
  sfx.playWhoosh();
}

function closeAssetsLightbox() {
  assetsLightbox.classList.add('hidden');
  assetsState.currentItem = null;
  sfx.playClick();
}

async function quickDownloadAsset(item, btnEl) {
  const url = item.urls.large || item.urls.medium || item.urls.original || item.thumbnail;
  const ext = item.type === 'gif' ? '.gif' : '.png';
  const filename = `${item.source}_${item.id}${ext}`;

  if (btnEl) {
    btnEl.style.opacity = '0.5';
    btnEl.style.pointerEvents = 'none';
  }

  try {
    const res = await fetch('/api/assets/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, filename })
    });
    const data = await res.json();
    if (data.success) {
      toast(t('assetsDownloaded'), 'success');
    } else {
      toast(data.error || t('assetsDownloadError'), 'error');
    }
  } catch {
    toast(t('assetsDownloadError'), 'error');
  } finally {
    if (btnEl) {
      btnEl.style.opacity = '';
      btnEl.style.pointerEvents = '';
    }
  }
}

async function downloadAssetFromLightbox() {
  const item = assetsState.currentItem;
  if (!item) return;

  const resolution = assetsResolutionSelect.value;
  const url = item.urls[resolution] || item.urls.large || item.urls.medium || item.thumbnail;
  const ext = item.type === 'gif' ? '.gif' : (item.type === 'vector' ? '.svg' : '.png');
  const filename = `${item.source}_${item.id}_${resolution}${ext}`;

  // Record user interest (+4)
  const keywords = (item.tags || []).concat((item.title || '').split(' '));
  recordUserInterests(keywords, 4);

  assetsDownloadBtn.disabled = true;
  const origText = assetsDownloadBtn.querySelector('span');
  if (origText) origText.textContent = t('assetsDownloading');

  try {
    const res = await fetch('/api/assets/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, filename })
    });
    const data = await res.json();
    if (data.success) {
      toast(t('assetsDownloaded'), 'success');
    } else {
      toast(data.error || t('assetsDownloadError'), 'error');
    }
  } catch {
    toast(t('assetsDownloadError'), 'error');
  } finally {
    assetsDownloadBtn.disabled = false;
    if (origText) origText.textContent = t('assetsDownloadBtn');
  }
}

function openVisualSearch() {
  assetsVisualSearchStatus.className = 'assets-visual-search-status';
  assetsVisualSearchStatus.textContent = t('assetsVisualHint');
  assetsVisualDropzone.classList.remove('hidden');
  assetsVisualResults.classList.add('hidden');
  assetsVisualResults.classList.remove('scraping');
  assetsVisualSearchDialog.classList.remove('results-mode');
  assetsVisualResults.src = 'about:blank';
  assetsVisualResults.classList.add('hidden');
  assetsVisualResults.classList.remove('scraping');
  assetsVisualSearchModal.classList.remove('hidden');
  assetsVisualDropzone.focus();
}

function closeVisualSearch() {
  assetsVisualSearchModal.classList.add('hidden');
  assetsVisualSearchInput.value = '';
  assetsVisualDropzone.classList.remove('drag-over');
  assetsVisualResults.src = 'about:blank';
}

async function searchSimilarImages(file) {
  if (!file?.type.startsWith('image/')) {
    assetsVisualSearchStatus.className = 'assets-visual-search-status error';
    assetsVisualSearchStatus.textContent = 'Please choose an image file.';
    return;
  }

  assetsVisualSearchStatus.className = 'assets-visual-search-status searching';
  assetsVisualSearchStatus.textContent = t('assetsVisualSearching');
  const formData = new FormData();
  formData.append('image', file, file.name || 'pasted-image.png');

  try {
    const res = await fetch('/api/assets/visual-search', { method: 'POST', body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Visual search failed.');
    if (assetsVisualSearchModal.classList.contains('hidden')) return;
    const searchUrl = new URL(data.searchUrl);
    if (searchUrl.hostname !== 'www.google.com' || searchUrl.pathname !== '/search') {
      throw new Error('Google Lens returned an invalid results page.');
    }
    await window.electronAPI?.setVisualSearchCookies(data.cookies || []);
    assetsVisualResults.classList.remove('hidden');
    assetsVisualResults.classList.add('scraping');
    assetsVisualSearchDialog.classList.add('results-mode');
    assetsVisualResults.src = searchUrl.href;
  } catch (err) {
    assetsVisualSearchStatus.className = 'assets-visual-search-status error';
    assetsVisualSearchStatus.textContent = err.message;
  }
}

document.addEventListener('paste', event => {
  if (assetsVisualSearchModal.classList.contains('hidden')) return;
  const image = [...(event.clipboardData?.items || [])]
    .find(item => item.type.startsWith('image/'))?.getAsFile();
  if (!image) return;
  event.preventDefault();
  searchSimilarImages(image);
});

assetsVisualResults.addEventListener('did-stop-loading', async () => {
  if (assetsVisualSearchModal.classList.contains('hidden') || assetsVisualResults.getURL() === 'about:blank' || assetsVisualResults.classList.contains('hidden')) return;
  if (assetsVisualResults.classList.contains('reading-results')) return;
  assetsVisualResults.classList.add('reading-results');
  try {
    const lensData = await assetsVisualResults.executeJavaScript(`(async () => {
      const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
      for (let attempt = 0; attempt < 12; attempt++) {
        const seen = new Set();
        const matches = [...document.images].map(img => {
          const link = img.closest('a[href]') || img.parentElement?.closest('a[href]');
          let image = [img.currentSrc, img.src, img.dataset.src, img.dataset.lazySrc].find(src => /^https?:/i.test(src || '')) || '';
          let page = link?.href || '';
          if (page) {
            try {
              const url = new URL(page);
              if (url.hostname === 'www.google.com' && url.pathname === '/imgres') {
                image = url.searchParams.get('imgurl') || image;
                page = url.searchParams.get('imgrefurl') || page;
              }
            } catch {}
          }
          const size = img.getBoundingClientRect();
          const hasSourcePage = /^https?:/i.test(page) && !/^(?:www\\.)?google\\./i.test(new URL(page).hostname);
          const isGoogleThumbnail = /^https?:\\/\\/encrypted-tbn\\d*\\.gstatic\\.com\\//i.test(image);
          if ((!hasSourcePage && !isGoogleThumbnail) || !/^https?:/i.test(image || '') || Math.max(img.naturalWidth, size.width) < 40 || Math.max(img.naturalHeight, size.height) < 40 || seen.has(image)) return null;
          seen.add(image);
          return { image, page: hasSourcePage ? page : image, title: (img.alt || link?.innerText?.trim() || '').slice(0, 160) };
        }).filter(Boolean).slice(0, 40);
        if (matches.length) return { matches };
        await sleep(750);
      }
      const clean = value => value.replace(/\\s+/g, ' ').trim();
      const skip = /^(google|google lens|search|images?|visual matches|exact matches|results?|all|about|shopping|translate)$/i;
      const labels = [...document.querySelectorAll('h1,h2,[role="heading"],[data-attrid="title"]')]
        .map(node => clean(node.innerText || node.textContent || ''))
        .filter(value => value.length >= 3 && value.length <= 90 && !skip.test(value));
      const title = clean(document.title.replace(/\\s+-\\s+Google.*$/i, ''));
      return { matches: [], query: labels[0] || (title.length >= 3 && title.length <= 90 && !skip.test(title) ? title : '') };
    })()`);
    const matches = lensData.matches || [];
    let textResults = [];
    if (!matches.length && lensData.query) {
      const response = await fetch(`/api/assets/search?q=${encodeURIComponent(lensData.query)}&source=google&type=photo&per_page=40`);
      if (response.ok) textResults = (await response.json()).items || [];
    }
    if (!matches.length && !textResults.length) throw new Error('Assets Finder could not retrieve similar images for this picture. Try a different image.');

    assetsState.items = matches.length ? matches.map((match, index) => {
      const pageUrl = new URL(match.page);
      const title = match.title || pageUrl.hostname.replace(/^www\./, '');
      return {
        id: `lens-${index}-${Date.now()}`,
        source: 'google-lens',
        type: 'photo',
        title,
        thumbnail: match.image,
        preview: match.image,
        urls: { small: match.image, medium: match.image, large: match.image, original: match.image },
        width: 0,
        height: 0,
        author: pageUrl.hostname.replace(/^www\./, ''),
        authorUrl: match.page,
        tags: title.toLowerCase().match(/[a-z0-9]{3,}/g) || [],
        pageUrl: match.page
      };
    }) : textResults;
    assetsState.query = lensData.query || '';
    assetsState.total = assetsState.items.length;
    assetsState.page = 1;
    assetsState.isDiscovery = false;
    assetsForYouBar?.classList.add('hidden');
    renderAssetsGrid(assetsState.items);
    assetsResultsInfo.classList.remove('hidden');
    assetsResultCount.textContent = t('assetsSimilarCount').replace('{count}', assetsState.items.length);
    assetsLoadMore?.classList.add('hidden');
    closeVisualSearch();
  } catch (err) {
    assetsVisualResults.classList.add('hidden');
    assetsVisualResults.classList.remove('scraping');
    assetsVisualSearchDialog.classList.remove('results-mode');
    assetsVisualDropzone.classList.remove('hidden');
    assetsVisualSearchStatus.className = 'assets-visual-search-status error';
    assetsVisualSearchStatus.textContent = err.message;
  } finally {
    assetsVisualResults.classList.remove('reading-results');
  }
});

if (assetsVisualDropzone) {
  assetsVisualDropzone.addEventListener('click', event => {
    if (event.target !== assetsVisualSearchInput) assetsVisualSearchInput.click();
  });
  assetsVisualDropzone.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      assetsVisualSearchInput.click();
    }
  });
  assetsVisualDropzone.addEventListener('dragover', event => {
    event.preventDefault();
    assetsVisualDropzone.classList.add('drag-over');
  });
  assetsVisualDropzone.addEventListener('dragleave', () => assetsVisualDropzone.classList.remove('drag-over'));
  assetsVisualDropzone.addEventListener('drop', event => {
    event.preventDefault();
    assetsVisualDropzone.classList.remove('drag-over');
    const image = [...(event.dataTransfer?.files || [])].find(file => file.type.startsWith('image/'));
    if (image) searchSimilarImages(image);
  });
  assetsVisualSearchInput.addEventListener('change', () => {
    const image = assetsVisualSearchInput.files?.[0];
    if (image) searchSimilarImages(image);
  });
}

// Wire up Assets Finder events
if (assetsSearchBtn) {
  assetsSearchBtn.addEventListener('click', () => searchAssets());
}
if (assetsFindMoreBtn) assetsFindMoreBtn.addEventListener('click', openVisualSearch);
assetsVisualSearchClose?.addEventListener('click', closeVisualSearch);
assetsVisualSearchBackdrop?.addEventListener('click', closeVisualSearch);
if (assetsRefreshFeedBtn) {
  assetsRefreshFeedBtn.addEventListener('click', () => {
    sfx.playPop();
    loadDiscoveryFeed(false);
  });
}
if (assetsSearchInput) {
  assetsSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') searchAssets();
  });
  assetsSearchInput.addEventListener('input', () => {
    if (assetsSearchClear) {
      assetsSearchClear.classList.toggle('hidden', !assetsSearchInput.value.trim());
    }
  });
}
if (assetsSearchClear) {
  assetsSearchClear.addEventListener('click', () => {
    assetsSearchInput.value = '';
    assetsSearchClear.classList.add('hidden');
    loadDiscoveryFeed(false);
  });
}

// Filter chips (Photos / GIFs)
if (assetsFilters) {
  assetsFilters.querySelectorAll('.assets-filter-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      sfx.playPop();
      assetsFilters.querySelectorAll('.assets-filter-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const type = chip.dataset.type;
      assetsState.type = type;
      assetsState.source = 'google';

      if (assetsSearchInput && assetsSearchInput.value.trim()) {
        searchAssets();
      } else {
        loadDiscoveryFeed(false);
      }
    });
  });
}

// Load more button
if (assetsLoadMoreBtn) {
  assetsLoadMoreBtn.addEventListener('click', () => {
    assetsState.page++;
    if (assetsState.isDiscovery) {
      loadDiscoveryFeed(true);
    } else {
      searchAssets(true);
    }
  });
}

// Lightbox events
if (assetsLightboxClose) {
  assetsLightboxClose.addEventListener('click', closeAssetsLightbox);
}
if (assetsLightboxBackdrop) {
  assetsLightboxBackdrop.addEventListener('click', closeAssetsLightbox);
}
if (assetsDownloadBtn) {
  assetsDownloadBtn.addEventListener('click', downloadAssetFromLightbox);
}
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (!assetsVisualSearchModal.classList.contains('hidden')) closeVisualSearch();
    else if (!assetsLightbox.classList.contains('hidden')) closeAssetsLightbox();
  }
});

// ── QR Maker ──────────────────────────────────────────────────────────────
function setQrBusy(isBusy) {
  qrGenerateBtn.disabled = isBusy;
  qrGenerateBtn.textContent = isBusy ? '...' : t('qrGenerate');
}

async function generateQr() {
  const value = qrValueInput.value.trim();
  if (!value) {
    toast(t('toastQrLinkRequired'), 'error');
    qrValueInput.focus();
    return;
  }

  setQrBusy(true);
  try {
    const response = await fetch('/api/qr', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value, size: qrState.size })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Unable to create QR code.');

    qrState.value = value;
    qrState.dataUrl = result.dataUrl;
    qrPreviewImage.src = result.dataUrl;
    qrPreviewImage.classList.remove('hidden');
    qrEmptyState.classList.add('hidden');
    qrActions.classList.remove('hidden');
    if (qrResolutionBadge) {
      const displaySize = result.size || qrState.size || 512;
      qrResolutionBadge.textContent = `${displaySize} × ${displaySize}`;
      qrResolutionBadge.classList.remove('hidden');
    }
    toast(t('toastQrGenerated'), 'success');
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    setQrBusy(false);
  }
}

qrSizeOptions?.addEventListener('click', (event) => {
  const button = event.target.closest('[data-size]');
  if (!button) return;
  qrState.size = Number(button.dataset.size);
  qrSizeOptions.querySelectorAll('.qr-size-btn').forEach(item => item.classList.toggle('active', item === button));
  if (qrResolutionBadge && !qrPreviewImage.classList.contains('hidden')) {
    qrResolutionBadge.textContent = `${qrState.size} × ${qrState.size}`;
  }
  if (qrState.value && !qrPreviewImage.classList.contains('hidden')) {
    generateQr();
  }
});

qrGenerateBtn?.addEventListener('click', generateQr);
qrValueInput?.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') generateQr();
});

qrCopyBtn?.addEventListener('click', async () => {
  if (!qrState.dataUrl) return;
  if (!window.electronAPI?.copyImage) {
    toast(t('toastQrCopyUnavailable'), 'error');
    return;
  }
  try {
    await window.electronAPI.copyImage(qrState.dataUrl);
    toast(t('toastQrCopied'), 'success');
  } catch (error) {
    toast(error.message || t('toastQrCopyUnavailable'), 'error');
  }
});

qrSaveBtn?.addEventListener('click', async () => {
  if (!qrState.value) return;
  qrSaveBtn.disabled = true;
  try {
    const response = await fetch('/api/qr/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ value: qrState.value, size: qrState.size })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Unable to save QR code.');
    if (!result.cancelled) toast(t('toastQrSaved'), 'success');
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    qrSaveBtn.disabled = false;
  }
});

if (qualitySelect) {
  qualitySelect.addEventListener('change', () => {
    saveDownloadDefaults();
  });
}

if (thumbnailToggle) {
  thumbnailToggle.addEventListener('change', () => {
    saveDownloadDefaults();
  });
}

browseBtn.addEventListener('click', async () => {
  try {
    const currentPath = encodeURIComponent(state.savePath || '');
    const res = await fetch(`/api/select-folder?current=${currentPath}`);
    const data = await res.json();
    if (data.path) {
      state.savePath = data.path;
      savePathInput.value = data.path;
      saveDownloadDefaults();
    }
  } catch (err) {
    toast(t('toastCannotBrowse'), 'error');
  }
});

// Platform auto-detection on URL input
urlInput.addEventListener('input', () => {
  updatePlatformBar(urlInput.value.trim());
});
urlInput.addEventListener('paste', () => {
  // Delay to let paste complete
  setTimeout(() => updatePlatformBar(urlInput.value.trim()), 50);
});

clearBtn.addEventListener('click', () => {
  for (const [id, dl] of state.activeDownloads.entries()) {
    if (dl.status !== 'downloading') {
      state.activeDownloads.delete(id);
    }
  }
  renderDownloads();
});

// ── History Search ─────────────────────────────────────────────────────────
if (historySearchInput) {
  historySearchInput.addEventListener('input', () => {
    renderHistoryTab();
  });
}

// ── History Tab Clear ──────────────────────────────────────────────────────
if (clearHistoryBtn) {
  clearHistoryBtn.addEventListener('click', async () => {
    const confirmed = await showConfirm('confirmClearTitle', 'confirmClearDesc');
    if (confirmed) {
      await clearAllHistory();
      toast(t('toastHistoryCleared'), 'success');
    }
  });
}

// ── Start Download ─────────────────────────────────────────────────────────
fetchBtn.addEventListener('click', async () => {
  sfx.playClick();
  const url = urlInput.value.trim();
  if (!url) { toast(t('toastPasteLink'), 'error'); return; }

  const detectedPlatform = detectPlatform(url);

  fetchBtn.disabled = true;
  fetchBtn.textContent = '...';

  const formatVal = state.format;
  const audioOnly = ['mp3', 'wav', 'm4a'].includes(formatVal);
  const qualityVal = qualitySelect.value;

  try {
    const res = await fetch('/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url,
        format: qualityVal,
        audioOnly: audioOnly,
        ext: formatVal,
        outputPath: state.savePath,
        subtitles: false,
        embedThumbnail: thumbnailToggle.checked,
        cookieSource: state.settings.cookieSource,
        cookieBrowser: state.settings.cookieBrowser,
        cookieFile: state.settings.cookieFile,
        dnsEnabled: state.settings.dnsEnabled,
        dnsProvider: state.settings.dnsProvider,
        customDnsUrl: state.settings.customDnsUrl,
        proxyEnabled: state.settings.proxyEnabled,
        proxyPreset: state.settings.proxyPreset,
        proxyUrl: state.settings.proxyUrl
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed');

    state.activeDownloads.set(data.id, {
      id: data.id,
      url,
      startedAt: new Date().toISOString(),
      title: '',
      status: 'downloading',
      progress: 0, speed: '', eta: '',
      audioOnly: audioOnly,
      ext: formatVal,
      thumbnail: thumbnailToggle.checked ? '' : null,
      platform: detectedPlatform ? detectedPlatform.id : null,
      savePath: state.savePath
    });

    renderDownloads();
    urlInput.value = '';
    updatePlatformBar('');
    toast(t('toastDownloadStarted'), 'success');
  } catch (err) {
    toast('Error: ' + err.message, 'error');
  } finally {
    fetchBtn.disabled = false;
    fetchBtn.textContent = t('btnDownload');
  }
});

// ── Handle Progress ────────────────────────────────────────────────────────
// Track cancelled download IDs so we never accept further updates for them
const cancelledDownloadIds = new Set();

function handleProgress(msg) {
  const { id, download } = msg;

  // If this download was already cancelled, block ALL further updates (including 'done')
  if (cancelledDownloadIds.has(id)) {
    return;
  }

  // If the existing entry is already cancelled/done/error, don't let a stale 'downloading' overwrite it
  const existing = state.activeDownloads.get(id) || {};
  const existingStatus = existing.status;
  if ((existingStatus === 'cancelled' || existingStatus === 'done' || existingStatus === 'error') 
      && download.status === 'downloading') {
    return;
  }

  if (download.status === 'cancelled') {
    cancelledDownloadIds.add(id);
  }

  if (download.status === 'done' || download.status === 'error' || download.status === 'cancelled') {
    if (download.status === 'done') {
      sfx.playComplete();
      const cleanDoneName = (download.title || download.filename || 'File').replace(/\.f\d+(\.[a-zA-Z0-9]+)?$/i, '');
      toast(`✅ ${truncate(cleanDoneName)}`, 'success');
      addToHistory(download);
    }
    if (download.status === 'error') {
      const errLower = (download.error || '').toLowerCase();
      if (errLower.includes('could not resolve host') || errLower.includes('curl: (6)') || errLower.includes('connection timed out') || errLower.includes('curl: (28)')) {
        const blockMsg = state.settings.language === 'th'
          ? '❌ เว็บไซต์นี้ถูกบล็อกโดยอินเทอร์เน็ต (DNS Block) กรุณาเปิดใช้ Proxy หรือ VPN ในหน้า Settings'
          : '❌ Site blocked by ISP DNS. Please enable Proxy or VPN in Settings.';
        toast(blockMsg, 'error');
      } else {
        const errDisplay = download.error || (state.settings.language === 'th' ? 'ดาวน์โหลดล้มเหลว' : 'Download failed');
        toast(`❌ ${truncate(errDisplay, 50)}`, 'error');
      }
      addToHistory(download);
    }
    if (download.status === 'cancelled') {
      addToHistory(download);
    }
  }
  
  state.activeDownloads.set(id, { ...existing, ...download });

  renderDownloads();
}

// ── Render Downloads (Home + Downloads tab) ────────────────────────────────
function renderDownloads() {
  const items = Array.from(state.activeDownloads.values()).sort((a, b) =>
    Date.parse(b.savedAt || b.finishedAt || b.startedAt || 0) - Date.parse(a.savedAt || a.finishedAt || a.startedAt || 0)
  );
  
  if (items.length === 0) {
    emptyState.textContent = t('emptyRecent');
    emptyState.classList.remove('hidden');
    Array.from(activeList.children).forEach(c => { if(c !== emptyState) c.remove(); });
    return;
  }

  emptyState.classList.add('hidden');

  // Smooth in-place DOM diffing (prevents flickering and keeps Cancel button clickable)
  const existingElements = new Map();
  Array.from(activeList.children).forEach(el => {
    if (el !== emptyState && el.getAttribute('data-id')) {
      existingElements.set(el.getAttribute('data-id'), el);
    }
  });

  const validIds = new Set(items.map(i => i.id));

  // Remove stale items
  existingElements.forEach((el, id) => {
    if (!validIds.has(id)) {
      el.remove();
    }
  });

  // Update in place and only move an item when its sort position changes.
  // Re-inserting every card on every progress event restarts its fadeIn
  // animation, which makes the list flicker and interrupts button clicks.
  items.forEach((dl, index) => {
    let el = existingElements.get(dl.id);
    if (el) {
      updateDlItem(el, dl, 'home');
    } else {
      el = makeDlItem(dl, 'home');
    }
    const itemAtIndex = activeList.children[index];
    if (itemAtIndex !== el) {
      activeList.insertBefore(el, itemAtIndex || emptyState);
    }
  });
}

function sanitizeTitle(dl) {
  const raw = dl.title || dl.filename || dl.url || '';
  return raw.replace(/\.f\d+(\.[a-zA-Z0-9]+)?$/i, '');
}

function updateDlItem(item, dl, context = 'home') {
  item.setAttribute('data-id', dl.id);
  
  const progress = Math.min(100, Math.round(dl.progress || 0));
  const isDownloading = dl.status === 'downloading';
  const isDone = dl.status === 'done';
  const ext = (dl.ext || (dl.audioOnly ? 'MP3' : 'MP4')).toUpperCase();
  const platformId = dl.platform || (dl.url ? (detectPlatform(dl.url) || {}).id : null);
  
  let statsText = '';
  if (isDownloading) {
    if (dl.isLive || dl.live_status === 'is_live') {
      statsText = `${progress}% · ${dl.speed || ''} · ${ext} · ${dl.timeSection ? '✂️ Clip' : t('statusLiveRecording')}`;
    } else {
      statsText = `${progress}% · ${dl.speed || ''} · ${ext}`;
    }
  } else if (isDone) {
    statsText = `${t('statusCompleted')} · ${ext}`;
  } else {
    statsText = `${dl.status === 'error' ? t('statusError') : dl.status} · ${ext}`;
  }

  const lastStatus = item.getAttribute('data-status');
  if (lastStatus !== dl.status) {
    item.setAttribute('data-status', dl.status);
    const temp = makeDlItem(dl, context);
    item.innerHTML = temp.innerHTML;
    bindDlItemActions(item, dl, context);
    return;
  }

  const fill = item.querySelector('.dl-progress-fill');
  if (fill) {
    fill.style.width = `${progress}%`;
    if (isDone) fill.style.background = '#4CAF50';
    else if (dl.status === 'error') fill.style.background = '#F44336';
  }

  const stats = item.querySelector('.dl-stats');
  if (stats && stats.textContent !== statsText) {
    stats.textContent = statsText;
  }

  const titleEl = item.querySelector('.dl-title');
  const titleText = sanitizeTitle(dl);
  if (titleEl && titleText && !titleEl.textContent.includes(titleText)) {
    titleEl.innerHTML = `${platformId ? `<span class="dl-platform-badge ${platformId}">${(PLATFORMS.find(p=>p.id===platformId)||{name:platformId}).name}</span>` : ''}${titleText}`;
  }

  const thumbImg = item.querySelector('.dl-thumb');
  if (thumbImg && dl.thumbnail && dl.thumbnail.startsWith('http') && thumbImg.src !== dl.thumbnail) {
    thumbImg.src = dl.thumbnail;
    thumbImg.style.padding = '';
    thumbImg.style.opacity = '';
  }
}

// ── Render History Tab ─────────────────────────────────────────────────────
function renderHistoryTab() {
  if (!historyTabList) return;

  let history = getStoredHistory();
  
  // Apply search filter
  const searchQuery = (historySearchInput?.value || '').trim().toLowerCase();
  if (searchQuery) {
    history = history.filter(h => {
      const title = (h.title || h.filename || h.url || '').toLowerCase();
      return title.includes(searchQuery);
    });
  }

  if (history.length === 0) {
    historyTabList.innerHTML = `<div class="empty-state">${searchQuery ? (state.settings.language === 'th' ? 'ไม่พบรายการที่ค้นหา' : 'No matching items found') : t('emptyHistory')}</div>`;
    return;
  }

  historyTabList.innerHTML = '';
  history.forEach(dl => {
    historyTabList.appendChild(makeDlItem(dl, 'history'));
  });
}

function renderHistory(history) {
  serverHistory = Array.isArray(history) ? history : [];
  const historyIds = new Set(serverHistory.map(h => h.id));

  // Remove stale completed/inactive items from Recent Downloads
  for (const [id, dl] of state.activeDownloads.entries()) {
    if (dl.status !== 'downloading' && !historyIds.has(id)) {
      state.activeDownloads.delete(id);
    }
  }

  // Add history items to active downloads map
  serverHistory.forEach(dl => {
    if (!state.activeDownloads.has(dl.id)) {
      state.activeDownloads.set(dl.id, dl);
    }
  });

  renderDownloads();
  renderHistoryTab();
}

// ── Build Item DOM ─────────────────────────────────────────────────────────
function makeDlItem(dl, context = 'home') {
  const item = document.createElement('div');
  item.className = 'dl-item';
  item.setAttribute('data-id', dl.id);
  item.setAttribute('data-status', dl.status || '');
  
  const progress = Math.min(100, Math.round(dl.progress || 0));
  const isDownloading = dl.status === 'downloading';
  const isDone = dl.status === 'done';
  const ext = (dl.ext || (dl.audioOnly ? 'MP3' : 'MP4')).toUpperCase();
  const platformId = dl.platform || (dl.url ? (detectPlatform(dl.url) || {}).id : null);
  
  let statsText = '';
  if (isDownloading) {
    if (dl.isLive || dl.live_status === 'is_live') {
      statsText = `${progress}% · ${dl.speed || ''} · ${ext} · ${dl.timeSection ? '✂️ Clip' : t('statusLiveRecording')}`;
    } else {
      statsText = `${progress}% · ${dl.speed || ''} · ${ext}`;
    }
  } else if (isDone) {
    statsText = `${t('statusCompleted')} · ${ext}`;
  } else {
    statsText = `${dl.status === 'error' ? t('statusError') : dl.status} · ${ext}`;
  }

  const fallbackSvg = 'data:image/svg+xml;charset=UTF-8,%3csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23ff6b52" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"%3e%3cpolygon points="23 7 16 12 23 17 23 7"%3e%3c/polygon%3e%3crect x="1" y="5" width="15" height="14" rx="2" ry="2"%3e%3c/rect%3e%3c/svg%3e';
  const hasHttpThumb = dl.thumbnail && dl.thumbnail.startsWith('http');
  const thumbSrc = hasHttpThumb ? dl.thumbnail : fallbackSvg;
  const isFallback = !hasHttpThumb;

  const dateStr = formatDate(dl.savedAt || dl.finishedAt || dl.startedAt);
  const titleText = sanitizeTitle(dl);

  let actionsHtml = '';
  if (context === 'history') {
    actionsHtml = `
      <button class="dl-btn btn-redownload" title="${state.settings.language === 'th' ? 'ดาวน์โหลดซ้ำ' : 'Re-download'}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
      </button>
      <button class="dl-btn btn-delete" title="${state.settings.language === 'th' ? 'ลบ' : 'Delete'}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
      </button>`;
  } else if (isDownloading) {
    actionsHtml = `
      <button class="dl-btn btn-cancel" title="Cancel">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
      </button>`;
  } else {
    actionsHtml = `
      <button class="dl-btn" title="Open Folder">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
      </button>`;
  }

  item.innerHTML = `
    <div class="dl-thumb-wrap">
      <img src="${thumbSrc}" class="dl-thumb" style="${isFallback ? 'padding: 16px; opacity: 0.3;' : ''}" onerror="this.onerror=null; this.src='${fallbackSvg}'; this.style.padding='16px'; this.style.opacity='0.3';" />
    </div>
    <div class="dl-info">
      <div class="dl-title">${platformId ? `<span class="dl-platform-badge ${platformId}">${(PLATFORMS.find(p=>p.id===platformId)||{name:platformId}).name}</span>` : ''}${titleText}</div>
      <div class="dl-progress-bar">
        <div class="dl-progress-fill" style="width: ${progress}%; ${isDone ? 'background: #4CAF50;' : (dl.status==='error'?'background: #F44336;':'')}"></div>
      </div>
      <div class="dl-stats">${statsText}</div>
      ${dateStr && context === 'history' ? `<div class="dl-date">${dateStr}</div>` : ''}
    </div>
    <div class="dl-actions">
      ${actionsHtml}
    </div>
  `;

  bindDlItemActions(item, dl, context);

  return item;
}

function bindDlItemActions(item, dl, context = 'home') {
  const isDownloading = dl.status === 'downloading';
  if (context === 'history') {
    const redownloadBtn = item.querySelector('.btn-redownload');
    const deleteBtn = item.querySelector('.btn-delete');
    
    if (redownloadBtn) {
      redownloadBtn.onclick = (e) => {
        e.stopPropagation();
        if (!dl.url) return;
        urlInput.value = dl.url;
        navItems.forEach(n => n.classList.remove('active'));
        document.querySelector('[data-tab="home"]').classList.add('active');
        tabContents.forEach(c => c.classList.add('hidden'));
        document.getElementById('home-tab').classList.remove('hidden');
        toast(t('toastRedownloadStarted'), 'info');
        fetchBtn.click();
      };
    }
    
    if (deleteBtn) {
      deleteBtn.onclick = async (e) => {
        e.stopPropagation();
        const confirmed = await showConfirm('confirmDeleteTitle', 'confirmDeleteDesc');
        if (confirmed) {
          await removeFromHistory(dl.id);
          toast(t('toastItemDeleted'), 'info');
        }
      };
    }
  } else if (isDownloading) {
    const cancelBtn = item.querySelector('.btn-cancel');
    if (cancelBtn) {
      cancelBtn.onclick = async (e) => {
        e.stopPropagation();
        cancelBtn.disabled = true;
        try {
          await fetch(`/api/cancel/${dl.id}`, { method: 'POST' });
          toast(t('toastCancelled'), 'info');
        } catch(err) {}
      };
    }
  } else {
    const folderBtn = item.querySelector('.dl-actions button');
    if (folderBtn) {
      folderBtn.onclick = async (e) => {
        e.stopPropagation();
        const folderPath = dl.outputDir || dl.savePath || state.savePath || '';
        const fileName = dl.filename || '';
        await fetch(`/api/open-folder?path=${encodeURIComponent(folderPath)}&file=${encodeURIComponent(fileName)}`);
      };
    }
  }
}

// ── Window Controls ────────────────────────────────────────────────────────
if (winMinBtn) winMinBtn.addEventListener('click', () => window.electronAPI?.minimize());
if (winMaxBtn) winMaxBtn.addEventListener('click', () => window.electronAPI?.maximize());
if (winCloseBtn) winCloseBtn.addEventListener('click', () => window.electronAPI?.close());

if (window.electronAPI?.onMaximizedStatus && winMaxBtn) {
  window.electronAPI.onMaximizedStatus((isMaximized) => {
    document.body.classList.toggle('maximized', isMaximized);
    if (isMaximized) {
      winMaxBtn.title = state.settings.language === 'th' ? 'ย่อขนาดลง' : 'Restore';
      winMaxBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="8" y="4" width="12" height="12" rx="1.5" ry="1.5"/><path d="M4 8v10a2 2 0 0 0 2 2h10"/></svg>`;
    } else {
      winMaxBtn.title = state.settings.language === 'th' ? 'ขยายหน้าจอ' : 'Maximize';
      winMaxBtn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="5" y="5" width="14" height="14" rx="2" ry="2"/></svg>`;
    }
  });
}

// ── Settings Handlers ──────────────────────────────────────────────────────
// Debounced server state patch — merges pending patches so rapid calls don't lose data
let _patchTimer = null;
let _pendingPatch = {};
function patchServerState(partial) {
  // Deep-merge into pending patch so no data is lost
  for (const key of Object.keys(partial)) {
    if (typeof partial[key] === 'object' && partial[key] !== null && !Array.isArray(partial[key])
        && typeof _pendingPatch[key] === 'object' && _pendingPatch[key] !== null) {
      _pendingPatch[key] = { ..._pendingPatch[key], ...partial[key] };
    } else {
      _pendingPatch[key] = partial[key];
    }
  }
  clearTimeout(_patchTimer);
  _patchTimer = setTimeout(async () => {
    const toSend = _pendingPatch;
    _pendingPatch = {};
    try {
      await fetch('/api/app-state', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toSend)
      });
    } catch {}
  }, 200);
}

function saveSettings() {
  patchServerState({ settings: state.settings });
}

function saveDownloadDefaults() {
  patchServerState({ downloadDefaults: {
    savePath: state.savePath,
    converterSavePath: state.converterSavePath,
    format: state.format,
    quality: document.getElementById('qualitySelect')?.value || 'best',
    embedThumbnail: document.getElementById('thumbnailToggle')?.checked !== false
  }});
}

function saveActiveTab(tab) {
  patchServerState({ ui: { activeTab: tab } });
}

async function loadSettings() {
  try {
    const res = await fetch('/api/app-state');
    const serverState = await res.json();
    if (serverState.settings) {
      state.settings = { ...state.settings, ...serverState.settings };
    }
    if (serverState.downloadDefaults) {
      if (serverState.downloadDefaults.savePath) {
        state.savePath = serverState.downloadDefaults.savePath;
        if (savePathInput) savePathInput.value = state.savePath;
      }
      if (serverState.downloadDefaults.converterSavePath) {
        state.converterSavePath = serverState.downloadDefaults.converterSavePath;
        if (converterSavePathInput) converterSavePathInput.value = state.converterSavePath;
      }
      if (serverState.downloadDefaults.format) {
        state.format = serverState.downloadDefaults.format;
        formatBtns.forEach(btn => {
          btn.classList.toggle('active', btn.dataset.val === state.format);
        });
        if (['mp3', 'wav', 'm4a'].includes(state.format)) {
          if (qualitySelect) qualitySelect.disabled = true;
        } else {
          if (qualitySelect) qualitySelect.disabled = false;
        }
      }
      if (serverState.downloadDefaults.quality && qualitySelect) {
        qualitySelect.value = serverState.downloadDefaults.quality;
      }
      if (serverState.downloadDefaults.embedThumbnail !== undefined && thumbnailToggle) {
        thumbnailToggle.checked = Boolean(serverState.downloadDefaults.embedThumbnail);
      }
    }
    setActiveTab('home');
    if (serverState.history) {
      serverHistory = serverState.history;
    }
  } catch {}
  applySettings();
}

function applySettings() {
  // 1. Theme
  if (state.settings.theme === 'dark') {
    document.body.classList.add('dark-theme');
    if (themeToggle) themeToggle.checked = true;
  } else {
    document.body.classList.remove('dark-theme');
    if (themeToggle) themeToggle.checked = false;
  }

  // 2. Always on Top & Run in Background
  if (alwaysOnTopToggle) alwaysOnTopToggle.checked = state.settings.alwaysOnTop;
  window.electronAPI?.setAlwaysOnTop(state.settings.alwaysOnTop);

  if (runInBackgroundToggle) runInBackgroundToggle.checked = state.settings.runInBackground !== false;
  window.electronAPI?.setRunInBackground(state.settings.runInBackground !== false);
  if (startMinimizedToggle) startMinimizedToggle.checked = state.settings.startMinimized === true;
  if (openOnStartupToggle) openOnStartupToggle.checked = state.settings.openOnStartup === true;

  // 3. Cookies Source
  cookieSourceRadios.forEach(radio => {
    if (radio.value === state.settings.cookieSource) {
      radio.checked = true;
    }
  });

  const browserCookieTip = document.getElementById('browserCookieTip');
  const fileCookieTip = document.getElementById('fileCookieTip');

  if (state.settings.cookieSource === 'browser') {
    browserCookieSection?.classList.remove('hidden');
    fileCookieSection?.classList.add('hidden');
    browserCookieTip?.classList.remove('hidden');
    fileCookieTip?.classList.add('hidden');
  } else if (state.settings.cookieSource === 'file') {
    browserCookieSection?.classList.add('hidden');
    fileCookieSection?.classList.remove('hidden');
    browserCookieTip?.classList.add('hidden');
    fileCookieTip?.classList.remove('hidden');
  } else {
    browserCookieSection?.classList.add('hidden');
    fileCookieSection?.classList.add('hidden');
    browserCookieTip?.classList.add('hidden');
    fileCookieTip?.classList.add('hidden');
  }

  if (cookieBrowserSelect) cookieBrowserSelect.value = state.settings.cookieBrowser;
  if (cookieFilePathInput) cookieFilePathInput.value = state.settings.cookieFile || '';

  // 4. Secure DNS
  if (dnsToggle) dnsToggle.checked = state.settings.dnsEnabled !== false;
  if (dnsProviderSelect) dnsProviderSelect.value = state.settings.dnsProvider || 'cloudflare';
  if (customDnsInput) customDnsInput.value = state.settings.customDnsUrl || '';

  if (state.settings.dnsEnabled !== false) {
    dnsProviderSection?.classList.remove('hidden');
    if (state.settings.dnsProvider === 'custom') {
      customDnsSection?.classList.remove('hidden');
    } else {
      customDnsSection?.classList.add('hidden');
    }
  } else {
    dnsProviderSection?.classList.add('hidden');
    customDnsSection?.classList.add('hidden');
  }

  // 5. Proxy
  if (proxyToggle) proxyToggle.checked = state.settings.proxyEnabled || false;
  if (proxyPresetSelect) proxyPresetSelect.value = state.settings.proxyPreset || 'warp';
  if (proxyUrlInput) proxyUrlInput.value = state.settings.proxyUrl || '';

  if (state.settings.proxyEnabled) {
    proxyPresetSection?.classList.remove('hidden');
    if (state.settings.proxyPreset === 'custom') {
      proxyUrlSection?.classList.remove('hidden');
    } else {
      proxyUrlSection?.classList.add('hidden');
    }
  } else {
    proxyPresetSection?.classList.add('hidden');
    proxyUrlSection?.classList.add('hidden');
  }

  // 5. Auto-delete days
  if (autoDeleteDaysSelect) autoDeleteDaysSelect.value = state.settings.autoDeleteDays || '0';

  // 6. Language
  applyI18n();

  // 7. Zoom Level
  if (state.settings.zoomLevel) {
    window.electronAPI?.setZoomFactor(parseFloat(state.settings.zoomLevel));
    if (zoomSelect) zoomSelect.value = state.settings.zoomLevel.toString();
  }

  // 8. Assets Finder API Keys
  const pxInput = document.getElementById('pixabayApiKeyInput');
  const gpInput = document.getElementById('giphyApiKeyInput');
  if (pxInput) pxInput.value = state.settings.pixabayApiKey || '';
  if (gpInput) gpInput.value = state.settings.giphyApiKey || '';

  // 9. Sound Effects
  if (soundEffectsToggle) soundEffectsToggle.checked = sfx.enabled;
  if (quickSoundIcon) quickSoundIcon.textContent = sfx.enabled ? '🔊' : '🔇';
  if (quickSoundBtn) quickSoundBtn.title = sfx.enabled ? 'Sound Enabled (Click to mute)' : 'Sound Muted (Click to unmute)';
  if (soundVolumeSlider) soundVolumeSlider.value = Math.round(sfx.volume * 100);
  if (soundVolumeLabel) soundVolumeLabel.textContent = `${Math.round(sfx.volume * 100)}%`;
}

// Wire sound controls
if (quickSoundBtn) {
  quickSoundBtn.addEventListener('click', () => {
    sfx.setEnabled(!sfx.enabled);
    applySettings();
    if (sfx.enabled) sfx.playSuccess();
  });
}

if (soundEffectsToggle) {
  soundEffectsToggle.addEventListener('change', (e) => {
    sfx.setEnabled(e.target.checked);
    applySettings();
    if (sfx.enabled) sfx.playSuccess();
  });
}

if (soundVolumeSlider) {
  soundVolumeSlider.addEventListener('input', (e) => {
    const val = parseInt(e.target.value, 10) || 0;
    sfx.setVolume(val / 100);
    if (soundVolumeLabel) soundVolumeLabel.textContent = `${val}%`;
  });
}

if (soundTestBtn) {
  soundTestBtn.addEventListener('click', () => {
    sfx.playSuccess();
  });
}

// Wire settings DOM listeners
if (themeToggle) {
  themeToggle.addEventListener('change', (e) => {
    state.settings.theme = e.target.checked ? 'dark' : 'light';
    saveSettings();
    applySettings();
  });
}

if (alwaysOnTopToggle) {
  alwaysOnTopToggle.addEventListener('change', (e) => {
    state.settings.alwaysOnTop = e.target.checked;
    saveSettings();
    applySettings();
  });
}

if (runInBackgroundToggle) {
  runInBackgroundToggle.addEventListener('change', (e) => {
    state.settings.runInBackground = e.target.checked;
    saveSettings();
    applySettings();
  });
}

if (startMinimizedToggle) {
  startMinimizedToggle.addEventListener('change', (e) => {
    state.settings.startMinimized = e.target.checked;
    saveSettings();
  });
}

if (openOnStartupToggle) {
  openOnStartupToggle.addEventListener('change', (e) => {
    state.settings.openOnStartup = e.target.checked;
    saveSettings();
    window.electronAPI?.setOpenOnStartup(e.target.checked);
  });
}

if (zoomSelect) {
  zoomSelect.addEventListener('change', (e) => {
    state.settings.zoomLevel = parseFloat(e.target.value);
    saveSettings();
    applySettings();
  });
}

cookieSourceRadios.forEach(radio => {
  radio.addEventListener('change', (e) => {
    state.settings.cookieSource = e.target.value;
    saveSettings();
    applySettings();
  });
});

if (cookieBrowserSelect) {
  cookieBrowserSelect.addEventListener('change', (e) => {
    state.settings.cookieBrowser = e.target.value;
    saveSettings();
  });
}

if (cookieFileBrowseBtn) {
  cookieFileBrowseBtn.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/select-file');
      const data = await res.json();
      if (data.path) {
        state.settings.cookieFile = data.path;
        saveSettings();
        applySettings();
      }
    } catch (err) {
      toast(t('toastCannotBrowseCookie'), 'error');
    }
  });
}

if (dnsToggle) {
  dnsToggle.addEventListener('change', (e) => {
    state.settings.dnsEnabled = e.target.checked;
    saveSettings();
    applySettings();
  });
}

if (dnsProviderSelect) {
  dnsProviderSelect.addEventListener('change', (e) => {
    state.settings.dnsProvider = e.target.value;
    saveSettings();
    applySettings();
  });
}

if (customDnsInput) {
  customDnsInput.addEventListener('input', (e) => {
    state.settings.customDnsUrl = e.target.value.trim();
    saveSettings();
  });
}

if (proxyToggle) {
  proxyToggle.addEventListener('change', (e) => {
    state.settings.proxyEnabled = e.target.checked;
    saveSettings();
    applySettings();
  });
}

if (proxyPresetSelect) {
  proxyPresetSelect.addEventListener('change', (e) => {
    state.settings.proxyPreset = e.target.value;
    saveSettings();
    applySettings();
  });
}

if (proxyUrlInput) {
  proxyUrlInput.addEventListener('input', (e) => {
    state.settings.proxyUrl = e.target.value.trim();
    saveSettings();
  });
}

// Manual yt-dlp update button
const updateYtdlpBtn = document.getElementById('updateYtdlpBtn');
if (updateYtdlpBtn) {
  updateYtdlpBtn.addEventListener('click', async () => {
    updateYtdlpBtn.disabled = true;
    updateYtdlpBtn.textContent = '...';
    try {
      const res = await fetch('/api/update-ytdlp', { method: 'POST' });
      const data = await res.json();
      renderYtDlpStatus(data);
      if (data.status === 'updated') {
        toast(t('toastYtdlpUpdated'), 'success');
      } else if (data.status === 'up-to-date') {
        toast(t('toastYtdlpUpToDate'), 'info');
      } else if (data.status === 'error') {
        toast('yt-dlp update error: ' + data.message, 'error');
      }
    } catch (e) {
      toast('Failed to trigger update', 'error');
    } finally {
      updateYtdlpBtn.disabled = false;
      updateYtdlpBtn.textContent = t('btnUpdateEngine');
    }
  });
}

// Auto-delete days selector
if (autoDeleteDaysSelect) {
  autoDeleteDaysSelect.addEventListener('change', (e) => {
    state.settings.autoDeleteDays = parseInt(e.target.value);
    saveSettings();
    autoDeleteOldHistory();
    renderHistoryTab();
  });
}

// Clear all history button in settings
if (clearAllHistoryBtn) {
  clearAllHistoryBtn.addEventListener('click', async () => {
    const confirmed = await showConfirm('confirmClearTitle', 'confirmClearDesc');
    if (confirmed) {
      await clearAllHistory();
      toast(t('toastHistoryCleared'), 'success');
    }
  });
}

// API Key inputs for Assets Finder
const pixabayApiKeyInput = document.getElementById('pixabayApiKeyInput');
const giphyApiKeyInput = document.getElementById('giphyApiKeyInput');

if (pixabayApiKeyInput) {
  pixabayApiKeyInput.addEventListener('change', () => {
    state.settings.pixabayApiKey = pixabayApiKeyInput.value.trim();
    saveSettings();
  });
}
if (giphyApiKeyInput) {
  giphyApiKeyInput.addEventListener('change', () => {
    state.settings.giphyApiKey = giphyApiKeyInput.value.trim();
    saveSettings();
  });
}

// Restore to Default button in settings
const restoreDefaultsBtn = document.getElementById('restoreDefaultsBtn');
if (restoreDefaultsBtn) {
  restoreDefaultsBtn.addEventListener('click', async () => {
    const confirmed = await showConfirm('confirmRestoreTitle', 'confirmRestoreDesc');
    if (confirmed) {
      try {
        const res = await fetch('/api/restore-defaults', { method: 'POST' });
        const fresh = await res.json();
        // Apply the fresh state to the UI
        if (fresh.settings) {
          state.settings = { ...state.settings, ...fresh.settings };
        }
        if (fresh.downloadDefaults) {
          if (fresh.downloadDefaults.savePath) {
            state.savePath = fresh.downloadDefaults.savePath;
            const savePathInput = document.getElementById('savePathInput');
            if (savePathInput) savePathInput.value = state.savePath;
          }
          if (fresh.downloadDefaults.converterSavePath) {
            state.converterSavePath = fresh.downloadDefaults.converterSavePath;
            const converterSavePathInput = document.getElementById('converterSavePathInput');
            if (converterSavePathInput) converterSavePathInput.value = state.converterSavePath;
          }
          if (fresh.downloadDefaults.format) {
            state.format = fresh.downloadDefaults.format;
            formatBtns.forEach(btn => {
              btn.classList.toggle('active', btn.dataset.val === state.format);
            });
          }
          if (qualitySelect) qualitySelect.value = fresh.downloadDefaults.quality || 'best';
          if (thumbnailToggle) thumbnailToggle.checked = fresh.downloadDefaults.embedThumbnail !== false;
        }
        serverHistory = fresh.history || [];
        renderDownloads();
        renderHistoryTab();
        applySettings();
        toast(t('toastRestoredDefaults'), 'success');
      } catch {}
    }
  });
}

// Language toggle buttons
langBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    state.settings.language = btn.dataset.lang;
    saveSettings();
    applySettings();
    // Re-render dynamic content
    renderDownloads();
    renderHistoryTab();
    renderConverterQueue();
  });
});

// ── File Converter Logic ───────────────────────────────────────────────────
const converterFiles = [];

const FORMAT_OPTIONS = {
  video: ['mp4', 'mkv', 'avi', 'mov', 'webm', 'mp3', 'wav', 'm4a', 'aac', 'ogg', 'flac'],
  audio: ['mp3', 'wav', 'm4a', 'aac', 'ogg', 'flac', 'opus'],
  image: ['png', 'jpg', 'webp', 'bmp', 'gif', 'tiff']
};

function getFileCategory(filename) {
  const ext = filename.split('.').pop().toLowerCase();
  const videoExts = ['mp4','mkv','avi','mov','wmv','flv','webm','m4v','3gp','ts','m2ts'];
  const audioExts = ['mp3','wav','m4a','aac','ogg','flac','wma','opus','alac'];
  const imageExts = ['png','jpg','jpeg','gif','bmp','tiff','tif','webp','svg','ico','heic','heif','avif'];
  if (videoExts.includes(ext)) return 'video';
  if (audioExts.includes(ext)) return 'audio';
  if (imageExts.includes(ext)) return 'image';
  return 'video'; // default
}

function getCategoryEmoji(category) {
  if (category === 'video') return '🎬';
  if (category === 'audio') return '🎵';
  if (category === 'image') return '🖼️';
  return '📄';
}

function getDefaultOutputFormat(filename, category) {
  const ext = filename.split('.').pop().toLowerCase();
  const options = FORMAT_OPTIONS[category] || FORMAT_OPTIONS.video;
  // Pick first format that's different from input
  for (const fmt of options) {
    if (fmt !== ext) return fmt;
  }
  return options[0];
}

function addConverterFiles(files) {
  const newFiles = files.map(f => {
    const category = getFileCategory(f.name || f.path);
    return {
      id: 'cf-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8),
      name: f.name || f.path,
      path: f.path || null,
      size: f.size || 0,
      mimeType: f.type || '',
      category,
      scannedCategory: null,
      scannedFormat: null,
      outputFormat: getDefaultOutputFormat(f.name || f.path, category),
      quality: 'high',
      status: 'pending', // pending | converting | done | error | cancelled
      progress: 0,
      serverId: null // server-side conversion ID
    };
  });
  // Keep the newest additions first while preserving their selection order.
  converterFiles.unshift(...newFiles);
  scanConverterFiles(newFiles);
  renderConverterQueue();
  if (files.length > 0) toast(t('toastFilesAdded'), 'success');
}

function scanConverterFiles(files) {
  files.forEach(file => {
    const ext = file.name.split('.').pop().toLowerCase();
    let category = getFileCategory(file.name);
    if (!['video', 'audio', 'image'].includes(category)) {
      if (file.mimeType.startsWith('image/')) category = 'image';
      else if (file.mimeType.startsWith('audio/')) category = 'audio';
      else if (file.mimeType.startsWith('video/')) category = 'video';
    }
    file.scannedCategory = category;
    file.scannedFormat = ext || file.mimeType.split('/').pop() || 'unknown';
  });
  const counts = converterFiles.reduce((result, file) => {
    result[file.scannedCategory] = (result[file.scannedCategory] || 0) + 1;
    return result;
  }, {});
  converterScanResult.textContent = `${t('converterScanComplete')}: ${converterFiles.length} · ${t('converterTypeImage')} ${counts.image || 0} · ${t('converterTypeVideo')} ${counts.video || 0} · ${t('converterTypeAudio')} ${counts.audio || 0}`;
}

async function browseConverterFiles() {
  try {
    const res = await fetch('/api/select-convert-files');
    const data = await res.json();
    if (data.files && data.files.length > 0) {
      addConverterFiles(data.files);
      return;
    }

    // A cancelled Electron dialog returns no files; do not open a second dialog.
    if (navigator.userAgent.toLowerCase().includes(' electron/')) return;
  } catch (err) {
    // Fall back to the browser's file chooser when the Electron dialog is unavailable.
  }

  converterFileInput?.click();
}

// Drag & Drop
if (converterDropzone) {
  converterDropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    converterDropzone.classList.add('drag-over');
  });
  converterDropzone.addEventListener('dragleave', () => {
    converterDropzone.classList.remove('drag-over');
  });
  converterDropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    converterDropzone.classList.remove('drag-over');
    const droppedFiles = Array.from(e.dataTransfer.files);
    if (droppedFiles.length > 0) {
      // For dropped files, we use the path from Electron
      const fileInfos = droppedFiles.map(f => ({
        name: f.name,
        path: f.path, // Electron provides this
        size: f.size
      }));
      addConverterFiles(fileInfos);
    }
  });
  converterDropzone.addEventListener('click', browseConverterFiles);
}

if (converterBrowseBtn) {
  converterBrowseBtn.addEventListener('click', async () => {
    try {
      const currentPath = encodeURIComponent(state.converterSavePath || state.savePath || '');
      const res = await fetch(`/api/select-folder?current=${currentPath}`);
      const data = await res.json();
      if (data.path) {
        state.converterSavePath = data.path;
        converterSavePathInput.value = data.path;
        saveDownloadDefaults();
      }
    } catch (err) {
      toast(t('toastCannotBrowse'), 'error');
    }
  });
}

if (converterFileInput) {
  converterFileInput.addEventListener('change', (e) => {
    const files = Array.from(e.target.files);
    const fileInfos = files.map(f => ({
      name: f.name,
      path: f.path || f.name,
      size: f.size,
      type: f.type
    }));
    addConverterFiles(fileInfos);
    converterFileInput.value = '';
  });
}

function renderConverterQueue() {
  if (!converterQueue || !converterEmpty) return;
  
  if (converterFiles.length === 0) {
    converterQueue.innerHTML = '';
    converterEmpty.classList.remove('hidden');
    return;
  }

  converterEmpty.classList.add('hidden');
  converterQueue.innerHTML = '';

  converterFiles.forEach((file, index) => {
    const item = document.createElement('div');
    item.className = 'convert-item';
    
    const inputExt = file.name.split('.').pop().toUpperCase();
    const isConverting = file.status === 'converting';
    const isDone = file.status === 'done';
    const isError = file.status === 'error';
    const isPending = file.status === 'pending';

    const formatOptions = FORMAT_OPTIONS[file.category] || FORMAT_OPTIONS.video;

    let statusText = '';
    if (isConverting) statusText = `${t('converterConverting')} ${file.progress}%`;
    else if (isDone) statusText = t('converterDone');
    else if (isError) statusText = t('converterError');
    else statusText = `${inputExt} → ${file.outputFormat.toUpperCase()}`;

    const progressClass = isDone ? 'done' : isError ? 'error' : '';

    item.innerHTML = `
      <div class="convert-file-icon ${file.category}">
        ${getCategoryEmoji(file.category)}
      </div>
      <div class="convert-item-info">
        <div class="convert-item-name">${file.name}</div>
        <div class="convert-item-meta">
          <span class="convert-item-size">${formatSize(file.size)}</span>
          <span class="convert-arrow">→</span>
          ${isPending ? `
            <select class="convert-format-select" data-index="${index}">
              ${formatOptions.map(fmt => `<option value="${fmt}" ${fmt === file.outputFormat ? 'selected' : ''}>${fmt.toUpperCase()}</option>`).join('')}
            </select>
            <select class="convert-quality-select" data-index="${index}">
              <option value="high" ${file.quality === 'high' ? 'selected' : ''}>${t('qualityHigh')}</option>
              <option value="medium" ${file.quality === 'medium' ? 'selected' : ''}>${t('qualityMedium')}</option>
              <option value="low" ${file.quality === 'low' ? 'selected' : ''}>${t('qualityLow')}</option>
            </select>
          ` : `<span class="convert-item-size">${file.outputFormat.toUpperCase()}</span>`}
        </div>
        ${(isConverting || isDone || isError) ? `
          <div class="convert-item-progress">
            <div class="convert-item-progress-fill ${progressClass}" style="width: ${file.progress}%"></div>
          </div>
        ` : ''}
        <div class="convert-item-status">${statusText}</div>
        ${file.scannedCategory ? `<div class="convert-item-scan-result">${t(file.scannedCategory === 'image' ? 'converterTypeImage' : file.scannedCategory === 'audio' ? 'converterTypeAudio' : 'converterTypeVideo')} · ${file.scannedFormat.toUpperCase()}</div>` : ''}
      </div>
      <div class="convert-item-actions">
        ${isPending ? `
          <button class="convert-btn convert-btn-start" title="Convert" data-action="start" data-index="${index}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          </button>
        ` : ''}
        ${isConverting ? `
          <button class="convert-btn convert-btn-cancel" title="Cancel" data-action="cancel" data-index="${index}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>
          </button>
        ` : ''}
        ${(isPending || isDone || isError) ? `
          ${isDone && file.outputPath ? `
            <button class="convert-btn convert-btn-location" title="Open media location" data-action="open-location" data-index="${index}">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M12 11v6m-3-3 3-3 3 3"/></svg>
            </button>
          ` : ''}
          <button class="convert-btn convert-btn-remove" title="Remove" data-action="remove" data-index="${index}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        ` : ''}
      </div>
    `;

    // Event listeners
    const formatSelect = item.querySelector('.convert-format-select');
    if (formatSelect) {
      formatSelect.addEventListener('change', (e) => {
        converterFiles[index].outputFormat = e.target.value;
      });
    }

    const qualitySelect = item.querySelector('.convert-quality-select');
    if (qualitySelect) {
      qualitySelect.addEventListener('change', (e) => {
        converterFiles[index].quality = e.target.value;
      });
    }

    const actionBtns = item.querySelectorAll('[data-action]');
    actionBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        const idx = parseInt(btn.dataset.index);
        if (action === 'start') startConversion(idx);
        else if (action === 'cancel') cancelConversion(idx);
        else if (action === 'open-location') openConvertedFileLocation(idx);
        else if (action === 'remove') removeConverterFile(idx);
      });
    });

    converterQueue.appendChild(item);
  });
}

async function startConversion(index) {
  const file = converterFiles[index];
  if (!file || file.status !== 'pending') return;

  file.status = 'converting';
  file.progress = 0;
  renderConverterQueue();

  try {
    const res = await fetch('/api/convert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        inputPath: file.path,
        outputFormat: file.outputFormat,
        quality: file.quality,
        outputPath: state.converterSavePath
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed');
    file.serverId = data.id;
    toast(t('toastConvertStarted'), 'info');
  } catch (err) {
    file.status = 'error';
    toast(t('toastConvertError') + ': ' + err.message, 'error');
  }
  renderConverterQueue();
}

async function cancelConversion(index) {
  const file = converterFiles[index];
  if (!file || !file.serverId) return;

  try {
    await fetch(`/api/cancel-convert/${file.serverId}`, { method: 'POST' });
    file.status = 'cancelled';
    toast(t('converterCancelled'), 'info');
  } catch (err) {}
  renderConverterQueue();
}

function removeConverterFile(index) {
  converterFiles.splice(index, 1);
  renderConverterQueue();
}

async function openConvertedFileLocation(index) {
  const outputPath = converterFiles[index]?.outputPath;
  if (!outputPath) return;
  try {
    await fetch(`/api/open-folder?path=${encodeURIComponent(outputPath)}`);
  } catch (err) {
    toast(t('toastCannotBrowse'), 'error');
  }
}

function handleConvertProgress(msg) {
  const { id, conversion } = msg;
  const file = converterFiles.find(f => f.serverId === id);
  if (!file) return;

  file.progress = conversion.progress || 0;
  file.status = conversion.status;
  if (conversion.outputPath) file.outputPath = conversion.outputPath;

  if (conversion.status === 'done') {
    sfx.playComplete();
    toast(`✅ ${truncate(conversion.outputName || 'File')}`, 'success');
  } else if (conversion.status === 'error') {
    toast(t('toastConvertError'), 'error');
  }

  renderConverterQueue();
}

// ── Clipper (Trim & Download) Logic ─────────────────────────────────────────
const clipperUrlInput       = document.getElementById('clipperUrlInput');
const clipperFetchBtn       = document.getElementById('clipperFetchBtn');
const clipperPreviewCard    = document.getElementById('clipperPreviewCard');
const clipperThumbImg       = document.getElementById('clipperThumbImg');
const clipperDurationBadge  = document.getElementById('clipperDurationBadge');
const clipperVideoTitle     = document.getElementById('clipperVideoTitle');
const clipperVideoAuthor    = document.getElementById('clipperVideoAuthor');
const clipperLiveTag        = document.getElementById('clipperLiveTag');
const clipperTotalDurTag    = document.getElementById('clipperTotalDurTag');
const clipStartTimeInput    = document.getElementById('clipStartTime');
const clipEndTimeInput      = document.getElementById('clipEndTime');
const clipCalcDurationEl    = document.getElementById('clipCalcDuration');
const clipperFormatBtns     = document.querySelectorAll('.clipper-format-btn');
const clipperQualitySelect  = document.getElementById('clipperQualitySelect');
const clipperSavePathInput  = document.getElementById('clipperSavePath');
const clipperBrowseBtn      = document.getElementById('clipperBrowseBtn');
const clipperDownloadBtn    = document.getElementById('clipperDownloadBtn');
const clipperPresetBtns     = document.querySelectorAll('.btn-preset');
const clipperTimeStepBtns   = document.querySelectorAll('.time-step-btn');

let clipperState = {
  format: 'mp4',
  videoInfo: null,
  totalDuration: 0,
  isLive: false
};

function parseTimeToSec(str) {
  if (!str) return 0;
  const clean = String(str).trim();
  if (!clean) return 0;

  if (clean.includes(':')) {
    const parts = clean.split(':').map(p => {
      const num = parseInt(p, 10);
      return isNaN(num) ? 0 : num;
    });
    if (parts.length >= 3) {
      const hrs = parts[0];
      const mins = parts[1];
      const secs = parts[2];
      return Math.max(0, hrs * 3600 + mins * 60 + secs);
    }
    if (parts.length === 2) {
      const mins = parts[0];
      const secs = parts[1];
      return Math.max(0, mins * 60 + secs);
    }
    if (parts.length === 1) {
      return Math.max(0, parts[0]);
    }
  }

  const num = parseInt(clean, 10);
  return isNaN(num) ? 0 : Math.max(0, num);
}

function formatSecToTime(totalSec, forceHours = true) {
  const s = Math.max(0, Math.floor(totalSec || 0));
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;
  const pad = n => String(n).padStart(2, '0');
  if (forceHours || hrs > 0) {
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }
  return `${pad(mins)}:${pad(secs)}`;
}

function normalizeTimeInputField(input) {
  if (!input) return;
  const sec = parseTimeToSec(input.value);
  let clampedSec = sec;
  if (clipperState.totalDuration > 0 && input === clipEndTimeInput) {
    clampedSec = Math.min(clipperState.totalDuration, sec);
  }
  input.value = formatSecToTime(clampedSec, true);
  updateClipCalcDuration();
}

function updateClipCalcDuration() {
  if (!clipStartTimeInput || !clipEndTimeInput || !clipCalcDurationEl) return;
  const startSec = parseTimeToSec(clipStartTimeInput.value);
  const endSec = parseTimeToSec(clipEndTimeInput.value);
  const diff = Math.max(0, endSec - startSec);
  clipCalcDurationEl.textContent = formatSecToTime(diff, true);
  if (endSec <= startSec) {
    clipCalcDurationEl.style.color = '#E53935';
  } else {
    clipCalcDurationEl.style.color = '';
  }
}

function attachTimeInputMask(input) {
  if (!input) return;

  let activeSegment = 2; // 0: Hours [0,1], 1: Minutes [3,4], 2: Seconds [6,7]
  let typedBuffer = '';

  function getSegmentIndices(seg) {
    if (seg === 0) return [0, 1];
    if (seg === 1) return [3, 4];
    return [6, 7];
  }

  function getSegmentFromPos(pos) {
    if (pos <= 2) return 0;
    if (pos <= 5) return 1;
    return 2;
  }

  function parseCurrentValues() {
    const raw = (input.value || '00:00:00').trim();
    const parts = raw.split(':').map(p => parseInt(p, 10) || 0);
    return {
      hours: parts[0] || 0,
      minutes: parts[1] || 0,
      seconds: parts[2] || 0
    };
  }

  function commitAndNormalize() {
    let { hours, minutes, seconds } = parseCurrentValues();
    if (typedBuffer.length > 0) {
      const num = parseInt(typedBuffer, 10) || 0;
      if (activeSegment === 0) hours = num;
      else if (activeSegment === 1) minutes = num;
      else if (activeSegment === 2) seconds = num;
      typedBuffer = '';
    }

    // Mathematical carry-over: remainder stays in current position, quotient carries to higher position
    let secRem = seconds % 60;
    let carryMin = Math.floor(seconds / 60);

    let totalMin = minutes + carryMin;
    let minRem = totalMin % 60;
    let carryHrs = Math.floor(totalMin / 60);

    let totalHrs = hours + carryHrs;

    const pad = n => String(n).padStart(2, '0');
    let formatted = `${pad(totalHrs)}:${pad(minRem)}:${pad(secRem)}`;

    if (clipperState.totalDuration > 0 && input === clipEndTimeInput) {
      const totalSec = totalHrs * 3600 + minRem * 60 + secRem;
      if (totalSec > clipperState.totalDuration) {
        formatted = formatSecToTime(clipperState.totalDuration, true);
      }
    }

    input.value = formatted;
    updateClipCalcDuration();
  }

  function selectActiveSegment() {
    const [tens, ones] = getSegmentIndices(activeSegment);
    input.setSelectionRange(tens, ones + 1);
  }

  // When clicking into any segment, commit previous and select clicked segment
  input.addEventListener('mouseup', () => {
    commitAndNormalize();
    const pos = input.selectionStart;
    activeSegment = getSegmentFromPos(pos);
    typedBuffer = '';
    selectActiveSegment();
  });

  input.addEventListener('focus', () => {
    commitAndNormalize();
    selectActiveSegment();
  });

  input.addEventListener('keydown', (e) => {
    if (['Tab', 'Home', 'End'].includes(e.key) || e.ctrlKey || e.metaKey || e.altKey) {
      return;
    }

    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      commitAndNormalize();
      activeSegment = (activeSegment + 2) % 3; // Move to previous segment
      typedBuffer = '';
      selectActiveSegment();
      return;
    }

    if (e.key === 'ArrowRight') {
      e.preventDefault();
      commitAndNormalize();
      activeSegment = (activeSegment + 1) % 3; // Move to next segment
      typedBuffer = '';
      selectActiveSegment();
      return;
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      commitAndNormalize();

      // Enter advances cursor to next position
      if (activeSegment < 2) {
        activeSegment++;
        typedBuffer = '';
        selectActiveSegment();
      } else {
        // At seconds (end of current input): advance to next input field
        typedBuffer = '';
        if (input === clipStartTimeInput && clipEndTimeInput) {
          clipEndTimeInput.focus();
          const [t, o] = getSegmentIndices(0);
          clipEndTimeInput.setSelectionRange(t, o + 1);
        } else {
          activeSegment = 0;
          selectActiveSegment();
        }
      }
      return;
    }

    if (e.key === 'Backspace') {
      e.preventDefault();
      if (typedBuffer.length > 0) {
        typedBuffer = typedBuffer.slice(0, -1);
      }
      let { hours, minutes, seconds } = parseCurrentValues();
      if (typedBuffer.length > 0) {
        const num = parseInt(typedBuffer, 10) || 0;
        if (activeSegment === 0) hours = num;
        else if (activeSegment === 1) minutes = num;
        else if (activeSegment === 2) seconds = num;
      } else {
        if (activeSegment === 0) hours = 0;
        else if (activeSegment === 1) minutes = 0;
        else if (activeSegment === 2) seconds = 0;
      }
      const pad = n => String(n).padStart(2, '0');
      input.value = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
      selectActiveSegment();
      updateClipCalcDuration();
      return;
    }

    if (e.key === 'Delete') {
      e.preventDefault();
      typedBuffer = '';
      let { hours, minutes, seconds } = parseCurrentValues();
      if (activeSegment === 0) hours = 0;
      else if (activeSegment === 1) minutes = 0;
      else if (activeSegment === 2) seconds = 0;
      const pad = n => String(n).padStart(2, '0');
      input.value = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
      selectActiveSegment();
      updateClipCalcDuration();
      return;
    }

    if (/^\d$/.test(e.key)) {
      e.preventDefault();
      typedBuffer += e.key;
      const num = parseInt(typedBuffer, 10) || 0;
      let { hours, minutes, seconds } = parseCurrentValues();
      if (activeSegment === 0) hours = num;
      else if (activeSegment === 1) minutes = num;
      else if (activeSegment === 2) seconds = num;

      const pad = n => String(n).padStart(2, '0');
      input.value = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
      selectActiveSegment();
      updateClipCalcDuration();
      return;
    }

    // Block any other key so colons and format cannot be deleted/corrupted
    e.preventDefault();
  });

  input.addEventListener('paste', (e) => {
    e.preventDefault();
    const pasteText = (e.clipboardData || window.clipboardData).getData('text');
    const sec = parseTimeToSec(pasteText);
    input.value = formatSecToTime(sec, true);
    typedBuffer = '';
    updateClipCalcDuration();
  });

  input.addEventListener('blur', () => {
    commitAndNormalize();
  });
  input.addEventListener('change', () => {
    commitAndNormalize();
  });
}

attachTimeInputMask(clipStartTimeInput);
attachTimeInputMask(clipEndTimeInput);

// Steppers
clipperTimeStepBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    const targetId = btn.dataset.target;
    const step = parseInt(btn.dataset.step, 10) || 1;
    const input = document.getElementById(targetId);
    if (!input) return;
    let currentSec = parseTimeToSec(input.value);
    currentSec = Math.max(0, currentSec + step);
    if (clipperState.totalDuration > 0 && targetId === 'clipEndTime') {
      currentSec = Math.min(clipperState.totalDuration, currentSec);
    }
    input.value = formatSecToTime(currentSec, true);
    updateClipCalcDuration();
  });
});

// Quick Presets
clipperPresetBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    const preset = btn.dataset.preset;
    const startSec = parseTimeToSec(clipStartTimeInput?.value || '00:00:00');
    let newEnd = startSec + 60;
    if (preset === '30s') newEnd = startSec + 30;
    else if (preset === '1m') newEnd = startSec + 60;
    else if (preset === '5m') newEnd = startSec + 300;
    else if (preset === '10m') newEnd = startSec + 600;
    else if (preset === 'full') {
      if (clipStartTimeInput) clipStartTimeInput.value = '00:00:00';
      newEnd = clipperState.totalDuration || 300;
    }

    if (clipperState.totalDuration > 0) {
      newEnd = Math.min(clipperState.totalDuration, newEnd);
    }
    if (clipEndTimeInput) clipEndTimeInput.value = formatSecToTime(newEnd, true);
    updateClipCalcDuration();
  });
});

// Format buttons for Clipper
clipperFormatBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    clipperFormatBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    clipperState.format = btn.dataset.val;
    if (['mp3', 'wav', 'm4a'].includes(clipperState.format)) {
      if (clipperQualitySelect) clipperQualitySelect.disabled = true;
    } else {
      if (clipperQualitySelect) clipperQualitySelect.disabled = false;
    }
  });
});

// Browse folder for Clipper
if (clipperBrowseBtn) {
  clipperBrowseBtn.addEventListener('click', async () => {
    try {
      const currentPath = encodeURIComponent(clipperSavePathInput?.value || state.savePath || '');
      const res = await fetch(`/api/select-folder?current=${currentPath}`);
      const data = await res.json();
      if (data.path) {
        if (clipperSavePathInput) clipperSavePathInput.value = data.path;
      }
    } catch {
      toast(t('toastCannotBrowse'), 'error');
    }
  });
}

// Fetch Video Info
async function fetchClipperInfo() {
  const url = (clipperUrlInput?.value || '').trim();
  if (!url) {
    toast(t('toastPasteLink'), 'error');
    return;
  }

  if (clipperFetchBtn) {
    clipperFetchBtn.disabled = true;
    clipperFetchBtn.textContent = '...';
  }
  toast(t('toastLoadingInfo'), 'info');

  try {
    const res = await fetch('/api/info', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url,
        cookieSource: state.settings.cookieSource,
        cookieBrowser: state.settings.cookieBrowser,
        cookieFile: state.settings.cookieFile,
        dnsEnabled: state.settings.dnsEnabled,
        dnsProvider: state.settings.dnsProvider,
        customDnsUrl: state.settings.customDnsUrl,
        proxyEnabled: state.settings.proxyEnabled,
        proxyPreset: state.settings.proxyPreset,
        proxyUrl: state.settings.proxyUrl
      })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to fetch video information');

    clipperState.videoInfo = data;
    clipperState.totalDuration = data.duration || 0;
    clipperState.isLive = Boolean(data.is_live);

    if (clipperPreviewCard) clipperPreviewCard.classList.remove('hidden');
    if (clipperThumbImg && data.thumbnail) clipperThumbImg.src = data.thumbnail;
    if (clipperVideoTitle) clipperVideoTitle.textContent = data.title || 'Untitled';
    if (clipperVideoAuthor) clipperVideoAuthor.textContent = data.uploader || 'Unknown Channel';

    const durFormatted = formatSecToTime(clipperState.totalDuration, false);
    if (clipperDurationBadge) clipperDurationBadge.textContent = durFormatted;
    if (clipperTotalDurTag) clipperTotalDurTag.textContent = `Total: ${formatSecToTime(clipperState.totalDuration, true)}`;

    if (clipperLiveTag) {
      clipperLiveTag.style.display = clipperState.isLive ? 'inline-block' : 'none';
    }

    if (clipStartTimeInput) clipStartTimeInput.value = '00:00:00';
    if (clipEndTimeInput) {
      const defaultClipLen = clipperState.totalDuration > 0 ? Math.min(clipperState.totalDuration, 60) : 60;
      clipEndTimeInput.value = formatSecToTime(defaultClipLen, true);
    }
    updateClipCalcDuration();
    toast(t('toastInfoLoaded'), 'success');
  } catch (err) {
    toast(`Error: ${err.message}`, 'error');
  } finally {
    if (clipperFetchBtn) {
      clipperFetchBtn.disabled = false;
      clipperFetchBtn.textContent = t('btnFetchInfo');
    }
  }
}

if (clipperFetchBtn) {
  clipperFetchBtn.addEventListener('click', fetchClipperInfo);
}

if (clipperUrlInput) {
  clipperUrlInput.addEventListener('input', () => {
    updatePlatformBar(clipperUrlInput.value.trim());
  });
  clipperUrlInput.addEventListener('paste', () => {
    setTimeout(() => {
      updatePlatformBar(clipperUrlInput.value.trim());
      fetchClipperInfo();
    }, 80);
  });
  clipperUrlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') fetchClipperInfo();
  });
}

// Trim & Download
if (clipperDownloadBtn) {
  clipperDownloadBtn.addEventListener('click', async () => {
    const url = (clipperUrlInput?.value || '').trim();
    if (!url) {
      toast(t('toastPasteLink'), 'error');
      return;
    }

    const startSec = parseTimeToSec(clipStartTimeInput?.value || '00:00:00');
    const endSec = parseTimeToSec(clipEndTimeInput?.value || '00:01:00');

    if (endSec <= startSec) {
      toast(t('toastInvalidTime'), 'error');
      return;
    }

    const startFormatted = formatSecToTime(startSec, true);
    const endFormatted = formatSecToTime(endSec, true);
    const formatVal = clipperState.format || 'mp4';
    const audioOnly = ['mp3', 'wav', 'm4a'].includes(formatVal);
    const qualityVal = clipperQualitySelect?.value || 'best';
    const outputPath = clipperSavePathInput?.value || state.savePath;

    clipperDownloadBtn.disabled = true;
    clipperDownloadBtn.textContent = '...';

    try {
      const res = await fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url,
          format: qualityVal,
          audioOnly,
          ext: formatVal,
          outputPath,
          subtitles: false,
          isLive: clipperState.isLive,
          timeSection: {
            start: startFormatted,
            end: endFormatted
          },
          section: `${startFormatted}-${endFormatted}`,
          totalDuration: clipperState.totalDuration || 0,
          cookieSource: state.settings.cookieSource,
          cookieBrowser: state.settings.cookieBrowser,
          cookieFile: state.settings.cookieFile,
          dnsEnabled: state.settings.dnsEnabled,
          dnsProvider: state.settings.dnsProvider,
          customDnsUrl: state.settings.customDnsUrl,
          proxyEnabled: state.settings.proxyEnabled,
          proxyPreset: state.settings.proxyPreset,
          proxyUrl: state.settings.proxyUrl
        })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Download failed');

      state.activeDownloads.set(data.id, {
        id: data.id,
        url,
        startedAt: new Date().toISOString(),
        title: clipperState.videoInfo ? `[${startFormatted}-${endFormatted}] ${clipperState.videoInfo.title}` : `[${startFormatted}-${endFormatted}]`,
        status: 'downloading',
        progress: 0,
        speed: '',
        eta: '',
        audioOnly,
        ext: formatVal,
        thumbnail: clipperState.videoInfo?.thumbnail || null,
        savePath: outputPath,
        timeSection: `${startFormatted}-${endFormatted}`
      });

      renderDownloads();
      toast(t('toastClipStarted'), 'success');
      setActiveTab('home');
      saveActiveTab('home');
    } catch (err) {
      toast(`Error: ${err.message}`, 'error');
    } finally {
      if (clipperDownloadBtn) {
        clipperDownloadBtn.disabled = false;
        clipperDownloadBtn.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>
          <span data-i18n="btnTrimDownload">${t('btnTrimDownload')}</span>
        `;
      }
    }
  });
}


// ── Init ───────────────────────────────────────────────────────────────────
(async () => {
  // 1. Parallel fetch of startup state, config, and downloads
  try {
    const [serverState, configData, downloadsData] = await Promise.all([
      fetch('/api/app-state').then(r => r.json()).catch(() => null),
      fetch('/api/config').then(r => r.json()).catch(() => null),
      fetch('/api/downloads').then(r => r.json()).catch(() => null)
    ]);

    if (serverState) {
      if (serverState.settings) {
        state.settings = { ...state.settings, ...serverState.settings };
      }
      if (serverState.downloadDefaults) {
        if (serverState.downloadDefaults.savePath) {
          state.savePath = serverState.downloadDefaults.savePath;
          if (savePathInput) savePathInput.value = state.savePath;
        }
        if (serverState.downloadDefaults.converterSavePath) {
          state.converterSavePath = serverState.downloadDefaults.converterSavePath;
          if (converterSavePathInput) converterSavePathInput.value = state.converterSavePath;
        }
        if (serverState.downloadDefaults.format) {
          state.format = serverState.downloadDefaults.format;
          formatBtns.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.val === state.format);
          });
          if (['mp3', 'wav', 'm4a'].includes(state.format)) {
            if (qualitySelect) qualitySelect.disabled = true;
          } else {
            if (qualitySelect) qualitySelect.disabled = false;
          }
        }
        if (serverState.downloadDefaults.quality && qualitySelect) {
          qualitySelect.value = serverState.downloadDefaults.quality;
        }
        if (serverState.downloadDefaults.embedThumbnail !== undefined && thumbnailToggle) {
          thumbnailToggle.checked = Boolean(serverState.downloadDefaults.embedThumbnail);
        }
      }
      // Always start at the Home page on every application launch
      setActiveTab('home');
      saveActiveTab('home');
      if (serverState.history) {
        serverHistory = serverState.history;
      }
    }

    if (configData) {
      if (!state.savePath && configData.defaultPath) {
        state.savePath = configData.defaultPath;
        if (savePathInput) savePathInput.value = state.savePath;
        if (clipperSavePathInput) clipperSavePathInput.value = state.savePath;
      }
      if (!state.converterSavePath) {
        state.converterSavePath = configData.converterSavePath || state.savePath;
        if (converterSavePathInput) converterSavePathInput.value = state.converterSavePath;
      }
      if (clipperSavePathInput && !clipperSavePathInput.value) {
        clipperSavePathInput.value = state.savePath || configData.defaultPath || '';
      }
    }

    if (downloadsData) {
      if (Array.isArray(downloadsData.active)) {
        downloadsData.active.forEach(dl => state.activeDownloads.set(dl.id, dl));
      }
      renderHistory(downloadsData.history);
    }
  } catch {}

  applySettings();

  // 2. Format buttons state
  if (state.format) {
    formatBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.val === state.format);
    });
    if (['mp3', 'wav', 'm4a'].includes(state.format)) {
      if (qualitySelect) qualitySelect.disabled = true;
    }
  }

  // 3. Render history
  renderHistoryTab();

  // 4. One-time migration from legacy localStorage if any
  try {
    const oldSettings = localStorage.getItem('nuu_settings');
    const oldHistory = localStorage.getItem('nuu_history');
    const oldConverterPath = localStorage.getItem('nuu_converter_save_path');

    if (oldSettings || oldHistory) {
      let migrationPayload = {};
      if (oldSettings) {
        try { migrationPayload.settings = JSON.parse(oldSettings); } catch {}
      }
      if (oldHistory) {
        try { migrationPayload.history = JSON.parse(oldHistory); } catch {}
      }
      if (oldConverterPath) {
        migrationPayload.converterSavePath = oldConverterPath;
      }

      const migrateRes = await fetch('/api/migrate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(migrationPayload)
      });
      const migrated = await migrateRes.json();

      if (migrated.settings) state.settings = { ...state.settings, ...migrated.settings };
      if (migrated.history) renderHistory(migrated.history);

      localStorage.removeItem('nuu_settings');
      localStorage.removeItem('nuu_history');
      localStorage.removeItem('nuu_converter_save_path');
      applySettings();
    }
  } catch {}

  // 5. Intercept link clicks to open in default browser
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a[href^="http"]');
    if (link) {
      e.preventDefault();
      const url = link.getAttribute('href');
      if (window.electronAPI?.openExternal) {
        window.electronAPI.openExternal(url);
      } else {
        window.open(url, '_blank');
      }
    }
  });
})();
