const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');
const { Readable } = require('node:stream');
const { pipeline } = require('node:stream/promises');

const rootDir = path.join(__dirname, '..');
const toolsDir = path.join(rootDir, 'tools');
const isWindows = process.platform === 'win32';
const binaryName = isWindows ? 'deno.exe' : 'deno';
const targetNameByPlatform = {
  'win32-x64': 'x86_64-pc-windows-msvc',
  'win32-arm64': 'aarch64-pc-windows-msvc',
  'darwin-x64': 'x86_64-apple-darwin',
  'darwin-arm64': 'aarch64-apple-darwin',
  'linux-x64': 'x86_64-unknown-linux-gnu',
  'linux-arm64': 'aarch64-unknown-linux-gnu'
};

function parseVersion(value) {
  const match = String(value || '').match(/(\d+)\.(\d+)\.(\d+)/);
  return match ? match.slice(1).map(Number) : null;
}

function compareVersions(left, right) {
  for (let index = 0; index < 3; index += 1) {
    if (left[index] !== right[index]) return left[index] - right[index];
  }
  return 0;
}

async function fetchResponse(url, accept = '*/*') {
  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Nuutapao-Tools-Build',
      Accept: accept
    },
    signal: AbortSignal.timeout(120000)
  });
  if (!response.ok) throw new Error(`Download failed (${response.status}): ${url}`);
  return response;
}

async function downloadToFile(url, destination) {
  const response = await fetchResponse(url);
  await pipeline(Readable.fromWeb(response.body), fs.createWriteStream(destination));
}

function readInstalledVersion(targetPath) {
  if (!fs.existsSync(targetPath)) return null;
  try {
    const output = execFileSync(targetPath, ['--version'], {
      encoding: 'utf8',
      timeout: 10000,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'ignore']
    });
    return parseVersion(output);
  } catch {
    return null;
  }
}

async function main() {
  const target = targetNameByPlatform[`${process.platform}-${process.arch}`];
  if (!target) throw new Error(`Deno runtime is not configured for ${process.platform}-${process.arch}.`);

  const releaseResponse = await fetchResponse(
    'https://api.github.com/repos/denoland/deno/releases/latest',
    'application/vnd.github+json'
  );
  const release = await releaseResponse.json();
  const requiredVersion = parseVersion(release.tag_name);
  if (!requiredVersion || compareVersions(requiredVersion, [2, 3, 0]) < 0) {
    throw new Error(`Latest Deno release is below yt-dlp's minimum supported version: ${release.tag_name}`);
  }

  const installedVersion = readInstalledVersion(path.join(toolsDir, binaryName));
  if (installedVersion && compareVersions(installedVersion, requiredVersion) >= 0) {
    console.log(`Deno ${installedVersion.join('.')} is ready for yt-dlp.`);
    return;
  }

  const archiveName = `deno-${target}.zip`;
  const archiveAsset = (release.assets || []).find(asset => asset.name === archiveName);
  if (!archiveAsset) throw new Error(`Deno release ${release.tag_name} has no ${archiveName} asset.`);

  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'nuutapao-deno-'));
  try {
    const archivePath = path.join(workDir, archiveName);
    await downloadToFile(archiveAsset.browser_download_url, archivePath);

    let expectedHash = String(archiveAsset.digest || '').replace(/^sha256:/i, '').toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(expectedHash)) {
      const checksumAsset = (release.assets || []).find(asset => asset.name === `${archiveName}.sha256sum`);
      if (!checksumAsset) throw new Error(`Deno release is missing checksum for ${archiveName}.`);
      const checksumResponse = await fetchResponse(checksumAsset.browser_download_url, 'text/plain');
      const checksumText = await checksumResponse.text();
      expectedHash = (checksumText.match(/[a-f0-9]{64}/i) || [])[0]?.toLowerCase();
    }

    const actualHash = crypto.createHash('sha256').update(fs.readFileSync(archivePath)).digest('hex');
    if (!expectedHash || actualHash !== expectedHash) {
      throw new Error(`Deno archive checksum did not match for ${release.tag_name}.`);
    }

    const extractedDir = path.join(workDir, 'extracted');
    await require('extract-zip')(archivePath, { dir: extractedDir });
    const extractedBinary = path.join(extractedDir, binaryName);
    const extractedVersion = readInstalledVersion(extractedBinary);
    if (!extractedVersion || compareVersions(extractedVersion, requiredVersion) !== 0) {
      throw new Error(`Downloaded Deno version did not match release ${release.tag_name}.`);
    }

    fs.mkdirSync(toolsDir, { recursive: true });
    const stagedBinary = path.join(toolsDir, `${binaryName}.new`);
    fs.copyFileSync(extractedBinary, stagedBinary);
    if (!isWindows) fs.chmodSync(stagedBinary, 0o755);
    fs.renameSync(stagedBinary, path.join(toolsDir, binaryName));
    console.log(`Installed Deno ${extractedVersion.join('.')} for yt-dlp.`);
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

main().catch(error => {
  console.error(`Could not prepare Deno for yt-dlp: ${error.message}`);
  process.exitCode = 1;
});
