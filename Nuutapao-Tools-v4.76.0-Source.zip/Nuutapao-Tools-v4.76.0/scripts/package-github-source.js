const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const rootDir = path.join(__dirname, '..');
const distDir = path.join(rootDir, 'dist');
const githubSourceDir = path.join(distDir, 'github-source');

const pkg = JSON.parse(fs.readFileSync(path.join(rootDir, 'package.json'), 'utf8'));
const version = pkg.version || '4.4.0';
const folderName = `Nuutapao-Tools-v${version}`;
const targetDir = path.join(githubSourceDir, folderName);
const zipFile = path.join(githubSourceDir, `Nuutapao-Tools-v${version}-Source.zip`);

const MAX_ZIP_MB = 25;

console.log(`📦 Packaging clean source code for GitHub release (${folderName})...`);
console.log(`   Target: < ${MAX_ZIP_MB} MB\n`);

// Ensure directory exists
if (!fs.existsSync(githubSourceDir)) {
  fs.mkdirSync(githubSourceDir, { recursive: true });
}

// Clean old folder
if (fs.existsSync(targetDir)) {
  fs.rmSync(targetDir, { recursive: true, force: true });
}
fs.mkdirSync(targetDir, { recursive: true });

// Source files and folders to include
const includeItems = [
  'hub',
  'installer',
  'public',
  'scripts',
  'test',
  'tools',
  '.gitignore',
  'app-state.js',
  'icon.ico',
  'installer.nsh',
  'LICENSE',
  'main.js',
  'Nuutapao Human Head.png',
  'Nuutapao Human.png',
  'Nuutapao petting2.gif',
  'package-lock.json',
  'package.json',
  'playwright.config.js',
  'preload.js',
  'README.md',
  'server.js'
];

// ── Excluded files (large binaries users can download separately) ───────────
const excludeFiles = new Set([
  'yt-dlp.exe',     // 17 MB — auto-downloads on first run
  'yt-dlp',         // macOS/Linux variant
  'deno.exe',       // Generated from official Deno release during builds
  'deno',           // Generated from official Deno release during builds
]);

// ── Duplicate images: skip these copies (keep originals in primary location) ─
// Primary locations: root/ for root assets, public/ for app assets
// Duplicates in hub/assets/ and cross-directory copies are excluded
const excludePaths = new Set([
  // public/logo.png is duplicate of Nuutapao Human Head.png (2.9 MB)
  path.join('public', 'logo.png'),
  // public/Nuutapao Human Head.png — duplicate of root (2.9 MB)
  path.join('public', 'Nuutapao Human Head.png'),
  // public/tray-icon.ico — duplicate of public/icon.ico
  path.join('public', 'tray-icon.ico'),
  // hub/assets duplicates of root and public images
  path.join('hub', 'assets', 'nuutapao-human.png'),
  path.join('hub', 'assets', 'Nuutapao Human.png'),
  path.join('hub', 'assets', 'Nuutapao logo 4.0.png'),
  path.join('hub', 'assets', 'logo-4.0.png'),
  path.join('hub', 'assets', 'logo-4.0-tight.png'),
  path.join('hub', 'assets', 'Nuutapao logo 4.0 tight.png'),
  path.join('hub', 'assets', 'Nuutapao border.png'),
  path.join('hub', 'assets', 'icon.ico'),
  path.join('hub', 'assets', 'Nuutapao petting2.gif'),
  path.join('hub', 'assets', 'nuutapao-petting2.gif'),
]);

// Directories to always skip inside any folder
const skipDirs = new Set([
  'node_modules', 'dist', '.git', '.cache',
  '.tempmediaStorage', '.user_uploaded'
]);

let totalBytes = 0;
let fileCount = 0;
let skippedFiles = [];

function copyRecursive(src, dest, relativeBase) {
  if (!fs.existsSync(src)) return;
  const stat = fs.statSync(src);

  if (stat.isDirectory()) {
    if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
    const entries = fs.readdirSync(src);
    for (const entry of entries) {
      if (skipDirs.has(entry)) continue;
      copyRecursive(
        path.join(src, entry),
        path.join(dest, entry),
        path.join(relativeBase, entry)
      );
    }
  } else {
    const fileName = path.basename(src);

    // Skip excluded binaries
    if (excludeFiles.has(fileName)) {
      skippedFiles.push({ path: relativeBase, reason: 'binary excluded', sizeMB: (stat.size / 1048576).toFixed(2) });
      return;
    }

    // Skip duplicate images
    if (excludePaths.has(relativeBase)) {
      skippedFiles.push({ path: relativeBase, reason: 'duplicate image', sizeMB: (stat.size / 1048576).toFixed(2) });
      return;
    }

    fs.copyFileSync(src, dest);
    totalBytes += stat.size;
    fileCount++;
  }
}

for (const item of includeItems) {
  const srcPath = path.join(rootDir, item);
  const destPath = path.join(targetDir, item);
  if (fs.existsSync(srcPath)) {
    copyRecursive(srcPath, destPath, item);
    console.log(`  + ${item}`);
  }
}

console.log(`\n  Copied ${fileCount} files (${(totalBytes / 1048576).toFixed(1)} MB uncompressed)`);

if (skippedFiles.length > 0) {
  console.log(`\n  Skipped ${skippedFiles.length} files to reduce size:`);
  for (const s of skippedFiles) {
    console.log(`    - ${s.path} (${s.sizeMB} MB, ${s.reason})`);
  }
}

// Create clean source ZIP
if (fs.existsSync(zipFile)) {
  fs.unlinkSync(zipFile);
}

const sysTar = path.join(process.env.SystemRoot || 'C:\\\\Windows', 'System32', 'tar.exe');
const tarBin = (process.platform === 'win32' && fs.existsSync(sysTar)) ? sysTar : 'tar';

try {
  execSync(`"${tarBin}" -a -c -f "${zipFile}" -C "${githubSourceDir}" "${folderName}"`, {
    cwd: rootDir,
    stdio: 'inherit'
  });
} catch (e) {
  console.warn('tar -a failed, creating zip with standard tar:', e.message);
  execSync(`"${tarBin}" -cf "${zipFile}" -C "${githubSourceDir}" "${folderName}"`, {
    cwd: rootDir,
    stdio: 'inherit'
  });
}

// Report final size
const zipStat = fs.statSync(zipFile);
const zipMB = (zipStat.size / 1048576).toFixed(1);
console.log(`\n✨ Created: ${zipFile}`);
console.log(`   Archive size: ${zipMB} MB`);

if (parseFloat(zipMB) > MAX_ZIP_MB) {
  console.warn(`\n⚠️  WARNING: Zip is ${zipMB} MB — exceeds ${MAX_ZIP_MB} MB target!`);
  process.exitCode = 0; // Non-fatal warning
} else {
  console.log(`   ✅ Under ${MAX_ZIP_MB} MB target`);
}

console.log('\n✅ GitHub source code package updated successfully!');
