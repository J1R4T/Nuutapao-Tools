// Ensure UTF-8 encoding across all subprocesses (yt-dlp, Python, FFmpeg, etc.)
process.env.PYTHONIOENCODING = 'utf-8';
process.env.PYTHONUTF8 = '1';
if (!process.env.LANG) process.env.LANG = 'en_US.UTF-8';
if (!process.env.LC_ALL) process.env.LC_ALL = 'en_US.UTF-8';

const express = require('express');
const { WebSocketServer } = require('ws');
const { spawn, exec } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const http = require('http');
const path = require('path');
const fs = require('fs');
const os = require('os');
const multer = require('multer');
const QRCode = require('qrcode');
const { createAppStateStore, HISTORY_LIMIT } = require('./app-state');

const QR_SIZES = new Set([256, 512, 1024]);

function validateQrRequest(body = {}) {
  const value = typeof body.value === 'string' ? body.value.trim() : '';
  if (!value) return { error: 'A link is required.' };
  try {
    const parsed = new URL(value);
    if (!parsed.protocol) return { error: 'Enter a valid absolute URL.' };
  } catch {
    return { error: 'Enter a valid absolute URL.' };
  }

  const size = Number(body.size);
  if (!QR_SIZES.has(size)) return { error: 'QR size must be 256, 512, or 1024 pixels.' };
  return { value, size };
}

function createQrOptions(size) {
  return {
    type: 'image/png',
    width: size,
    margin: 2,
    errorCorrectionLevel: 'H',
    color: { dark: '#000000', light: '#FFFFFFFF' }
  };
}

function getSpawnEnv() {
  const env = { ...process.env };
  const toolsDir = runtimeConfig.isPackaged && runtimeConfig.resourcesPath
    ? path.join(runtimeConfig.resourcesPath, 'tools')
    : path.join(__dirname, 'tools');
  const denoPath = path.join(toolsDir, `deno${toolExt}`);

  // yt-dlp discovers its JavaScript runtime through PATH. Deno ships beside
  // yt-dlp in packaged builds, so expose that directory to every subprocess.
  if (fs.existsSync(denoPath)) {
    const pathKey = Object.keys(env).find(key => key.toLowerCase() === 'path') || 'PATH';
    env[pathKey] = [toolsDir, env[pathKey]].filter(Boolean).join(path.delimiter);
  }

  return {
    ...env,
    PYTHONIOENCODING: 'utf-8',
    PYTHONUTF8: '1',
    LANG: 'en_US.UTF-8',
    LC_ALL: 'en_US.UTF-8'
  };
}

let runtimeConfig = {
  isPackaged: false,
  resourcesPath: '',
  userDataPath: ''
};

// Runtime boundaries are deliberately centralised so tests can replace process
// execution, executable discovery, and shell calls without touching real media
// tools or the user's machine.  Production uses the native implementations.
let runtimeAdapters = {};
function runProcess(...args) {
  return (runtimeAdapters.spawn || spawn)(...args);
}
function runShell(...args) {
  return (runtimeAdapters.exec || exec)(...args);
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Multer for file uploads (converter)
const uploadDir = path.join(os.tmpdir(), 'nuutapao-converter');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({ dest: uploadDir });

// Store active downloads
const activeDownloads = new Map();
let downloadHistory = [];
let stateStore = null;

// Store active conversions
const activeConversions = new Map();

// Default download folder: Desktop/YT Downloads with OneDrive and Downloads fallbacks
function resolveInitialDownloadPath() {
  const home = os.homedir();
  const candidates = [
    path.join(home, 'Desktop', 'YT Downloads'),
    path.join(home, 'OneDrive', 'Desktop', 'YT Downloads'),
    path.join(home, 'Downloads', 'YT Downloads'),
    path.join(home, 'YT Downloads')
  ];

  for (const candidate of candidates) {
    try {
      const parent = path.dirname(candidate);
      if (fs.existsSync(parent)) {
        if (!fs.existsSync(candidate)) {
          fs.mkdirSync(candidate, { recursive: true });
        }
        return candidate;
      }
    } catch {
      // Continue to next fallback candidate
    }
  }

  const emergency = path.join(os.tmpdir(), 'YT Downloads');
  try { if (!fs.existsSync(emergency)) fs.mkdirSync(emergency, { recursive: true }); } catch {}
  return emergency;
}

const defaultDownloadPath = resolveInitialDownloadPath();

function getStateStore() {
  if (!stateStore) {
    stateStore = createAppStateStore({
      userDataPath: runtimeConfig.userDataPath,
      defaultDownloadPath
    });
    const state = stateStore.load();
    downloadHistory = state.history;
  }
  return stateStore;
}

function recordHistory(download) {
  const state = getStateStore().appendHistory(download);
  downloadHistory = state.history;
  broadcast({ type: 'history', data: downloadHistory });
}

// Provide config to frontend
app.get('/api/config', (req, res) => {
  const st = getStateStore().get();
  res.json({
    defaultPath: st.downloadDefaults.savePath || defaultDownloadPath,
    converterSavePath: st.downloadDefaults.converterSavePath || st.downloadDefaults.savePath || defaultDownloadPath
  });
});

app.get('/api/app-state', (req, res) => {
  res.json(getStateStore().get());
});

app.patch('/api/app-state', (req, res) => {
  const updated = getStateStore().patch(req.body);
  downloadHistory = updated.history;
  res.json(updated);
});

// Restore all settings and history to factory defaults
app.post('/api/restore-defaults', (req, res) => {
  const fresh = getStateStore().resetToDefaults();
  downloadHistory = fresh.history;
  broadcast({ type: 'history', data: downloadHistory });
  res.json(fresh);
});

// QR Maker — stateless, local generation. QR content is never added to history.
app.post('/api/qr', async (req, res) => {
  const request = validateQrRequest(req.body);
  if (request.error) return res.status(400).json({ error: request.error });
  try {
    const dataUrl = await QRCode.toDataURL(request.value, createQrOptions(request.size));
    res.json({ dataUrl, size: request.size });
  } catch (error) {
    res.status(422).json({ error: `Unable to create QR code: ${error.message}` });
  }
});

app.post('/api/qr/save', async (req, res) => {
  const request = validateQrRequest(req.body);
  if (request.error) return res.status(400).json({ error: request.error });
  if (!electronDialog?.showSaveDialog) {
    return res.status(501).json({ error: 'Saving QR images is only available in the desktop app.' });
  }
  try {
    const { canceled, filePath } = await electronDialog.showSaveDialog({
      title: 'Save QR Code',
      defaultPath: 'nuutapao-qr.png',
      filters: [{ name: 'PNG Image', extensions: ['png'] }]
    });
    if (canceled || !filePath) return res.json({ cancelled: true, path: null });
    const targetPath = path.extname(filePath) ? filePath : `${filePath}.png`;
    const png = await QRCode.toBuffer(request.value, createQrOptions(request.size));
    fs.writeFileSync(targetPath, png);
    res.json({ cancelled: false, path: targetPath });
  } catch (error) {
    res.status(500).json({ error: `Unable to save QR code: ${error.message}` });
  }
});

// One-time migration from client localStorage
app.post('/api/migrate', (req, res) => {
  const updated = getStateStore().migrateFromClient(req.body);
  downloadHistory = updated.history;
  broadcast({ type: 'history', data: downloadHistory });
  res.json(updated);
});

// History endpoints — server is the single source of truth
app.get('/api/history', (req, res) => {
  res.json({ history: getStateStore().get().history });
});

app.delete('/api/history', (req, res) => {
  const state = getStateStore().clearHistory();
  downloadHistory = state.history;
  broadcast({ type: 'history', data: downloadHistory });
  res.json({ history: downloadHistory });
});

app.delete('/api/history/:id', (req, res) => {
  const state = getStateStore().removeHistory(req.params.id);
  downloadHistory = state.history;
  broadcast({ type: 'history', data: downloadHistory });
  res.json({ history: downloadHistory });
});

// ── Assets Finder API ─────────────────────────────────────────────────────
function getAssetsApiKeys() {
  const st = getStateStore().get();
  return {
    pixabay: (st.settings?.pixabayApiKey || '').trim(),
    giphy: (st.settings?.giphyApiKey || '').trim()
  };
}

function httpsGet(url) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? require('https') : require('http');
    mod.get(url, { headers: { 'User-Agent': 'NuutapaoTools/3.1' } }, (resp) => {
      let data = '';
      resp.on('data', chunk => { data += chunk; });
      resp.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch { reject(new Error('Invalid JSON from upstream API')); }
      });
    }).on('error', reject);
  });
}

function searchWebAssets(q, type = 'photo', page = 1, perPage = 30) {
  return new Promise((resolve, reject) => {
    const isGif = type === 'gif';
    const first = (page - 1) * perPage + 1;
    let targetUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(q)}&form=HDRSC2&first=${first}`;
    if (isGif) {
      targetUrl += '&qft=+filterui:photo-animatedgif';
    } else {
      targetUrl += '&qft=+filterui:photo-photo';
    }

    const mod = require('https');
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'no-cache'
      }
    };

    const handleResp = (resp) => {
      if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
        let nextUrl = resp.headers.location;
        if (!nextUrl.startsWith('http')) {
          nextUrl = 'https://www.bing.com' + nextUrl;
        }
        return mod.get(nextUrl, options, handleResp).on('error', reject);
      }
      let body = '';
      resp.on('data', chunk => { body += chunk; });
      resp.on('end', () => {
        try {
          const items = [];
          const seen = new Set();
          const regex = /m="({.+?})"/g;
          let m;
          while ((m = regex.exec(body)) !== null && items.length < perPage) {
            try {
              const unescaped = m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
              const parsed = JSON.parse(unescaped);
              if (!parsed.murl) continue;

              let domain = 'Google / Web';
              try {
                if (parsed.purl) {
                  const u = new URL(parsed.purl);
                  domain = u.hostname.replace(/^www\./, '');
                }
              } catch {}

              const sourceTitle = (parsed.t || parsed.desc || '')
                .replace(/[\uE000-\uF8FF]/g, '')
                .replace(/<[^>]+>/g, '')
                .trim();
              const title = sourceTitle || q;
              const id = String(parsed.imageId || parsed.mid || '');
              const pageUrl = parsed.purl || '';
              const identity = id || `${parsed.murl}|${pageUrl}|${title.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim()}`;
              if (seen.has(identity)) continue;
              seen.add(identity);

              // Skip AI-generated content to ensure authentic photos and Gen Z aesthetics
              const lowerTitle = title.toLowerCase();
              const purlLower = (parsed.purl || '').toLowerCase();
              const murlLower = (parsed.murl || '').toLowerCase();
              const isAi = /\b(ai[\s_-]?art|ai[\s_-]?generated|midjourney|dall[\s_-]?e|stable[\s_-]?diffusion|craiyon|nightcafe|novelai|leonardo[\s_-]?ai|bing[\s_-]?image[\s_-]?creator)\b/i.test(lowerTitle) ||
                /(midjourney|civitai|leonardo\.ai|nightcafe\.studio|craiyon|artbreeder)/i.test(purlLower) ||
                /(midjourney|civitai|artbreeder)/i.test(murlLower);
              if (isAi) continue;

              // Filter out clipart, vector graphics, and svg stickers when user wants real photos
              if (!isGif) {
                const isVectorOrClipart = /\b(clipart|vector|svg|sticker|coloring page|png clipart)\b/i.test(lowerTitle) ||
                  /(vecteezy|vectorstock|freepik|freevector|cleanpng|pngtree)/i.test(purlLower) ||
                  murlLower.endsWith('.svg');
                if (isVectorOrClipart) continue;
              }

              const rawTags = (title + ' ' + q).toLowerCase().match(/\b[a-z0-9_-]{3,}\b/g) || [];
              const uniqueTags = [...new Set(rawTags)].slice(0, 6);
              items.push({
                id: id || (Math.random().toString(36).substring(2) + Date.now().toString(36)),
                source: 'google',
                type: isGif ? 'gif' : 'photo',
                title: sourceTitle,
                thumbnail: parsed.turl || parsed.murl,
                preview: parsed.murl,
                urls: {
                  small: parsed.turl || parsed.murl,
                  medium: parsed.murl,
                  large: parsed.murl,
                  original: parsed.murl
                },
                width: parseInt(parsed.width) || 0,
                height: parseInt(parsed.height) || 0,
                author: domain,
                authorUrl: parsed.purl || `https://www.google.com/search?q=${encodeURIComponent(q)}`,
                tags: uniqueTags,
                pageUrl
              });
            } catch {}
          }

          resolve({
            total: items.length > 0 ? (page * perPage + 50) : 0,
            page,
            perPage,
            items
          });
        } catch (err) {
          reject(err);
        }
      });
    };

    mod.get(targetUrl, options, handleResp).on('error', reject);
  });
}

async function searchWebAssetsByImage(filePath, mimeType, filename) {
  const form = new FormData();
  form.append('encoded_image', new Blob([await fs.promises.readFile(filePath)], { type: mimeType }), path.basename(filename));
  form.append('ep', 'ccm');
  const response = await fetch('https://lens.google.com/v3/upload?hl=en&re=df', {
    method: 'POST',
    body: form,
    redirect: 'manual',
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36' }
  });
  const searchUrl = response.headers.get('location');
  if (![302, 303].includes(response.status) || !searchUrl) {
    throw new Error(`Google Lens returned HTTP ${response.status}.`);
  }
  const resultUrl = new URL(searchUrl);
  if (resultUrl.hostname !== 'www.google.com' || resultUrl.pathname !== '/search') {
    throw new Error('Google Lens returned an unexpected results URL.');
  }
  return { searchUrl: resultUrl.href, cookies: response.headers.getSetCookie?.() || [response.headers.get('set-cookie')].filter(Boolean) };
}

app.get('/api/assets/search', async (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.status(400).json({ error: 'Search query is required.' });

  const source = (req.query.source || 'google').toLowerCase();
  const type = req.query.type || 'photo';
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const perPage = Math.min(50, Math.max(3, parseInt(req.query.per_page) || 30));

  const keys = getAssetsApiKeys();

  // Backward compatibility check for Pixabay and Giphy API keys
  if (source === 'giphy' && !keys.giphy) {
    return res.json({ setup_required: 'giphy', items: [], total: 0, page: 1, perPage });
  }
  if (source === 'pixabay' && !keys.pixabay) {
    return res.json({ setup_required: 'pixabay', items: [], total: 0, page: 1, perPage });
  }

  try {
    // 1. Google / Web (API-less, no key needed!)
    if (source === 'google' || source === 'web') {
      const data = await searchWebAssets(q, type, page, perPage);
      return res.json(data);
    }

    // 2. Giphy
    if (type === 'gif' || source === 'giphy') {
      if (!keys.giphy) {
        return res.json({ setup_required: 'giphy', items: [], total: 0, page: 1, perPage });
      }
      const offset = (page - 1) * perPage;
      const giphyUrl = `https://api.giphy.com/v1/gifs/search?api_key=${keys.giphy}&q=${encodeURIComponent(q)}&limit=${perPage}&offset=${offset}&rating=g&lang=en`;
      const gData = await httpsGet(giphyUrl);
      const items = (gData.data || []).map(g => ({
        id: g.id,
        source: 'giphy',
        type: 'gif',
        thumbnail: g.images?.fixed_width?.url || g.images?.preview_gif?.url || '',
        preview: g.images?.downsized_medium?.url || g.images?.fixed_width?.url || '',
        urls: {
          small: g.images?.fixed_width?.url || '',
          medium: g.images?.downsized_medium?.url || g.images?.downsized?.url || '',
          large: g.images?.downsized_large?.url || g.images?.original?.url || '',
          original: g.images?.original?.url || ''
        },
        width: parseInt(g.images?.original?.width) || 0,
        height: parseInt(g.images?.original?.height) || 0,
        author: g.user?.display_name || g.username || 'Giphy',
        authorUrl: g.user?.profile_url || `https://giphy.com/${g.username || ''}`,
        tags: g.title ? g.title.split(' ').filter(t => t.length > 1).slice(0, 5) : [],
        pageUrl: g.url || ''
      }));
      return res.json({
        total: gData.pagination?.total_count || items.length,
        page,
        perPage,
        items
      });
    }

    // 3. Pixabay
    const pixabayType = type === 'vector' ? 'vector' : (type === 'illustration' ? 'illustration' : 'photo');
    const pixabayUrl = `https://pixabay.com/api/?key=${keys.pixabay}&q=${encodeURIComponent(q)}&image_type=${pixabayType}&page=${page}&per_page=${perPage}&safesearch=true`;
    const pData = await httpsGet(pixabayUrl);
    const items = (pData.hits || []).map(h => ({
      id: String(h.id),
      source: 'pixabay',
      type: pixabayType,
      thumbnail: h.previewURL || '',
      preview: h.webformatURL || '',
      urls: {
        small: h.previewURL || '',
        medium: h.webformatURL || '',
        large: h.largeImageURL || '',
        original: h.fullHDURL || h.imageURL || h.largeImageURL || ''
      },
      width: h.imageWidth || 0,
      height: h.imageHeight || 0,
      author: h.user || 'Pixabay',
      authorUrl: `https://pixabay.com/users/${h.user_id}/`,
      tags: h.tags ? h.tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      pageUrl: h.pageURL || ''
    }));
    res.json({
      total: pData.totalHits || items.length,
      page,
      perPage,
      items
    });
  } catch (err) {
    res.status(502).json({ error: `Asset search failed: ${err.message}` });
  }
});

const visualSearchUpload = multer({ dest: uploadDir, limits: { fileSize: 15 * 1024 * 1024 } }).single('image');
app.post('/api/assets/visual-search', (req, res, next) => {
  visualSearchUpload(req, res, err => {
    if (err) {
      const status = err.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
      return res.status(status).json({ error: status === 413 ? 'Image must be 15 MB or smaller.' : 'Could not read the image upload.' });
    }
    next();
  });
}, async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: 'Choose or paste an image first.' });
  if (!file.mimetype?.startsWith('image/')) {
    try { await fs.promises.unlink(file.path); } catch {}
    return res.status(400).json({ error: 'Only image files can be visually searched.' });
  }

  try {
    const result = await searchWebAssetsByImage(file.path, file.mimetype, file.originalname);
    res.json(result);
  } catch (err) {
    res.status(502).json({ error: `Visual search failed: ${err.message}` });
  } finally {
    try { await fs.promises.unlink(file.path); } catch {}
  }
});

app.post('/api/assets/download', async (req, res) => {
  const { url, filename, savePath } = req.body || {};
  if (!url || !filename) {
    return res.status(400).json({ error: 'URL and filename are required.' });
  }

  const targetDir = savePath || path.join(os.homedir(), 'Downloads');
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });

  // Sanitise the filename
  const safeName = filename.replace(/[<>:"/\\|?*]/g, '_').substring(0, 200);
  let targetPath = path.join(targetDir, safeName);

  // Avoid overwriting
  if (fs.existsSync(targetPath)) {
    const ext = path.extname(safeName);
    const base = path.basename(safeName, ext);
    let i = 1;
    while (fs.existsSync(path.join(targetDir, `${base} (${i})${ext}`))) i++;
    targetPath = path.join(targetDir, `${base} (${i})${ext}`);
  }

  try {
    await new Promise((resolve, reject) => {
      const mod = url.startsWith('https') ? require('https') : require('http');
      const doRequest = (requestUrl, redirectCount = 0) => {
        if (redirectCount > 5) return reject(new Error('Too many redirects'));
        const headers = {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
          'Referer': requestUrl
        };
        mod.get(requestUrl, { headers }, (resp) => {
          if (resp.statusCode >= 300 && resp.statusCode < 400 && resp.headers.location) {
            return doRequest(resp.headers.location, redirectCount + 1);
          }
          if (resp.statusCode !== 200) return reject(new Error(`HTTP ${resp.statusCode}`));
          const fileStream = fs.createWriteStream(targetPath);
          resp.pipe(fileStream);
          fileStream.on('finish', () => { fileStream.close(resolve); });
          fileStream.on('error', reject);
        }).on('error', reject);
      };
      doRequest(url);
    });
    if (path.extname(targetPath).toLowerCase() === '.png') {
      const ffmpegPath = getFFmpegPath();
      if (!ffmpegPath || !fs.existsSync(ffmpegPath)) throw new Error('FFmpeg is unavailable to prepare a DaVinci Resolve compatible image.');
      const convertedPath = `${targetPath}.converted.png`;
      await new Promise((resolve, reject) => {
        const proc = spawn(ffmpegPath, ['-y', '-i', targetPath, '-frames:v', '1', convertedPath], { env: getSpawnEnv(), windowsHide: true });
        let errorOutput = '';
        proc.stderr.on('data', data => { errorOutput += data.toString(); });
        proc.once('error', reject);
        proc.once('close', code => code === 0
          ? resolve()
          : reject(new Error(errorOutput.trim().split(/\r?\n/).filter(Boolean).slice(-1)[0] || `FFmpeg exited with code ${code}`)));
      });
      fs.unlinkSync(targetPath);
      fs.renameSync(convertedPath, targetPath);
    }
    res.json({ success: true, path: targetPath });
  } catch (err) {
    // Clean up partial file
    try { fs.unlinkSync(targetPath); } catch {}
    try { fs.unlinkSync(`${targetPath}.converted.png`); } catch {}
    res.status(500).json({ error: `Download failed: ${err.message}` });
  }
});

// Browse folder dialog for Assets Finder save path
app.post('/api/assets/browse-folder', async (req, res) => {
  if (!electronDialog?.showOpenDialog) {
    return res.status(501).json({ error: 'Folder browsing is only available in the desktop app.' });
  }
  try {
    const { canceled, filePaths } = await electronDialog.showOpenDialog({
      title: 'Select folder to save assets',
      properties: ['openDirectory', 'createDirectory']
    });
    if (canceled || !filePaths?.length) return res.json({ cancelled: true });
    res.json({ cancelled: false, path: filePaths[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


const wsClients = new Set();

wss.on('connection', (ws) => {
  wsClients.add(ws);
  // Send current history & yt-dlp status
  ws.send(JSON.stringify({ type: 'history', data: downloadHistory }));
  ws.send(JSON.stringify({ type: 'ytdlp-status', data: ytDlpStatus }));
  ws.on('close', () => wsClients.delete(ws));
});

function broadcast(data) {
  const msg = JSON.stringify(data);
  wsClients.forEach(ws => {
    if (ws.readyState === 1) ws.send(msg);
  });
}

// Platform-aware binary extension: .exe on Windows, no extension on macOS/Linux
const isWin = process.platform === 'win32';
const toolExt = isWin ? '.exe' : '';

function getYtDlpPath() {
  const baseDir = runtimeConfig.userDataPath || path.join(os.homedir(), '.nuutapao-downloader');
  const userToolsDir = path.join(baseDir, 'tools');
  const binaryName = `yt-dlp${toolExt}`;
  const targetPath = path.join(userToolsDir, binaryName);

  let bundlePath = null;
  if (runtimeConfig.isPackaged && runtimeConfig.resourcesPath) {
    bundlePath = path.join(runtimeConfig.resourcesPath, 'tools', binaryName);
  } else {
    bundlePath = path.join(__dirname, 'tools', binaryName);
  }

  // If user data copy doesn't exist yet, copy initial bundled binary
  if (!fs.existsSync(targetPath)) {
    if (!fs.existsSync(userToolsDir)) {
      try { fs.mkdirSync(userToolsDir, { recursive: true }); } catch (e) {}
    }
    if (bundlePath && fs.existsSync(bundlePath)) {
      try {
        fs.copyFileSync(bundlePath, targetPath);
        if (!isWin) {
          try { fs.chmodSync(targetPath, 0o755); } catch (e) {}
        }
      } catch (err) {
        return bundlePath;
      }
    } else {
      return bundlePath;
    }
  }
  return fs.existsSync(targetPath) ? targetPath : bundlePath;
}

function getToolPath(name) {
  if (runtimeAdapters.getToolPath) return runtimeAdapters.getToolPath(name);
  if (name === 'yt-dlp') return getYtDlpPath();
  const binaryName = `${name}${toolExt}`;
  if (runtimeConfig.isPackaged && runtimeConfig.resourcesPath) {
    const packagedPath = path.join(runtimeConfig.resourcesPath, 'tools', binaryName);
    if (fs.existsSync(packagedPath)) return packagedPath;
  }
  const localToolsPath = path.join(__dirname, 'tools', binaryName);
  if (fs.existsSync(localToolsPath)) return localToolsPath;
  try {
    return require('ffmpeg-static');
  } catch {
    return null;
  }
}

// ── yt-dlp Auto-Update Manager ──────────────────────────────────────────────
let ytDlpStatus = {
  version: '',
  status: 'idle', // idle | checking | updating | up-to-date | updated | error
  lastChecked: null,
  message: ''
};

function checkYtDlpVersion() {
  const ytDlpPath = getToolPath('yt-dlp');
  if (!ytDlpPath || !fs.existsSync(ytDlpPath)) return;
  try {
    const proc = runProcess(ytDlpPath, ['--version'], { env: getSpawnEnv() });
    let out = '';
    proc.stdout.on('data', d => out += d.toString());
    proc.on('close', (code) => {
      if (code === 0 && out.trim()) {
        ytDlpStatus.version = out.trim();
        broadcast({ type: 'ytdlp-status', data: ytDlpStatus });
      }
    });
  } catch (e) {}
}

let ytDlpUpdateQueue = Promise.resolve();
let ytDlp403RecoveryPromise = null;
let ytDlp403RecoveryAt = 0;

function updateYtDlp(channel = 'stable') {
  const update = ytDlpUpdateQueue.then(
    () => runYtDlpUpdate(channel),
    () => runYtDlpUpdate(channel)
  );
  ytDlpUpdateQueue = update.catch(() => null);
  return update;
}

function recoverYtDlpFor403() {
  if (ytDlp403RecoveryPromise) return ytDlp403RecoveryPromise;
  if (Date.now() - ytDlp403RecoveryAt < 10 * 60 * 1000) {
    return Promise.resolve(ytDlpStatus);
  }

  ytDlp403RecoveryAt = Date.now();
  ytDlp403RecoveryPromise = updateYtDlp('nightly').finally(() => {
    ytDlp403RecoveryPromise = null;
  });
  return ytDlp403RecoveryPromise;
}

function runYtDlpUpdate(channel = 'stable') {
  const ytDlpPath = getToolPath('yt-dlp');
  if (!ytDlpPath || !fs.existsSync(ytDlpPath)) {
    ytDlpStatus = { ...ytDlpStatus, status: 'error', message: 'yt-dlp binary not found' };
    broadcast({ type: 'ytdlp-status', data: ytDlpStatus });
    return Promise.resolve(ytDlpStatus);
  }

  ytDlpStatus = { ...ytDlpStatus, status: 'checking', message: 'Checking for yt-dlp updates...' };
  broadcast({ type: 'ytdlp-status', data: ytDlpStatus });

  return new Promise((resolve) => {
    const updateArgs = channel === 'nightly'
      ? ['--encoding', 'utf-8', '--update-to', 'nightly']
      : ['--encoding', 'utf-8', '-U'];
    const proc = runProcess(ytDlpPath, updateArgs, { env: getSpawnEnv() });
    let output = '';
    let errOutput = '';

    proc.stdout.on('data', d => output += d.toString());
    proc.stderr.on('data', d => errOutput += d.toString());

    proc.on('close', (code) => {
      const fullLog = (output + errOutput).trim();
      const verMatches = fullLog.match(/\d{4}\.\d{2}\.\d{2}/g);
      const latestVer = verMatches ? verMatches[verMatches.length - 1] : ytDlpStatus.version;

      ytDlpStatus.lastChecked = new Date().toISOString();
      getStateStore().patch({ engine: { lastChecked: ytDlpStatus.lastChecked } });

      if (fullLog.includes('up to date') || fullLog.includes('Up to date')) {
        ytDlpStatus = {
          ...ytDlpStatus,
          status: 'up-to-date',
          version: latestVer || ytDlpStatus.version,
          message: `yt-dlp is up to date (${latestVer || ytDlpStatus.version})`
        };
      } else if (fullLog.includes('Updated') || fullLog.includes('updated')) {
        ytDlpStatus = {
          ...ytDlpStatus,
          status: 'updated',
          version: latestVer || ytDlpStatus.version,
          message: `Updated yt-dlp to version ${latestVer}`
        };
      } else if (code === 0) {
        ytDlpStatus = {
          ...ytDlpStatus,
          status: 'up-to-date',
          version: latestVer || ytDlpStatus.version,
          message: fullLog || 'yt-dlp check complete'
        };
      } else {
        ytDlpStatus = {
          ...ytDlpStatus,
          status: 'error',
          message: errOutput.trim() || 'yt-dlp update failed'
        };
      }

      broadcast({ type: 'ytdlp-status', data: ytDlpStatus });
      resolve(ytDlpStatus);
    });
  });
}

app.get('/api/ytdlp-status', (req, res) => {
  res.json(ytDlpStatus);
});

app.post('/api/update-ytdlp', async (req, res) => {
  const result = await updateYtDlp();
  res.json(result);
});

function getToolStatus() {
  const ytDlpPath = getToolPath('yt-dlp');
  const ffmpegPath = getToolPath('ffmpeg');
  return {
    ready: Boolean(ytDlpPath && ffmpegPath && fs.existsSync(ytDlpPath) && fs.existsSync(ffmpegPath)),
    ytDlp: { available: Boolean(ytDlpPath && fs.existsSync(ytDlpPath)) },
    ffmpeg: { available: Boolean(ffmpegPath && fs.existsSync(ffmpegPath)) }
  };
}

function toolUnavailable(res, toolName) {
  return res.status(503).json({ error: `${toolName} is missing from this installation. Please reinstall Nuutapao Tools.` });
}

app.get('/api/health', (req, res) => {
  const tools = getToolStatus();
  res.status(tools.ready ? 200 : 503).json({ ok: tools.ready, tools });
});

// ── Internal Secure DNS (DoH) Proxy ─────────────────────────────────────────
const net = require('net');
const https = require('https');

let internalDohPort = null;
let currentDnsProvider = 'cloudflare';
let currentCustomDnsUrl = '';
const dohCache = new Map();
const DOH_CACHE_TTL_MS = 5 * 60 * 1000;
const DOH_CACHE_LIMIT = 512;

function getDohUrl(provider, customUrl) {
  if (provider === 'google') return 'https://dns.google/resolve';
  if (provider === 'opendns') return 'https://doh.opendns.com/dns-query';
  if (provider === 'quad9') return 'https://dns.quad9.net/dns-query';
  if (provider === 'adguard') return 'https://dns.adguard-dns.com/dns-query';
  if (provider === 'custom' && customUrl) return customUrl;
  return 'https://1.1.1.1/dns-query';
}

function resolveDoH(domain, provider, customUrl) {
  if (!domain || domain === 'localhost' || domain === '127.0.0.1') return Promise.resolve(null);
  const cacheKey = `${provider}:${domain}`;
  const cached = dohCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) return Promise.resolve(cached.value);
  if (cached) dohCache.delete(cacheKey);

  return new Promise(resolve => {
    const isGoogle = provider === 'google';
    const baseUrl = getDohUrl(provider, customUrl);
    const fullUrl = isGoogle 
      ? `${baseUrl}?name=${encodeURIComponent(domain)}&type=A`
      : `${baseUrl}?name=${encodeURIComponent(domain)}&type=A`;
    const headers = isGoogle ? {} : { 'accept': 'application/dns-json' };

    https.get(fullUrl, { headers, timeout: 4000 }, r => {
      let data = '';
      r.on('data', c => data += c);
      r.on('end', () => {
        try {
          const json = JSON.parse(data);
          const ans = json.Answer || json.answer;
          if (ans && ans.length) {
            const ip = ans.find(a => a.type === 1)?.data;
            if (ip) {
              if (dohCache.size >= DOH_CACHE_LIMIT) dohCache.delete(dohCache.keys().next().value);
              dohCache.set(cacheKey, { value: ip, expiresAt: Date.now() + DOH_CACHE_TTL_MS });
              return resolve(ip);
            }
          }
        } catch (e) {}
        resolve(null);
      });
    }).on('error', () => resolve(null));
  });
}

const dohProxy = http.createServer();
let dohProxyStarted = false;
dohProxy.on('connect', async (req, clientSocket, head) => {
  const [host, portStr] = req.url.split(':');
  const targetPort = parseInt(portStr) || 443;
  const resolvedIp = (currentDnsProvider !== 'os') 
    ? (await resolveDoH(host, currentDnsProvider, currentCustomDnsUrl) || host)
    : host;

  const serverSocket = net.connect(targetPort, resolvedIp, () => {
    clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
    serverSocket.write(head);
    serverSocket.pipe(clientSocket);
    clientSocket.pipe(serverSocket);
  });

  serverSocket.on('error', () => clientSocket.end());
  clientSocket.on('error', () => serverSocket.end());
});

function startDohProxy() {
  if (dohProxyStarted) return;
  dohProxyStarted = true;
  dohProxy.listen(0, '127.0.0.1', () => {
    internalDohPort = dohProxy.address().port;
    console.log(`🔒 Internal Secure DNS (DoH) Proxy running on port ${internalDohPort}`);
  });
}

function resolveProxyUrl(body = {}) {
  const dnsEnabled = body.dnsEnabled !== undefined ? body.dnsEnabled : true;
  const dnsProvider = body.dnsProvider || 'cloudflare';
  const customDnsUrl = body.customDnsUrl || '';
  const proxyEnabled = body.proxyEnabled || false;
  const proxyPreset = body.proxyPreset || 'warp';
  // Accept both field names: frontend historically sent `proxy`, server schema uses `proxyUrl`
  const proxyUrl = body.proxyUrl || body.proxy || '';

  currentDnsProvider = dnsProvider || 'cloudflare';
  currentCustomDnsUrl = customDnsUrl || '';

  if (proxyEnabled) {
    if (proxyPreset === 'warp') return 'socks5://127.0.0.1:10808';
    if (proxyPreset === 'clash') return 'http://127.0.0.1:7890';
    if (proxyPreset === 'shadowsocks') return 'socks5://127.0.0.1:1080';
    if (proxyPreset === 'custom') return proxyUrl || '';
    return proxyUrl || '';
  }

  if (dnsEnabled !== false && dnsProvider !== 'os' && internalDohPort) {
    return `http://127.0.0.1:${internalDohPort}`;
  }

  return '';
}

function getLocalProxyPort(preset) {
  if (preset === 'warp') return 10808;
  if (preset === 'clash') return 7890;
  if (preset === 'shadowsocks') return 1080;
  return null;
}

function validateAccessSettings(body = {}) {
  const cookieSource = body.cookieSource || 'none';
  if (cookieSource === 'file') {
    if (!body.cookieFile) {
      return 'No cookies file selected. Choose a valid cookies.txt file or use browser cookies.';
    }
    if (!fs.existsSync(body.cookieFile)) {
      return `Cookies file not found at "${body.cookieFile}". Choose a valid cookies.txt file or use browser cookies.`;
    }
  }
  if (body.proxyEnabled) {
    if (body.proxyPreset === 'custom') {
      const proxyUrl = body.proxyUrl || body.proxy || '';
      if (!proxyUrl) {
        return 'Custom proxy URL is empty. Enter a proxy URL or choose a preset.';
      }
      try {
        const parsed = new URL(proxyUrl);
        if (!['http:', 'https:', 'socks4:', 'socks4a:', 'socks5:', 'socks5h:'].includes(parsed.protocol)) {
          return `Proxy scheme "${parsed.protocol.replace(':', '')}" is not supported. Use http, https, socks4, socks4a, socks5, or socks5h.`;
        }
      } catch {
        return 'Custom proxy URL is invalid. Use format like http://127.0.0.1:1080 or socks5://127.0.0.1:10808';
      }
    }
  }
  return null;
}

function extractCleanUrl(rawUrl = '') {
  if (!rawUrl) return '';
  const trimmed = rawUrl.trim();
  const match = trimmed.match(/https?:\/\/[^\s"'<>]+/i);
  return match ? match[0] : trimmed;
}

function ensureNetscapeCookieFile(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return filePath;
  try {
    let content = fs.readFileSync(filePath, 'utf8');
    // Strip UTF-8 BOM if present
    if (content.charCodeAt(0) === 0xFEFF) {
      content = content.slice(1);
    }
    const trimmed = content.trim();

    // If JSON format (from Cookie-Editor / EditThisCookie extension)
    if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
      const parsed = JSON.parse(trimmed);
      const cookieArray = Array.isArray(parsed) ? parsed : [parsed];
      let netscapeLines = ['# Netscape HTTP Cookie File', '# Auto-converted by Nuutapao Downloader', ''];
      cookieArray.forEach(c => {
        if (!c.domain || !c.name) return;
        let domain = c.domain;
        const flag = domain.startsWith('.') ? 'TRUE' : 'FALSE';
        const path = c.path || '/';
        const secure = (c.secure !== undefined) ? (c.secure ? 'TRUE' : 'FALSE') : 'FALSE';
        const expiry = Math.round(c.expirationDate || c.expiry || (Date.now() / 1000 + 86400 * 365));
        const name = c.name;
        const value = c.value || '';
        netscapeLines.push(`${domain}\t${flag}\t${path}\t${secure}\t${expiry}\t${name}\t${value}`);
      });
      const netscapePath = path.join(os.tmpdir(), `nuu-netscape-cookies-${path.basename(filePath)}.txt`);
      fs.writeFileSync(netscapePath, netscapeLines.join('\r\n'), 'utf8');
      return netscapePath;
    }

    // Ensure Netscape header exists if it's already a text file
    if (!trimmed.includes('# Netscape HTTP Cookie File') && !trimmed.includes('# HTTP Cookie File')) {
      const formatted = `# Netscape HTTP Cookie File\r\n# Auto-fixed by Nuutapao Downloader\r\n\r\n${content}`;
      const netscapePath = path.join(os.tmpdir(), `nuu-fixed-cookies-${path.basename(filePath)}.txt`);
      fs.writeFileSync(netscapePath, formatted, 'utf8');
      return netscapePath;
    }
  } catch {}
  return filePath;
}

const tiktokResolvedCache = new Map();

function isTikTokUrl(url = '') {
  return /tiktok\.com|vm\.tiktok|vt\.tiktok/i.test(url || '');
}

async function resolveTikTokVideo(rawUrl) {
  let url = (rawUrl || '').trim();
  const cached = tiktokResolvedCache.get(url);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.data;
  }

  // Expand short URLs (vt.tiktok.com, vm.tiktok.com, /t/)
  if (/vt\.tiktok|vm\.tiktok|\/t\//i.test(url)) {
    try {
      const headRes = await fetch(url, {
        method: 'GET',
        redirect: 'follow',
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
        }
      });
      if (headRes.url && headRes.url !== url) {
        url = headRes.url.split('?')[0];
      }
    } catch {}
  }

  const ssstikUrl = 'https://ssstik.io';
  const getRes = await fetch(ssstikUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    }
  });

  const html = await getRes.text();
  const match = html.match(/s_tt\s*=\s*['"]([^'"]+)['"]/);
  const tt = match ? match[1] : null;
  if (!tt) throw new Error('Could not establish TikTok resolver session');

  const cookie = getRes.headers.get('set-cookie')?.split(';')?.[0] || '';

  const postRes = await fetch('https://ssstik.io/abc?url=dl', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'Origin': ssstikUrl,
      'Referer': `${ssstikUrl}/en`,
      'Cookie': cookie,
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
    },
    body: new URLSearchParams({
      id: url,
      locale: 'en',
      tt: tt
    })
  });

  const resHtml = await postRes.text();
  if (!resHtml || resHtml.includes('Video currently unavailable') || resHtml.includes('panel critical')) {
    throw new Error('TikTok video is unavailable or private');
  }

  const title = resHtml.match(/<p class="maintext"[^>]*>([\s\S]*?)<\/p>/)?.[1]?.trim() || 'TikTok Video';
  const author = resHtml.match(/<h2>([\s\S]*?)<\/h2>/)?.[1]?.trim() || 'TikTok Creator';
  const cover = resHtml.match(/background-image:\s*url\(([^)]+)\)/)?.[1] ||
                resHtml.match(/<img class="result_author"[^>]*src="([^"]+)"/)?.[1] || '';

  const videoMatch = resHtml.match(/href="([^"]+)"[^>]*class="[^"]*without_watermark/i) ||
                     resHtml.match(/href="([^"]+)"[^>]*>Without watermark/i) ||
                     resHtml.match(/class="[^"]*download_link[^"]*"[^>]*href="([^"]+)"/i);
  const videoUrl = videoMatch ? videoMatch[1] : null;

  const audioMatch = resHtml.match(/href="([^"]+)"[^>]*class="[^"]*music/i) ||
                     resHtml.match(/href="([^"]+)"[^>]*>Download MP3/i);
  const audioUrl = audioMatch ? audioMatch[1] : null;

  if (!videoUrl && !audioUrl) {
    throw new Error('Unable to extract video download URL');
  }

  const formats = [];
  if (videoUrl) {
    formats.push({
      format_id: 'hd-nowm',
      ext: 'mp4',
      resolution: 'HD (No Watermark)',
      filesize: null,
      vcodec: 'h264',
      acodec: 'aac',
      fps: 30,
      note: 'Direct HD Stream (No Watermark)'
    });
  }
  if (audioUrl) {
    formats.push({
      format_id: 'audio-mp3',
      ext: 'mp3',
      resolution: 'audio only',
      filesize: null,
      vcodec: 'none',
      acodec: 'mp3',
      note: 'Original Audio'
    });
  }

  const data = {
    title,
    uploader: author,
    duration: null,
    thumbnail: cover,
    view_count: null,
    like_count: null,
    upload_date: null,
    description: title,
    webpage_url: url,
    is_live: false,
    live_status: 'not_live',
    formats,
    directVideoUrl: videoUrl,
    directAudioUrl: audioUrl
  };

  tiktokResolvedCache.set(rawUrl, { data, expiresAt: Date.now() + 15 * 60 * 1000 });
  if (url !== rawUrl) {
    tiktokResolvedCache.set(url, { data, expiresAt: Date.now() + 15 * 60 * 1000 });
  }

  return data;
}

function isYouTubeUrl(url) {
  return /youtu\.?be|youtube\.com/i.test(url || '');
}

const h264FormatFilter = "[vcodec~='^(avc1|h264)']";

function buildPlatformArgs(url = '', hasCookies = false, isLive = false) {
  const args = [
    '--encoding', 'utf-8',
    '--trim-filenames', '180',
    '--no-playlist',
    '--no-check-certificates'
  ];

  // Only use --windows-filenames on Windows to sanitize characters like : * ? etc.
  if (isWin) {
    args.push('--windows-filenames');
  }

  if (isYouTubeUrl(url)) {
    // YouTube-only compat option — do not apply to other platforms
    args.push('--compat-options', 'no-youtube-unavailable-videos');
    // Let yt-dlp choose its cookie-aware clients for signed-in accounts.
    // In particular, android_vr does not support cookie authentication, so
    // forcing it here makes legitimate age-gated downloads fail even when a
    // valid cookies.txt file was supplied.
    if (hasCookies) {
      return args;
    }
    if (isLive) {
      args.push('--extractor-args', 'youtube:player_client=default,android');
    } else {
      args.push('--extractor-args', 'youtube:player_client=default,android_vr,web_embedded');
    }
  } else if (/instagram\.com|instagr\.am/i.test(url)) {
    args.push('--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36');
    args.push('--referer', 'https://www.instagram.com/');
  }
  return args;
}

function isCookieDbError(errMessage = '') {
  const normalized = (errMessage || '').toLowerCase();
  return (
    normalized.includes('cookies database') ||
    normalized.includes('cookie database') ||
    normalized.includes('could not find opera cookies') ||
    (normalized.includes('could not extract') && normalized.includes('cookie')) ||
    (normalized.includes('could not copy') && normalized.includes('cookie')) ||
    normalized.includes('cookie file is not valid') ||
    normalized.includes('cookies file must be netscape') ||
    normalized.includes('database is locked')
  );
}

function buildAccessArgs(body = {}, excludeCookies = false) {
  const args = [];
  const effectiveProxy = resolveProxyUrl(body);
  if (effectiveProxy) args.push('--proxy', effectiveProxy);
  if (!excludeCookies) {
    if (body.cookieSource === 'browser' && body.cookieBrowser) {
      args.push('--cookies-from-browser', body.cookieBrowser);
    } else if (body.cookieSource === 'file' && body.cookieFile) {
      const netscapeCookiePath = ensureNetscapeCookieFile(body.cookieFile);
      args.push('--cookies', netscapeCookiePath);
    }
  }
  return args;
}

function isHttp403Error(message = '') {
  return /http error 403|403: forbidden/i.test(message || '');
}

function isUsableYtDlpUpdate(result) {
  return result && (result.status === 'updated' || result.status === 'up-to-date');
}

function classifyYtDlpError(message = '', cookieSource = 'none') {
  const normalized = (message || '').toLowerCase();
  if (/cookies file must be netscape formatted/i.test(normalized)) {
    return 'Cookies file must be in Netscape format. Export your cookies in Netscape format or select your browser under Browser Cookies.';
  }
  if (/could not find .* cookies database|could not copy .* cookie database|could not extract .* cookies|cookie database in|database is locked|resource busy/i.test(normalized)) {
    return 'Could not access the selected browser cookies. Make sure the browser is installed and closed (or check Cookie Settings / use cookies.txt).';
  }
  if (/unexpected response|tiktok.*error|anti.?bot|challenge|blocked from accessing this post|universal data for rehydration/i.test(normalized) && /tiktok/i.test(normalized)) {
    return 'TikTok anti-bot verification returned an unexpected response. Try updating yt-dlp or using browser cookies in Settings.';
  }
  if (/age.?restricted|confirm your age|sign in to confirm/i.test(normalized)) {
    if (cookieSource === 'browser') {
      return 'Age-restricted video: Could not use browser cookies (browser may be open). Please close your browser completely or select "Use cookies.txt File" in Settings -> Cookies.';
    }
    if (cookieSource === 'file') {
      return 'YouTube still requires age verification. The selected cookies.txt was passed to yt-dlp, but YouTube did not accept its session for this video. Export a fresh Netscape-format cookies.txt while signed in to an age-verified account, make sure it includes YouTube cookies, then select the file again in Settings -> Cookies. Cookies expire, and some videos require an account that has already passed age verification.';
    }
    return 'This video requires age verification. Select "Use Browser Cookies" (and close your browser) or select "Use cookies.txt File" in Settings -> Cookies.';
  }
  if (/not available in your country|geo.?restricted|not available in this location|country block/i.test(normalized)) {
    return 'This video is region-locked and not available in your country. Use a proxy or VPN server located in an allowed region. Secure DNS (DoH) cannot change your geographic location.';
  }
  if (/login required|sign in|required.*cookies|members.?only|private video/i.test(normalized)) {
    return 'This video requires account access (login/membership). Provide browser cookies or a cookies.txt file from an authorized account in Settings -> Cookies.';
  }
  if (/connection refused|failed to establish connection|proxy error|socks|tunnel connection failed/i.test(normalized)) {
    return 'The configured proxy could not be reached. Make sure the proxy/VPN application is running and check its address and port.';
  }
  if (/could not resolve host|getaddrinfo|name.*resolution|name or service not known|nodename nor servname|curl.*\(6\)/i.test(normalized)) {
    return 'DNS resolution failed. The site may be blocked by your ISP. Try enabling a proxy/VPN in Settings.';
  }
  if (/time.?out|timed.?out|gateway time-out|curl.*\(28\)|connection.*timed/i.test(normalized)) {
    return 'Connection timed out. Check your internet connection or try a different proxy/VPN.';
  }
  if (/too many requests|http error 429|rate.?limit/i.test(normalized)) {
    return 'Too many requests sent to this service. Please wait a moment before downloading again.';
  }
  if (isHttp403Error(normalized)) {
    if (cookieSource === 'file') {
      return 'The platform still returned HTTP 403. Your cookies.txt was sent and Nuutapao tried to update yt-dlp. Export a fresh cookies.txt for this site while signed in, then retry. A VPN, proxy, or rate limit can also cause 403.';
    }
    if (cookieSource === 'browser') {
      return 'The platform still returned HTTP 403. Browser cookies were sent and Nuutapao tried to update yt-dlp. Sign in to this site in the selected browser, then retry. A VPN, proxy, or rate limit can also cause 403.';
    }
    return 'The platform still returned HTTP 403. Nuutapao tried to update yt-dlp. Try signed-in cookies from this site, or check whether a VPN, proxy, or rate limit is blocking access.';
  }
  if (/video.*unavailable|removed|taken down|copyright/i.test(normalized)) {
    return 'This video is unavailable (removed, taken down, or blocked for copyright). It cannot be downloaded.';
  }
  if (/cannot be partially downloaded/i.test(normalized)) {
    return 'This live stream format cannot be trimmed while live. Try clipping after the live stream ends, or download the full stream.';
  }
  if (/no space left on device|disk full/i.test(normalized)) {
    return 'Disk is full. Please free up disk space in your download folder.';
  }
  if (/requested format is not available|no video formats found|format.*not available/i.test(normalized)) {
    return 'The requested video format or quality is not available for this link. Try selecting "Best Available (Auto)" quality.';
  }
  return (message || '').trim() || 'Download failed';
}

function ensureOutputDirectory(directory) {
  try {
    fs.mkdirSync(directory, { recursive: true });
    return fs.statSync(directory).isDirectory() ? null : 'Output path is not a folder.';
  } catch (error) {
    return `Unable to create output folder: ${error.message}`;
  }
}

// GET video info
app.post('/api/info', async (req, res) => {
  const rawUrl = req.body.url;
  const url = extractCleanUrl(rawUrl);
  if (!url) return res.status(400).json({ error: 'URL is required' });
  const accessError = validateAccessSettings(req.body);
  if (accessError) return res.status(400).json({ error: accessError });

  const ytDlpPath = getToolPath('yt-dlp');
  if (!ytDlpPath || !fs.existsSync(ytDlpPath)) return toolUnavailable(res, 'yt-dlp');

  function fetchInfo(excludeCookies = false) {
    const hasCookies = Boolean(!excludeCookies && req.body.cookieSource && req.body.cookieSource !== 'none');
    return new Promise((resolve) => {
      const args = [
        '--dump-json', '--no-playlist',
        '--socket-timeout', '45',
        '--extractor-retries', '5',
        ...buildPlatformArgs(url, hasCookies),
        ...buildAccessArgs(req.body, excludeCookies),
        url
      ];

      const proc = runProcess(ytDlpPath, args, { env: getSpawnEnv() });
      let output = '';
      let errOutput = '';

      proc.stdout.on('data', d => output += d.toString());
      proc.stderr.on('data', d => errOutput += d.toString());
      proc.once('error', (err) => {
        resolve({ ok: false, error: `Unable to start yt-dlp: ${err.message}`, rawError: err.message });
      });

      proc.on('close', (code) => {
        if (code === 0) {
          try {
            const info = JSON.parse(output);
            const formats = (info.formats || [])
              .filter(f => f.vcodec !== 'none' || f.acodec !== 'none')
              .map(f => ({
                format_id: f.format_id,
                ext: f.ext,
                resolution: f.resolution || (f.height ? `${f.height}p` : 'audio only'),
                filesize: f.filesize || f.filesize_approx || null,
                vcodec: f.vcodec,
                acodec: f.acodec,
                fps: f.fps,
                tbr: f.tbr,
                note: f.format_note
              }))
              .reverse();

            const isLive = Boolean(info.is_live || info.live_status === 'is_live' || info.is_live_content || info.live_status === 'is_upcoming');
            return resolve({
              ok: true,
              data: {
                title: info.title,
                uploader: info.uploader,
                duration: info.duration,
                thumbnail: info.thumbnail,
                view_count: info.view_count,
                like_count: info.like_count,
                upload_date: info.upload_date,
                description: info.description,
                webpage_url: info.webpage_url,
                is_live: isLive,
                live_status: info.live_status,
                formats
              }
            });
          } catch (e) {
            return resolve({ ok: false, error: 'Failed to parse video info', rawError: output });
          }
        }
        resolve({ ok: false, code, rawError: errOutput });
      });
    });
  }

  let result = await fetchInfo(false);
  if (!result.ok && isHttp403Error(result.rawError || result.error)) {
    const updateResult = await recoverYtDlpFor403();
    if (isUsableYtDlpUpdate(updateResult)) {
      result = await fetchInfo(false);
    }
  }

  // If cookies failed to load, retry once without cookies for public media
  if (!result.ok && req.body.cookieSource === 'browser' && isCookieDbError(result.rawError || '')) {
    const retryResult = await fetchInfo(true);
    if (retryResult.ok) {
      result = retryResult;
    }
  }

  // Fallback for TikTok if yt-dlp was challenged or blocked by anti-bot
  if (!result.ok && isTikTokUrl(url)) {
    try {
      const resolved = await resolveTikTokVideo(url);
      if (resolved) {
        return res.json(resolved);
      }
    } catch (e) {}
  }

  if (result.ok) {
    return res.json(result.data);
  }
  return res.status(500).json({ error: classifyYtDlpError(result.rawError || result.error || 'Failed to fetch video info', req.body.cookieSource) });
});

function parseTimeToSeconds(timeStr) {
  if (!timeStr) return 0;
  const parts = timeStr.toString().trim().split(':').map(Number);
  if (parts.length === 3) {
    return (parts[0] || 0) * 3600 + (parts[1] || 0) * 60 + (parts[2] || 0);
  } else if (parts.length === 2) {
    return (parts[0] || 0) * 60 + (parts[1] || 0);
  } else if (parts.length === 1) {
    return parts[0] || 0;
  }
  return 0;
}

function formatEtaSeconds(totalSeconds) {
  if (!totalSeconds || isNaN(totalSeconds) || totalSeconds <= 0) return '00:00';
  const hrs = Math.floor(totalSeconds / 3600);
  const mins = Math.floor((totalSeconds % 3600) / 60);
  const secs = Math.floor(totalSeconds % 60);
  if (hrs > 0) {
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

function getSectionDuration(sectionStr) {
  if (!sectionStr) return 0;
  const clean = sectionStr.replace(/^\*/, '');
  const [startPart, endPart] = clean.split('-');
  if (!startPart || !endPart || endPart.toLowerCase() === 'inf') return 0;
  const startSec = parseTimeToSeconds(startPart);
  const endSec = parseTimeToSeconds(endPart);
  return Math.max(0, endSec - startSec);
}

function formatTimeSection(timeSection) {
  if (!timeSection) return null;
  if (typeof timeSection === 'string') {
    const trimmed = timeSection.trim();
    if (!trimmed) return null;
    return trimmed.startsWith('*') ? trimmed : `*${trimmed}`;
  }
  if (typeof timeSection === 'object') {
    const start = (timeSection.start || '').trim() || '00:00:00';
    const end = (timeSection.end || '').trim() || 'inf';
    return `*${start}-${end}`;
  }
  return null;
}

// Start download
app.post('/api/download', (req, res) => {
  const { format, audioOnly, outputPath, subtitles, ext, embedThumbnail, timeSection, section } = req.body;
  const rawUrl = req.body.url;
  const url = extractCleanUrl(rawUrl);
  if (!url) return res.status(400).json({ error: 'URL is required' });
  const accessError = validateAccessSettings(req.body);
  if (accessError) return res.status(400).json({ error: accessError });

  const ytDlpPath = getToolPath('yt-dlp');
  if (!ytDlpPath || !fs.existsSync(ytDlpPath)) return toolUnavailable(res, 'yt-dlp');
  const id = uuidv4();
  const downloadDir = outputPath || defaultDownloadPath;
  const directoryError = ensureOutputDirectory(downloadDir);
  if (directoryError) return res.status(400).json({ error: directoryError });
  const ffmpegPath = getToolPath('ffmpeg');
  if (!ffmpegPath || !fs.existsSync(ffmpegPath)) return toolUnavailable(res, 'FFmpeg');

  const normalizedSection = formatTimeSection(timeSection || section);
  const targetDuration = getSectionDuration(normalizedSection) || Number(req.body.totalDuration) || 0;
  const isLiveStream = Boolean(req.body.isLive);

  function normalizeFormatRequest(format) {
    if (!format || format === 'best') return { isBest: true, height: null };
    const genericHeight = String(format).match(/height<=(\d+)/i);
    if (genericHeight) {
      return { isBest: false, height: genericHeight[1] };
    }
    const numberMatch = String(format).match(/(\d{3,4})p?/i);
    if (numberMatch && ['4320', '2160', '1440', '1080', '720', '480', '360', '240'].includes(numberMatch[1])) {
      return { isBest: false, height: numberMatch[1] };
    }
    return { isBest: true, height: null };
  }

  function buildDownloadArgs(excludeCookies = false, forceLiveFallback = false, directStreamInfo = null) {
    const {
      url,
      format,
      audioOnly,
      ext,
      outputPath,
      subtitles,
      embedThumbnail,
      isLive
    } = req.body;

    const downloadDir = outputPath || defaultDownloadPath;
    const hasCookies = !excludeCookies && (
      (req.body.cookieSource === 'browser' && req.body.cookieBrowser) ||
      (req.body.cookieSource === 'file' && req.body.cookieFile)
    );

    const isDirectTikTok = Boolean(directStreamInfo && isTikTokUrl(url));
    const targetUrl = isDirectTikTok
      ? (audioOnly ? (directStreamInfo.directAudioUrl || directStreamInfo.directVideoUrl) : directStreamInfo.directVideoUrl)
      : url;

    let args = [
      '--newline',
      '--no-simulate',
      '--progress',
      '--live-from-start',
      '--extractor-retries', '5',
      '--retries', '5',
      '--fragment-retries', '10',
      '--socket-timeout', '45',
      '--concurrent-fragments', '5',
      ...buildPlatformArgs(url, hasCookies, isLive),
      ...buildAccessArgs(req.body, excludeCookies)
    ];

    if (!isDirectTikTok) {
      args.push('--print', 'before_dl:NuuMeta:%(title)s|||%(thumbnail)s');
    } else {
      args.push('--user-agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36');
    }

    if (normalizedSection) {
      args.push('--download-sections', normalizedSection);
      args.push('--force-keyframes-at-cuts');
    }

    if (audioOnly) {
      const audioExt = ext || 'mp3';
      args.push('-f', 'ba[ext=m4a]/ba/b', '-x', '--audio-format', audioExt, '--audio-quality', '0');
      if (embedThumbnail !== false) {
        args.push('--embed-thumbnail');
      }
      if (audioExt === 'mp3') {
        args.push('--postprocessor-args', 'ffmpeg:-codec:a libmp3lame -b:a 320k -ar 48000');
      } else if (audioExt === 'm4a' || audioExt === 'aac') {
        args.push('--postprocessor-args', 'ffmpeg:-codec:a aac -b:a 256k -ar 48000');
      } else if (audioExt === 'wav') {
        args.push('--postprocessor-args', 'ffmpeg:-codec:a pcm_s16le -ar 48000');
      }
    } else {
      const videoExt = ext || 'mp4';
      const ytUrl = isYouTubeUrl(url);
      const parsedFormat = normalizeFormatRequest(format);
      const videoFilter = videoExt === 'mp4' ? h264FormatFilter : '';

      if (isDirectTikTok) {
        args.push('--recode-video', 'mp4');
        args.push('--postprocessor-args', 'ffmpeg:-c:v copy -c:a aac -b:a 192k -ar 48000 -movflags +faststart');
      } else if (isLive) {
        if (!parsedFormat.isBest && parsedFormat.height) {
          const h = parsedFormat.height;
          args.push('-f', `bv*${videoFilter}[height<=?${h}]+ba/b${videoFilter}[height<=?${h}]/bv*${videoFilter}+ba/b${videoFilter}`);
        } else {
          args.push('-f', `bv*${videoFilter}+ba/b${videoFilter}`);
        }
        args.push('--merge-output-format', videoExt);
        args.push('--postprocessor-args', 'ffmpeg:-c:a aac -b:a 192k -ar 48000');
      } else if (videoExt === 'mp4') {
        if (!parsedFormat.isBest && parsedFormat.height) {
          const h = parsedFormat.height;
          if (ytUrl) {
            args.push('-f',
              `bv*${videoFilter}[height<=?${h}][ext=mp4]+ba[ext=m4a]/` +
              `bv*${videoFilter}[height<=?${h}]+ba/` +
              `b${videoFilter}[height<=?${h}]/` +
              `bv*${videoFilter}[ext=mp4]+ba[ext=m4a]/` +
              `bv*${videoFilter}+ba/b${videoFilter}`
            );
          } else {
            args.push('-f',
              `b${videoFilter}[height<=?${h}][ext=mp4]/` +
              `b${videoFilter}[height<=?${h}]/` +
              `bv*${videoFilter}[height<=?${h}][ext=mp4]+ba[ext=m4a]/` +
              `bv*${videoFilter}[height<=?${h}]+ba/` +
              `b${videoFilter}[width<=?${h}]/` +
              `bv*${videoFilter}[width<=?${h}]+ba/` +
              `b${videoFilter}/bv*${videoFilter}+ba/b${videoFilter}`
            );
          }
        } else {
          if (ytUrl) {
            args.push('-f',
              `bv*${videoFilter}[ext=mp4]+ba[ext=m4a]/` +
              `bv*${videoFilter}+ba/` +
              `b${videoFilter}[ext=mp4]/` +
              `b${videoFilter}`
            );
          } else {
            args.push('-f',
              `b${videoFilter}[ext=mp4]/` +
              `bv*${videoFilter}[ext=mp4]+ba[ext=m4a]/` +
              `b${videoFilter}/` +
              `bv*${videoFilter}+ba/` +
              `b${videoFilter}`
            );
          }
        }
        args.push('--merge-output-format', 'mp4');
        args.push('--postprocessor-args', 'ffmpeg:-c:a aac -b:a 192k -ar 48000 -movflags +faststart');
      } else {
        if (!parsedFormat.isBest && parsedFormat.height) {
          const h = parsedFormat.height;
          if (ytUrl) {
            args.push('-f', `bv*[height<=?${h}]+ba/b[height<=?${h}]/bv*+ba/b`);
          } else {
            args.push('-f', `b[height<=?${h}]/bv*[height<=?${h}]+ba/b[width<=?${h}]/b/bv*+ba/best`);
          }
        } else {
          if (ytUrl) {
            args.push('-f', 'bv*+ba/b');
          } else {
            args.push('-f', 'b/bv*+ba/best');
          }
        }
        args.push('--merge-output-format', videoExt);
        if (videoExt === 'mov') {
          args.push('--postprocessor-args', 'ffmpeg:-c:a aac -b:a 192k -ar 48000');
        } else if (videoExt === 'webm' || videoExt === 'mkv') {
          args.push('--remux-video', videoExt);
        }
      }
    }

    if (subtitles) {
      args.push('--write-sub', '--write-auto-sub', '--sub-lang', 'en,th');
    }

    args.push('--ffmpeg-location', ffmpegPath);
    if (isDirectTikTok && directStreamInfo?.title) {
      const safeTitle = directStreamInfo.title.replace(/[\\/:*?"<>|]/g, '').trim().substring(0, 150) || 'TikTok Video';
      const targetExt = audioOnly ? (ext || 'mp3') : (ext || 'mp4');
      if (normalizedSection) {
        const displayRange = normalizedSection.replace(/^\*/, '').replace(/[:]/g, '.');
        args.push('-o', path.join(downloadDir, `${safeTitle} [${displayRange}].${targetExt}`), targetUrl);
      } else {
        args.push('-o', path.join(downloadDir, `${safeTitle}.${targetExt}`), targetUrl);
      }
    } else if (normalizedSection) {
      const displayRange = normalizedSection.replace(/^\*/, '').replace(/[:]/g, '.');
      args.push('-o', path.join(downloadDir, `%(title)s [${displayRange}].%(ext)s`), targetUrl);
    } else {
      args.push('-o', path.join(downloadDir, '%(title)s.%(ext)s'), targetUrl);
    }
    return args;
  }

  const download = {
    id,
    url,
    status: 'downloading',
    progress: 0,
    speed: '',
    eta: '',
    title: '',
    filename: '',
    thumbnail: '',
    outputDir: downloadDir,
    startedAt: new Date().toISOString(),
    audioOnly: audioOnly || false,
    timeSection: normalizedSection ? normalizedSection.replace(/^\*/, '') : null,
    error: null
  };

  const downloadEntry = { proc: null, info: download, isCancelled: false };
  activeDownloads.set(id, downloadEntry);

  let lastBroadcastTime = 0;

  function handleDownloadLine(rawLine) {
    if (downloadEntry.isCancelled) return;
    const line = (rawLine || '').toString();

    if (line.includes('NuuMeta:')) {
      const metaMatch = line.match(/NuuMeta:(.*?)\|\|\|(.*)/);
      if (metaMatch) {
        const extractedTitle = metaMatch[1].trim();
        const extractedThumb = metaMatch[2].trim();
        if (extractedTitle) {
          download.title = normalizedSection
            ? `[${normalizedSection.replace(/^\*/, '')}] ${extractedTitle}`
            : extractedTitle;
        }
        if (extractedThumb && extractedThumb.startsWith('http')) download.thumbnail = extractedThumb;
      }
    }

    const progressMatch = line.match(/(\d+\.?\d*)%/);
    const fragMatch = line.match(/(\d+)\s+of\s+(\d+)\s+fragments/i) || line.match(/Fragment\s+(\d+)\/(\d+)/i);
    const hlsItemMatch = line.match(/Downloading\s+(?:item|segment)\s+(\d+)\s+of\s+(\d+)/i);
    const speedMatch = line.match(/at\s+([\d.]+\w+\/s)/);
    const etaMatch = line.match(/ETA\s+([\d:]+)/);
    const destMatch = line.match(/\[download\] Destination: (.+)/);
    const mergeMatch = line.match(/\[Merger\] Merging formats into "(.+)"/);
    const extractAudioMatch = line.match(/\[ExtractAudio\] Destination: (.+)/);
    const alreadyMatch = line.match(/\[download\] (.+) has already been downloaded/);
    const fixupMatch = line.match(/\[Fixup[a-zA-Z0-9]+\] Moving file ".+" to "(.+)"/);
    const moveMatch = line.match(/\[MoveFiles\] Moving file ".+" to "(.+)"/);

    // FFmpeg HLS / live stream cutting progress
    const ffmpegTimeMatch = line.match(/time=(\d+:\d+:\d+\.?\d*|\d+\.?\d*)/);
    const ffmpegSpeedMatch = line.match(/speed=\s*([\d.]+x)/);
    const ffmpegBitrateMatch = line.match(/bitrate=\s*([\d.]+\w+\/s)/);

    if (destMatch) {
      const rawName = path.basename(destMatch[1].trim());
      download.filename = rawName.replace(/\.f\d+(\.[a-zA-Z0-9]+)$/, '$1');
    }
    if (mergeMatch) download.filename = path.basename(mergeMatch[1].trim());
    if (extractAudioMatch) download.filename = path.basename(extractAudioMatch[1].trim());
    if (alreadyMatch) download.filename = path.basename(alreadyMatch[1].trim());
    if (fixupMatch) download.filename = path.basename(fixupMatch[1].trim());
    if (moveMatch) download.filename = path.basename(moveMatch[1].trim());

    if (line.includes('[download] 100%')) {
      download.progress = 100;
    } else if (progressMatch) {
      download.progress = parseFloat(progressMatch[1]);
    } else if (fragMatch) {
      const cur = parseInt(fragMatch[1], 10);
      const total = parseInt(fragMatch[2], 10);
      if (total > 0) download.progress = Math.min(99.5, Math.round((cur / total) * 1000) / 10);
    } else if (hlsItemMatch) {
      const cur = parseInt(hlsItemMatch[1], 10);
      const total = parseInt(hlsItemMatch[2], 10);
      if (total > 0) download.progress = Math.min(99.5, Math.round((cur / total) * 1000) / 10);
    } else if (ffmpegTimeMatch) {
      const currentSec = parseTimeToSeconds(ffmpegTimeMatch[1]);
      if (targetDuration > 0) {
        download.progress = Math.min(99.5, Math.round((currentSec / targetDuration) * 1000) / 10);
      }
      if (ffmpegSpeedMatch) {
        const speedVal = ffmpegSpeedMatch[1];
        const speedNum = parseFloat(speedVal);
        if (ffmpegBitrateMatch) {
          download.speed = `${speedVal} (${ffmpegBitrateMatch[1]})`;
        } else {
          download.speed = speedVal;
        }
        if (speedNum > 0 && targetDuration > currentSec) {
          const remainingSec = Math.round((targetDuration - currentSec) / speedNum);
          download.eta = formatEtaSeconds(remainingSec);
        }
      }
    }

    if (speedMatch) download.speed = speedMatch[1];
    if (etaMatch) download.eta = etaMatch[1];

    const now = Date.now();
    if (now - lastBroadcastTime >= 100 || download.progress === 100) {
      lastBroadcastTime = now;
      broadcast({ type: 'progress', id, download: { ...download } });
    }
  }

  let attemptedLiveFallback = false;
  let attemptedFormatFallback = false;
  let attemptedTikTokFallback = false;
  let attemptedEngineRecovery = false;

  async function startProcess(excludeCookies = false, forceLiveFallback = false, forceFormatFallback = false, directStreamInfo = null) {
    if (directStreamInfo) {
      if (directStreamInfo.title) {
        download.title = normalizedSection
          ? `[${normalizedSection.replace(/^\*/, '')}] ${directStreamInfo.title}`
          : directStreamInfo.title;
      }
      if (directStreamInfo.thumbnail) download.thumbnail = directStreamInfo.thumbnail;
    } else if (isTikTokUrl(url)) {
      const cached = tiktokResolvedCache.get(url);
      if (cached && cached.expiresAt > Date.now() && cached.data) {
        directStreamInfo = cached.data;
        if (directStreamInfo.title) {
          download.title = normalizedSection
            ? `[${normalizedSection.replace(/^\*/, '')}] ${directStreamInfo.title}`
            : directStreamInfo.title;
        }
        if (directStreamInfo.thumbnail) download.thumbnail = directStreamInfo.thumbnail;
      }
    }

    let args = buildDownloadArgs(excludeCookies, forceLiveFallback, directStreamInfo);

    // If retrying with format fallback, replace the -f argument with universal fallback selector
    if (forceFormatFallback) {
      const fIdx = args.indexOf('-f');
      if (fIdx !== -1 && fIdx + 1 < args.length) {
        // Do not keep the H.264 restriction from the preferred MP4 selector here:
        // some extractors only expose VP9/AV1 (or audio-only) formats. Let yt-dlp
        // choose an available source and leave the requested post-processing intact.
        args[fIdx + 1] = audioOnly ? 'ba/b' : 'bv*+ba/b';
      }
    }
    const proc = runProcess(ytDlpPath, args, { env: getSpawnEnv(), detached: !isWin });
    downloadEntry.proc = proc;

    let stderrBuffer = '';

    proc.once('error', (err) => {
      if (downloadEntry.isCancelled) return;
      activeDownloads.delete(id);
      download.status = 'error';
      download.error = `Unable to start yt-dlp: ${err.message}`;
      download.finishedAt = new Date().toISOString();
      recordHistory({ ...download });
      broadcast({ type: 'progress', id, download: { ...download } });
    });

    proc.stdout.on('data', (data) => {
      const lines = data.toString().split(/\r?\n/);
      for (const line of lines) {
        handleDownloadLine(line);
      }
    });

    proc.stderr.on('data', (data) => {
      if (downloadEntry.isCancelled) return;
      const text = data.toString();
      stderrBuffer += text + '\n';
      const lines = text.split(/\r?\n/);
      for (const line of lines) {
        handleDownloadLine(line);
        broadcast({ type: 'log', id, message: line });
      }
    });

    proc.on('close', async (code) => {
      if (downloadEntry.isCancelled) return;

      if (code !== 0 && !attemptedEngineRecovery && isHttp403Error(stderrBuffer)) {
        attemptedEngineRecovery = true;
        broadcast({ type: 'log', id, message: 'HTTP 403. Updating yt-dlp nightly, then retrying with the same settings...' });
        const updateResult = await recoverYtDlpFor403();
        if (isUsableYtDlpUpdate(updateResult) && !downloadEntry.isCancelled) {
          return startProcess(excludeCookies, forceLiveFallback, forceFormatFallback, directStreamInfo);
        }
      }

      // If failed due to cookie database error and we haven't retried yet, retry without cookies
      if (code !== 0 && !excludeCookies && req.body.cookieSource === 'browser' && isCookieDbError(stderrBuffer)) {
        return startProcess(true, forceLiveFallback);
      }

      // If failed due to partial download restriction on livestream format, retry with live fallback client
      if (code !== 0 && !attemptedLiveFallback && stderrBuffer.toLowerCase().includes('cannot be partially downloaded')) {
        attemptedLiveFallback = true;
        return startProcess(excludeCookies, true);
      }

      // If failed due to format not available, retry with 'best' format as ultimate fallback
      if (code !== 0 && !attemptedFormatFallback && /requested format is not available|no video formats found|format.*not available/i.test(stderrBuffer)) {
        attemptedFormatFallback = true;
        return startProcess(excludeCookies, forceLiveFallback, true);
      }

      // If TikTok download failed with anti-bot or challenge error, resolve and retry via direct stream
      if (code !== 0 && !attemptedTikTokFallback && isTikTokUrl(url) && !directStreamInfo) {
        attemptedTikTokFallback = true;
        try {
          const resolved = await resolveTikTokVideo(url);
          if (resolved && (resolved.directVideoUrl || resolved.directAudioUrl)) {
            return startProcess(true, false, false, resolved);
          }
        } catch (e) {}
      }

      activeDownloads.delete(id);
      if (code === 0) {
        download.status = 'done';
        download.progress = 100;
        download.finishedAt = new Date().toISOString();

        // If filename wasn't captured from stdout lines, locate the newly created file in downloadDir
        if (!download.filename && download.title && fs.existsSync(downloadDir)) {
          try {
            const files = fs.readdirSync(downloadDir);
            const cleanTitle = download.title.replace(/^\[[^\]]+\]\s*/, '').replace(/[\\/:*?"<>|]/g, '').trim().toLowerCase();
            const matched = files.find(f => f.toLowerCase().startsWith(cleanTitle));
            if (matched) download.filename = matched;
          } catch {}
        }
      } else {
        download.status = 'error';
        const lines = stderrBuffer.split('\n').map(l => l.trim()).filter(l => l.startsWith('ERROR:') || l.toLowerCase().includes('error:'));
        const rawError = lines.length > 0
          ? lines[lines.length - 1].replace(/^ERROR:\s*/i, '')
          : (stderrBuffer.trim().split('\n').pop() || 'Download failed');
        download.error = classifyYtDlpError(rawError, req.body.cookieSource);
        download.rawError = rawError;
        download.finishedAt = new Date().toISOString();
        cleanupPartialFiles(downloadDir, download.title, download.filename);
      }
      recordHistory({ ...download });
      broadcast({ type: 'progress', id, download: { ...download } });
    });
  }

  startProcess(false);
  res.json({ id, message: 'Download started' });
});

function cleanupPartialFiles(outputDir, title, filename) {
  if (!outputDir || !fs.existsSync(outputDir)) return;

  const titleClean = (title || filename || '').replace(/[\\/:*?"<>|]/g, '').replace(/\.f\d+(\.[a-zA-Z0-9]+)?$/, '').trim();
  const titleWords = titleClean.split(/\s+/).filter(w => w.length > 3);

  try {
    const files = fs.readdirSync(outputDir);
    files.forEach(f => {
      let isMatch = false;

      // 1. Direct match on filename or title
      if (filename && f.includes(filename.replace(/\.f\d+\.[a-zA-Z0-9]+$/, ''))) isMatch = true;
      if (titleClean && f.includes(titleClean)) isMatch = true;

      // 2. Match if file contains main title words
      if (!isMatch && titleWords.length > 0) {
        const matchingWords = titleWords.filter(w => f.toLowerCase().includes(w.toLowerCase()));
        if (matchingWords.length >= Math.min(2, titleWords.length)) {
          isMatch = true;
        }
      }

      // 3. Match temporary extensions / fragment markers (.f137, .f401, .f251, .part, .ytdl, etc.)
      const isTempExt = f.endsWith('.part') || f.endsWith('.ytdl') || f.endsWith('.temp') || /\.f\d+/i.test(f) || /\.frag\d+/i.test(f);
      if (isTempExt || isMatch) {
        const filePath = path.join(outputDir, f);
        try {
          fs.unlinkSync(filePath);
        } catch (e) {}
      }
    });
  } catch (e) {}
}

// Cancel download
app.post('/api/cancel/:id', (req, res) => {
  const entry = activeDownloads.get(req.params.id);
  if (!entry) return res.status(404).json({ error: 'Download not found' });

  entry.isCancelled = true;
  entry.info.status = 'cancelled';
  entry.info.finishedAt = new Date().toISOString();

  // Force-kill process tree (yt-dlp + ffmpeg children)
  if (entry.proc) {
    // 1. Destroy stdio streams immediately to stop all data flow
    try { entry.proc.stdout.destroy(); } catch (e) {}
    try { entry.proc.stderr.destroy(); } catch (e) {}
    // 2. Kill main process synchronously 
    try { entry.proc.kill('SIGTERM'); } catch (e) {}
    // 3. Force-kill entire process tree (includes ffmpeg child processes)
    if (entry.proc.pid) {
      if (isWin) {
        runShell(`taskkill /pid ${entry.proc.pid} /T /F`, () => {});
      } else {
        // macOS/Linux: kill process group
        try { process.kill(-entry.proc.pid, 'SIGKILL'); } catch (e) {}
        try { entry.proc.kill('SIGKILL'); } catch (e) {}
      }
    }
  }

  // Delete partial downloaded files from disk immediately & retry 600ms later after Windows file handle release
  const filename = entry.info.filename;
  const title = entry.info.title;
  const outputDir = entry.info.outputDir || defaultDownloadPath;

  cleanupPartialFiles(outputDir, title, filename);
  setTimeout(() => {
    cleanupPartialFiles(outputDir, title, filename);
  }, 600);

  activeDownloads.delete(req.params.id);
  recordHistory({ ...entry.info });

  broadcast({ type: 'progress', id: req.params.id, download: { ...entry.info } });

  res.json({ message: 'Cancelled successfully' });
});

// Get active downloads
app.get('/api/downloads', (req, res) => {
  const active = Array.from(activeDownloads.values()).map(e => e.info);
  res.json({ active, history: downloadHistory });
});

// Open download folder / highlight file
app.get('/api/open-folder', (req, res) => {
  const folderPath = req.query.path || defaultDownloadPath;
  const fileName = req.query.file;

  const isFilePath = fs.existsSync(folderPath) && fs.statSync(folderPath).isFile();
  const targetPath = isFilePath ? path.dirname(folderPath) : fs.existsSync(folderPath) ? folderPath : defaultDownloadPath;
  const fullFilePath = isFilePath ? folderPath : fileName ? path.join(targetPath, fileName) : null;

  if (fullFilePath && fs.existsSync(fullFilePath)) {
    if (process.platform === 'win32') {
      runShell(`explorer /select,"${fullFilePath}"`);
    } else if (process.platform === 'darwin') {
      runShell(`open -R "${fullFilePath}"`);
    } else {
      runShell(`xdg-open "${targetPath}"`);
    }
  } else {
    if (process.platform === 'win32') {
      runShell(`explorer "${targetPath}"`);
    } else if (process.platform === 'darwin') {
      runShell(`open "${targetPath}"`);
    } else {
      runShell(`xdg-open "${targetPath}"`);
    }
  }
  res.json({ message: 'Opened' });
});

// Select folder via Electron dialog
let electronDialog = null;
app.get('/api/select-folder', async (req, res) => {
  if (electronDialog) {
    const currentPath = req.query.current || defaultDownloadPath;
    const dialogOpts = {
      properties: ['openDirectory'],
      defaultPath: currentPath
    };
    const { canceled, filePaths } = await electronDialog.showOpenDialog(dialogOpts);
    if (!canceled && filePaths.length > 0) {
      return res.json({ path: filePaths[0] });
    }
  }
  res.json({ path: null });
});

app.get('/api/select-file', async (req, res) => {
  if (electronDialog) {
    const { canceled, filePaths } = await electronDialog.showOpenDialog({
      properties: ['openFile'],
      filters: [
        { name: 'Text Files', extensions: ['txt'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    });
    if (!canceled && filePaths.length > 0) {
      return res.json({ path: filePaths[0] });
    }
  }
  res.json({ path: null });
});

// Select files for converter via Electron dialog
app.get('/api/select-convert-files', async (req, res) => {
  if (electronDialog) {
    const { canceled, filePaths } = await electronDialog.showOpenDialog({
      properties: ['openFile', 'multiSelections'],
      filters: [
        { name: 'Media Files', extensions: ['mp4','mkv','avi','mov','wmv','flv','webm','m4v','3gp','mp3','wav','m4a','aac','ogg','flac','wma','opus','png','jpg','jpeg','gif','bmp','tiff','webp','svg','ico','heic'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    });
    if (!canceled && filePaths.length > 0) {
      const files = filePaths.map(fp => ({
        path: fp,
        name: path.basename(fp),
        size: fs.statSync(fp).size
      }));
      return res.json({ files });
    }
  }
  res.json({ files: [] });
});

// Get ffmpeg path helper
function getFFmpegPath() {
  return getToolPath('ffmpeg');
}

// Convert file
app.post('/api/convert', upload.single('file'), (req, res) => {
  const { outputFormat, quality, inputPath, outputPath: requestedOutputPath } = req.body;
  
  // Support both uploaded file and local file path
  let srcPath;
  let originalName;
  if (req.file) {
    srcPath = req.file.path;
    originalName = req.file.originalname;
  } else if (inputPath) {
    srcPath = inputPath;
    originalName = path.basename(inputPath);
  } else {
    return res.status(400).json({ error: 'No file provided' });
  }

  if (!outputFormat) return res.status(400).json({ error: 'Output format required' });

  const id = uuidv4();
  const baseName = path.parse(originalName).name;
  const outputFileName = `${baseName}.${outputFormat}`;
  const outputDir = requestedOutputPath || defaultDownloadPath;
  if (!fs.existsSync(outputDir) || !fs.statSync(outputDir).isDirectory()) {
    return res.status(400).json({ error: 'Output folder does not exist' });
  }
  let outputPath = path.join(outputDir, outputFileName);

  // Avoid overwriting
  let counter = 1;
  while (fs.existsSync(outputPath)) {
    outputPath = path.join(outputDir, `${baseName} (${counter}).${outputFormat}`);
    counter++;
  }

  const ffmpegBin = getFFmpegPath();
  if (!ffmpegBin || !fs.existsSync(ffmpegBin)) return toolUnavailable(res, 'FFmpeg');
  const args = ['-i', srcPath, '-y'];

  // Detect file type category from extension
  const inputExt = path.extname(originalName).toLowerCase().slice(1);
  const videoExts = ['mp4','mkv','avi','mov','wmv','flv','webm','m4v','3gp','ts','m2ts'];
  const audioExts = ['mp3','wav','m4a','aac','ogg','flac','wma','opus','alac'];
  const imageExts = ['png','jpg','jpeg','gif','bmp','tiff','tif','webp','svg','ico','heic','heif','avif'];

  const isVideo = videoExts.includes(inputExt);
  const isAudio = audioExts.includes(inputExt);
  const isImage = imageExts.includes(inputExt);

  const qualityLevel = quality || 'high';

  if (isVideo) {
    const outputIsVideo = videoExts.includes(outputFormat);
    const outputIsAudio = audioExts.includes(outputFormat);

    if (outputIsAudio) {
      // Extract audio from video
      args.push('-vn');
      if (outputFormat === 'mp3') {
        const br = qualityLevel === 'high' ? '320k' : qualityLevel === 'medium' ? '192k' : '128k';
        args.push('-c:a', 'libmp3lame', '-b:a', br, '-ar', '48000');
      } else if (outputFormat === 'wav') {
        args.push('-c:a', 'pcm_s16le', '-ar', '48000');
      } else if (outputFormat === 'm4a' || outputFormat === 'aac') {
        const br = qualityLevel === 'high' ? '256k' : qualityLevel === 'medium' ? '192k' : '128k';
        args.push('-c:a', 'aac', '-b:a', br, '-ar', '48000');
      } else if (outputFormat === 'ogg') {
        args.push('-c:a', 'libvorbis', '-q:a', qualityLevel === 'high' ? '8' : qualityLevel === 'medium' ? '5' : '3');
      } else if (outputFormat === 'flac') {
        args.push('-c:a', 'flac');
      } else if (outputFormat === 'opus') {
        const br = qualityLevel === 'high' ? '128k' : qualityLevel === 'medium' ? '96k' : '64k';
        args.push('-c:a', 'libopus', '-b:a', br);
      }
    } else if (outputIsVideo) {
      // Video to video
      if (outputFormat === 'mp4') {
        const crf = qualityLevel === 'high' ? '18' : qualityLevel === 'medium' ? '23' : '28';
        args.push('-c:v', 'libx264', '-preset', 'medium', '-crf', crf, '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart');
      } else if (outputFormat === 'webm') {
        const crf = qualityLevel === 'high' ? '20' : qualityLevel === 'medium' ? '30' : '40';
        args.push('-c:v', 'libvpx-vp9', '-crf', crf, '-b:v', '0', '-c:a', 'libopus', '-b:a', '128k');
      } else if (outputFormat === 'mkv') {
        const crf = qualityLevel === 'high' ? '18' : qualityLevel === 'medium' ? '23' : '28';
        args.push('-c:v', 'libx264', '-preset', 'medium', '-crf', crf, '-c:a', 'aac', '-b:a', '192k', '-ar', '48000');
      } else if (outputFormat === 'avi') {
        args.push('-c:v', 'libx264', '-c:a', 'mp3', '-b:a', '192k', '-ar', '48000');
      } else if (outputFormat === 'mov') {
        const crf = qualityLevel === 'high' ? '18' : qualityLevel === 'medium' ? '23' : '28';
        args.push('-c:v', 'libx264', '-preset', 'medium', '-crf', crf, '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000');
      } else {
        args.push('-c:v', 'libx264', '-c:a', 'aac', '-ar', '48000');
      }
    }
  } else if (isAudio) {
    if (outputFormat === 'mp3') {
      const br = qualityLevel === 'high' ? '320k' : qualityLevel === 'medium' ? '192k' : '128k';
      args.push('-c:a', 'libmp3lame', '-b:a', br, '-ar', '48000');
    } else if (outputFormat === 'wav') {
      args.push('-c:a', 'pcm_s16le', '-ar', '48000');
    } else if (outputFormat === 'm4a' || outputFormat === 'aac') {
      const br = qualityLevel === 'high' ? '256k' : qualityLevel === 'medium' ? '192k' : '128k';
      args.push('-c:a', 'aac', '-b:a', br, '-ar', '48000');
    } else if (outputFormat === 'ogg') {
      args.push('-c:a', 'libvorbis', '-q:a', qualityLevel === 'high' ? '8' : qualityLevel === 'medium' ? '5' : '3');
    } else if (outputFormat === 'flac') {
      args.push('-c:a', 'flac');
    } else if (outputFormat === 'opus') {
      const br = qualityLevel === 'high' ? '128k' : qualityLevel === 'medium' ? '96k' : '64k';
      args.push('-c:a', 'libopus', '-b:a', br);
    }
  } else if (isImage) {
    if (outputFormat === 'jpg' || outputFormat === 'jpeg') {
      const q = qualityLevel === 'high' ? '2' : qualityLevel === 'medium' ? '5' : '10';
      args.push('-q:v', q);
    } else if (outputFormat === 'webp') {
      const q = qualityLevel === 'high' ? '90' : qualityLevel === 'medium' ? '75' : '50';
      args.push('-quality', q);
    } else if (outputFormat === 'png') {
      // PNG is lossless
    } else if (outputFormat === 'bmp') {
      // BMP is lossless
    } else if (outputFormat === 'gif') {
      args.push('-vf', 'fps=10,scale=320:-1:flags=lanczos');
    }
  }

  // Add progress output
  args.push('-progress', 'pipe:1', outputPath);

  const proc = runProcess(ffmpegBin, args, { env: getSpawnEnv() });
  const conversion = {
    id,
    inputName: originalName,
    outputName: outputFileName,
    outputFormat,
    status: 'converting',
    progress: 0,
    startedAt: new Date().toISOString(),
    error: null
  };

  activeConversions.set(id, { proc, info: conversion });
  proc.once('error', (err) => {
    activeConversions.delete(id);
    conversion.status = 'error';
    conversion.error = `Unable to start FFmpeg: ${err.message}`;
    broadcast({ type: 'convert-progress', id, conversion: { ...conversion } });
  });

  // Get input file duration for progress calc
  let totalDuration = 0;
  const probeProc = runProcess(ffmpegBin, ['-i', srcPath, '-hide_banner'], { env: getSpawnEnv() });
  let probeOutput = '';
  probeProc.stderr.on('data', d => probeOutput += d.toString());
  probeProc.once('error', () => {});
  probeProc.on('close', () => {
    const durMatch = probeOutput.match(/Duration: (\d+):(\d+):(\d+)\.(\d+)/);
    if (durMatch) {
      totalDuration = parseInt(durMatch[1]) * 3600 + parseInt(durMatch[2]) * 60 + parseInt(durMatch[3]) + parseFloat('0.' + durMatch[4]);
    }
  });

  proc.stdout.on('data', (data) => {
    const line = data.toString();
    const timeMatch = line.match(/out_time_us=(\d+)/);
    if (timeMatch && totalDuration > 0) {
      const currentSec = parseInt(timeMatch[1]) / 1000000;
      conversion.progress = Math.min(99, Math.round((currentSec / totalDuration) * 100));
      broadcast({ type: 'convert-progress', id, conversion: { ...conversion } });
    }
    const progressMatch = line.match(/progress=(\w+)/);
    if (progressMatch && progressMatch[1] === 'end') {
      conversion.progress = 100;
    }
  });

  proc.stderr.on('data', (data) => {
    const line = data.toString();
    // Also try to get duration from stderr
    if (totalDuration === 0) {
      const durMatch = line.match(/Duration: (\d+):(\d+):(\d+)\.(\d+)/);
      if (durMatch) {
        totalDuration = parseInt(durMatch[1]) * 3600 + parseInt(durMatch[2]) * 60 + parseInt(durMatch[3]) + parseFloat('0.' + durMatch[4]);
      }
    }
  });

  proc.on('close', (code) => {
    activeConversions.delete(id);
    // Clean up uploaded temp file
    if (req.file && fs.existsSync(srcPath)) {
      try { fs.unlinkSync(srcPath); } catch (e) {}
    }

    if (code === 0) {
      conversion.status = 'done';
      conversion.progress = 100;
      conversion.finishedAt = new Date().toISOString();
      conversion.outputPath = outputPath;
    } else {
      conversion.status = 'error';
      conversion.error = 'Conversion failed';
    }
    broadcast({ type: 'convert-progress', id, conversion: { ...conversion } });
  });

  res.json({ id, message: 'Conversion started', conversion });
});

// Cancel conversion
app.post('/api/cancel-convert/:id', (req, res) => {
  const entry = activeConversions.get(req.params.id);
  if (!entry) return res.status(404).json({ error: 'Conversion not found' });
  entry.proc.kill();
  entry.info.status = 'cancelled';
  activeConversions.delete(req.params.id);
  broadcast({ type: 'convert-progress', id: req.params.id, conversion: { ...entry.info } });
  res.json({ message: 'Cancelled' });
});

let serverPort = null;
const PORT = 0;
function startServer() {
  if (server.listening) return Promise.resolve(serverPort || server.address().port);
  getStateStore();
  startDohProxy();
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(PORT, '127.0.0.1', () => {
      serverPort = server.address().port;
      console.log(`\nNuutapao Tools running at http://127.0.0.1:${serverPort}\n`);
      console.log(`📁 Downloads saved to: ${defaultDownloadPath}\n`);

      // Defer background checks to avoid blocking/slowing down initial launch
      setTimeout(() => {
        checkYtDlpVersion();
        const lastChecked = new Date(getStateStore().get().engine.lastChecked || 0).getTime();
        if (!lastChecked || Date.now() - lastChecked >= 24 * 60 * 60 * 1000) {
          updateYtDlp();
        }
      }, 3000);

      resolve(serverPort);
    });
  });
}

function stopServer() {
  return new Promise((resolve) => {
    try {
      wss.close(() => {});
      if (dohProxyStarted) {
        dohProxy.close(() => {});
        dohProxyStarted = false;
      }
      server.close(() => {
        serverPort = null;
        resolve();
      });
    } catch {
      resolve();
    }
  });
}

module.exports = {
  configureRuntime: (config) => { runtimeConfig = { ...runtimeConfig, ...config }; },
  setRuntimeAdapters: (adapters = {}) => { runtimeAdapters = { ...adapters }; },
  resetRuntimeAdapters: () => { runtimeAdapters = {}; },
  getPort: () => serverPort,
  setDialog: (d) => electronDialog = d,
  startServer,
  stopServer,
  flushState: () => stateStore?.save(),
  getAppState: () => getStateStore().get(),
  patchAppState: (partial) => getStateStore().patch(partial),
  buildAccessArgs,
  buildPlatformArgs,
  getSpawnEnv,
  resolveProxyUrl,
  validateAccessSettings,
  classifyYtDlpError,
  extractCleanUrl,
  ensureNetscapeCookieFile,
  formatTimeSection,
  parseTimeToSeconds,
  formatEtaSeconds,
  getSectionDuration,
  getDohUrl,
  QR_SIZES,
  validateQrRequest,
  createQrOptions,
  isTikTokUrl,
  resolveTikTokVideo
};
