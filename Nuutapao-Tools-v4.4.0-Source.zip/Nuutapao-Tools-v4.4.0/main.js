// Ensure UTF-8 encoding across all subprocesses (yt-dlp, Python, etc.)
process.env.PYTHONIOENCODING = 'utf-8';
process.env.PYTHONUTF8 = '1';
if (!process.env.LANG) process.env.LANG = 'en_US.UTF-8';
if (!process.env.LC_ALL) process.env.LC_ALL = 'en_US.UTF-8';

const { app, BrowserWindow, dialog, ipcMain, shell, clipboard, nativeImage, Tray, Menu } = require('electron');
const appServer = require('./server');
const path = require('path');
const fs = require('fs');

// Universal Windows Compatibility & Performance Optimizations
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
app.commandLine.appendSwitch('high-dpi-support', '1');

// Support CLI flags and environment overrides for low-spec / VM / broken GPU environments
if (
  process.argv.includes('--disable-gpu') ||
  process.env.NUUTAPAO_DISABLE_GPU === '1' ||
  process.env.NUUTAPAO_TEST === '1'
) {
  app.disableHardwareAcceleration();
}
if (process.argv.includes('--no-sandbox')) {
  app.commandLine.appendSwitch('no-sandbox');
}

// Graceful child process crash handler (GPU, utility processes)
app.on('child-process-gone', (event, details) => {
  if (details.type === 'GPU') {
    console.warn('GPU process gone:', details.reason, '- running in safe fallback');
  }
});
app.on('render-process-gone', (event, webContents, details) => {
  console.warn('Render process gone:', details.reason);
});

let mainWindow;
let isMaximizedState = false;
let saveWindowStateTimer = null;
let tray = null;
let isQuitting = false;

// --- Single Instance Lock ---
// Prevent duplicate windows when "Run in Background" is on and user re-launches
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      if (!mainWindow.isVisible()) mainWindow.show();
      mainWindow.focus();
    }
  });
}

function saveWindowState() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  const bounds = mainWindow.getNormalBounds();
  appServer.patchAppState({
    window: {
      bounds: { x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height },
      maximized: mainWindow.isMaximized()
    }
  });
}

function scheduleWindowStateSave() {
  clearTimeout(saveWindowStateTimer);
  saveWindowStateTimer = setTimeout(saveWindowState, 300);
}

function createTray() {
  if (tray) return;

  const icoPath = path.join(__dirname, 'public', 'tray-icon.ico');
  const pngPath = path.join(__dirname, 'public', 'tray-icon.png');
  const rootIco = path.join(__dirname, 'icon.ico');
  const logoPng = path.join(__dirname, 'public', 'logo.png');

  let trayImage;
  // On Windows, ICO files provide crisp multi-resolution rendering across all DPI scaling levels
  if (process.platform === 'win32' && fs.existsSync(icoPath)) {
    trayImage = nativeImage.createFromPath(icoPath);
  } else if (fs.existsSync(pngPath)) {
    trayImage = nativeImage.createFromPath(pngPath);
  } else if (fs.existsSync(rootIco)) {
    trayImage = nativeImage.createFromPath(rootIco);
  } else if (fs.existsSync(logoPng)) {
    const raw = nativeImage.createFromPath(logoPng);
    trayImage = raw.isEmpty() ? raw : raw.resize({ width: 16, height: 16, quality: 'best' });
  } else {
    trayImage = nativeImage.createEmpty();
  }

  tray = new Tray(trayImage);
  tray.setToolTip('Nuutapao Tools');

  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Open Nuutapao Tools',
      click: () => {
        if (mainWindow) {
          mainWindow.show();
          mainWindow.focus();
        }
      }
    },
    { type: 'separator' },
    {
      label: 'Quit Nuutapao Tools',
      click: () => {
        isQuitting = true;
        app.quit();
      }
    }
  ]);

  tray.setContextMenu(contextMenu);

  tray.on('click', () => {
    if (!mainWindow) return;
    if (mainWindow.isVisible()) {
      mainWindow.focus();
    } else {
      mainWindow.show();
    }
  });

  tray.on('double-click', () => {
    if (!mainWindow) return;
    mainWindow.show();
    mainWindow.focus();
  });
}

function createWindow(port) {
  const savedWindow = appServer.getAppState().window || {};
  const savedBounds = savedWindow.bounds || {};
  const icoPath = path.join(__dirname, 'public', 'icon.ico');
  const pngPath = path.join(__dirname, 'public', 'tray-icon.png');
  const windowIcon = fs.existsSync(icoPath) ? icoPath : pngPath;

  mainWindow = new BrowserWindow({
    width: Math.max(900, Number(savedBounds.width) || 1050),
    height: Math.max(650, Number(savedBounds.height) || 700),
    ...(Number.isFinite(savedBounds.x) && Number.isFinite(savedBounds.y) ? { x: savedBounds.x, y: savedBounds.y } : {}),
    minWidth: 900,
    minHeight: 650,
    show: false,
    backgroundColor: '#00000000',
    frame: false, // Frameless for cute rounded UI
    transparent: true,
    icon: windowIcon,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      // Downloads run in the local server/main process, so inactive windows can
      // throttle normally instead of consuming CPU while hidden in the tray.
      preload: path.join(__dirname, 'preload.js')
    }
  });

  mainWindow.once('ready-to-show', () => {
    if (savedWindow.maximized) {
      mainWindow.maximize();
    }
    mainWindow.show();
  });

  isMaximizedState = false;

  mainWindow.on('maximize', () => {
    isMaximizedState = true;
    scheduleWindowStateSave();
    mainWindow.webContents.send('window-maximized-status', true);
  });

  mainWindow.on('unmaximize', () => {
    isMaximizedState = false;
    scheduleWindowStateSave();
    mainWindow.webContents.send('window-maximized-status', false);
  });

  mainWindow.on('resize', scheduleWindowStateSave);
  mainWindow.on('move', scheduleWindowStateSave);
  mainWindow.on('close', (e) => {
    const settings = appServer.getAppState()?.settings || {};
    const runInBackground = settings.runInBackground !== false;
    if (!isQuitting && runInBackground) {
      e.preventDefault();
      saveWindowState();
      mainWindow.hide();
    } else {
      saveWindowState();
    }
  });

  mainWindow.loadURL(`http://127.0.0.1:${port}`);
}

app.whenReady().then(async () => {
  appServer.configureRuntime({
    isPackaged: app.isPackaged,
    resourcesPath: process.resourcesPath,
    userDataPath: app.getPath('userData')
  });
  appServer.setDialog(dialog);
  const port = await appServer.startServer();
  createWindow(port);
  createTray();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow(appServer.getPort());
    } else if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });
}).catch((err) => {
  dialog.showErrorBox('Nuutapao Tools could not start', err.message);
  app.quit();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    const settings = appServer.getAppState()?.settings || {};
    const runInBackground = settings.runInBackground !== false;
    if (isQuitting || !runInBackground) {
      app.quit();
    }
  }
});

app.on('before-quit', () => {
  isQuitting = true;
  clearTimeout(saveWindowStateTimer);
  saveWindowState();
  appServer.flushState();
});

// IPC for custom window controls
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (isMaximizedState) {
    mainWindow?.unmaximize();
    isMaximizedState = false;
    mainWindow?.webContents.send('window-maximized-status', false);
  } else {
    mainWindow?.maximize();
    isMaximizedState = true;
    mainWindow?.webContents.send('window-maximized-status', true);
  }
});
ipcMain.on('window-close', () => {
  const settings = appServer.getAppState()?.settings || {};
  const runInBackground = settings.runInBackground !== false;
  if (!isQuitting && runInBackground) {
    saveWindowState();
    mainWindow?.hide();
  } else {
    mainWindow?.close();
  }
});
ipcMain.on('window-always-on-top', (event, val) => {
  mainWindow?.setAlwaysOnTop(val);
});
ipcMain.on('window-run-in-background', (event, val) => {
  appServer.patchAppState({ settings: { runInBackground: Boolean(val) } });
});
ipcMain.on('open-external', (event, url) => {
  if (!url) return;
  if (url.startsWith('http://') || url.startsWith('https://')) {
    shell.openExternal(url);
  } else if (fs.existsSync(url)) {
    shell.openPath(url);
  } else {
    shell.openExternal(url);
  }
});
ipcMain.handle('copy-image', (event, dataUrl) => {
  if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/png;base64,')) {
    throw new Error('Invalid PNG image data.');
  }
  const image = nativeImage.createFromDataURL(dataUrl);
  if (image.isEmpty()) throw new Error('Could not read the QR image.');
  clipboard.writeImage(image);
  return true;
});
