'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { getInstallableRelease } = require('../hub/release-utils');

test('accepts a release whose tag and setup asset versions match', () => {
  const result = getInstallableRelease({
    tag_name: 'V.4.2',
    assets: [{ name: 'Nuutapao.Tools.Setup.4.2.0.exe' }]
  });

  assert.equal(result.version, '4.2.0');
  assert.equal(result.asset.name, 'Nuutapao.Tools.Setup.4.2.0.exe');
});

test('rejects a release whose setup asset cannot deliver the tagged version', () => {
  const result = getInstallableRelease({
    tag_name: 'V.4.3',
    assets: [{ name: 'Nuutapao.Tools.Setup.4.2.0.exe' }]
  });

  assert.equal(result, null);
});
