'use strict';

function parseSemver(value) {
  const match = String(value || '').match(/(\d+)(?:\.(\d+))?(?:\.(\d+))?/);
  if (!match) return [0, 0, 0];
  return [
    Number.parseInt(match[1], 10) || 0,
    Number.parseInt(match[2], 10) || 0,
    Number.parseInt(match[3], 10) || 0
  ];
}

function compareSemver(left, right) {
  const a = Array.isArray(left) ? left : parseSemver(left);
  const b = Array.isArray(right) ? right : parseSemver(right);
  for (let index = 0; index < 3; index += 1) {
    if (a[index] !== b[index]) return a[index] > b[index] ? 1 : -1;
  }
  return 0;
}

function isToolsSetupAsset(asset) {
  const name = String(asset?.name || '').toLowerCase();
  return name.endsWith('.exe') && /nuutapao.*tools.*setup/.test(name);
}

function getAssetVersion(asset) {
  const name = String(asset?.name || '');
  const match = name.match(/(?:setup[._ -]*)(\d+(?:\.\d+){1,2})\.exe$/i);
  return match ? match[1] : null;
}

// The executable is what will actually be installed, so only advertise a
// release when its tag and setup filename describe the same version.
function getInstallableRelease(release) {
  if (!release || release.draft) return null;
  const asset = (release.assets || []).find(isToolsSetupAsset);
  if (!asset) return null;

  const tagVersion = parseSemver(release.tag_name || release.name);
  const assetVersion = getAssetVersion(asset);
  if (!assetVersion || compareSemver(tagVersion, assetVersion) !== 0) return null;

  return { release, asset, version: assetVersion };
}

module.exports = {
  parseSemver,
  compareSemver,
  isToolsSetupAsset,
  getAssetVersion,
  getInstallableRelease
};
