const { contextBridge, ipcRenderer } = require('electron');

const api = {
  closeWindow: () => ipcRenderer.send('hub-close'),
  minimizeWindow: () => ipcRenderer.send('hub-minimize'),
  maximizeWindow: () => ipcRenderer.send('hub-maximize'),
  unmaximizeWindow: () => ipcRenderer.send('hub-unmaximize'),
  toggleMaximize: () => ipcRenderer.send('hub-toggle-maximize'),
  launchApp: () => ipcRenderer.invoke('hub-launch-tools'),
  uninstallTools: () => ipcRenderer.invoke('hub-uninstall-tools'),
  confirmDialog: (opts) => ipcRenderer.invoke('hub-confirm-dialog', opts),
  selectDirectory: (currentPath) => ipcRenderer.invoke('hub-select-dir', currentPath),
  getSystemInfo: () => ipcRenderer.invoke('hub-system-info'),
  checkGitHubUpdates: () => ipcRenderer.invoke('hub-check-github-updates'),
  downloadAndInstallUpdate: (params) => ipcRenderer.invoke('hub-download-and-install-update', params),
  onDownloadProgress: (callback) => {
    ipcRenderer.removeAllListeners('hub-download-progress');
    ipcRenderer.on('hub-download-progress', (e, data) => callback(data));
  },
  onInstallLog: (callback) => {
    ipcRenderer.removeAllListeners('hub-install-log');
    ipcRenderer.on('hub-install-log', (e, msg) => callback(msg));
  },
  openExternal: (url) => ipcRenderer.invoke('hub-open-external', url)
};

contextBridge.exposeInMainWorld('electronAPI', api);
contextBridge.exposeInMainWorld('hubAPI', api);

